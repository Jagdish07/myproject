<?php  
 require_once "php/db_connect.php"; 
 $db = new DB_CONNECT();  
if(isset($_POST['submit'])) {
$ids  = $_REQUEST['data'];
$id= explode("-",$ids);
$nofAlb = mysql_query("UPDATE Clients SET AccountVerified='Y' WHERE ClientId='".$id[1]."'");
if($nofAlb) {
	
	$msg= "Your account has been activated .  please Click <a href='www.footballbh.com/events.php'> Here </a>" ;
	
}
}
?>
<div class="container">

	<div class="events_box clearfix">
	  
	  <div class="row">
		  <div class="draw_time">
		  </div>
		  <div class="act_form">
		    <div class="fm_hdg">Click on Home win, Draw or Away Win then press Select to place your bet.<br/>Good luck!!</div>
			<div> <?php echo isset($msg)?$msg:'' ?>
			<form method="POST">
			  
			   <input type="submit" value="Activate" class="btn btn-success" name="submit"/>
			</form>
		  </div>
	  </div>
    </div>	 
	</section>
</article>
<?php  
require_once "footer.php"; 
?>