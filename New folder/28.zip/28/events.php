<?php  
require_once "header.php"; 

$page ='';
if(isset($_GET['page'])){
	$page = $_GET['page'];
}else{
  $page = 1;
}

if($page == "" || $page == "1"){
  $page1 = 1;
}
else{
  $page1 = ($page*1)-1;
}
?>

<div class="container">
<article class="events_main">
    <div class="ep_hdg"><h2>Next Live Event</h2></div>
	<?php
	  $query = mysql_query("SELECT * FROM `Events` WHERE NOW() < TIMESTAMP(`MatchDate`,`MatchTime`) AND `Status` = 'Active' ORDER BY MatchDate,MatchTime ASC LIMIT 1");
	  $nofAlb = mysql_num_rows($query);
	  if($nofAlb == 1){
	?>
	<section class="mn_box">
	<?php 
	while($results = mysql_fetch_array($query)){ 
	  $Day = $results['MatchDate'];
      $Day = date('l', strtotime($Day));
	  $Date = $results['MatchDate'];
	  $Time = $results['MatchTime'];
	  $League = $results['League'];
	  $HomeTeam = $results['HomeTeam'];
	  $AwayTeam = $results['AwayTeam'];
	  $DrawTime = $results['DrawTime'];
	?>
	<div class="events_box clearfix">
	  <div class="row">
		  <div class="evt_date">
			<p><?php echo $Day; ?></p>
			<p><?php echo $Date; ?></p>
			<p><?php echo $Time; ?></p>
		  </div>
		  <div class="evt_data">
			<h4><?php echo $League; ?></h4>
			<p><?php echo $HomeTeam.'<span style="padding:0 15px;">vs</span>'.$AwayTeam ?></p>
		  </div>
	  </div>
	  <div class="row">
		  <div class="draw_time">
		  Draw Time: <?php echo $DrawTime; ?>   
		  </div>
		  <div class="act_form">
		    <div class="fm_hdg">Click on Home win, Draw or Away Win then press Select to place your bet.<br/>Good luck!!</div>
			<form>
			   <div class="check_options">
				 <input type="radio" name=""/> Home Win &nbsp;
				 <input type="radio" name=""/> Draw &nbsp;
				 <input type="radio" name=""/> Away Win
			   </div>
			   <input type="submit" value="Place £2 Bet" class="sub_btn"/>
			</form>
		  </div>
	  </div>
    </div>	 
	<?php
	}
	}else{
	  echo '<div class="events_box clearfix">No live events.</div>';
	}
	?>   
	</section>
</article>


<article class="events_main">
	<div class="ep_hdg"><h2>Upcoming Events</h2></div>
	<section class="mn_box">
	<?php 
	$nofAlb = mysql_query("SELECT * FROM `Events` WHERE NOW() < TIMESTAMP(`MatchDate`,`MatchTime`) AND `Status` = 'Active'");
	$nofAlb = mysql_num_rows($nofAlb);
	
	$query = mysql_query("SELECT * FROM `Events` WHERE NOW() < TIMESTAMP(`MatchDate`,`MatchTime`) AND `Status` = 'Active' ORDER BY MatchDate,MatchTime ASC LIMIT $page1, $nofAlb");
	 
	if($nofAlb != 0){
	
	while($results = mysql_fetch_array($query)){ 
	  $Day = $results['MatchDate'];
	  $Day = date('l', strtotime($Day));
	  $Date = $results['MatchDate'];
	  $Time = $results['MatchTime'];
	  $League = $results['League'];
	  $HomeTeam = $results['HomeTeam'];
	  $AwayTeam = $results['AwayTeam'];
	  $DrawTime = $results['DrawTime'];
	?>
	<div class="events_box clearfix">
	  <div class="row">
		  <div class="evt_date">
			<p><?php echo $Day; ?></p>
			<p><?php echo $Date; ?></p>
			<p><?php echo $Time; ?></p>
		  </div>
		  <div class="evt_data">
			<h4><?php echo $League; ?></h4>
			<p><?php echo $HomeTeam.'<span style="padding:0 15px;">vs</span>'.$AwayTeam ?></p>
		  </div>
	  </div>
	  <div class="row">
		  <div class="draw_time">
		  Draw Time: <?php echo $DrawTime; ?>   
		  </div>
		  <div class="act_form">
		    <div class="fm_hdg">Click on Home win, Draw or Away Win then press Select to place your bet.<br/>Good luck!!</div>
			<form>
			   <div class="check_options">
				 <input type="radio" name=""/> Home Win &nbsp;
				 <input type="radio" name=""/> Draw &nbsp;
				 <input type="radio" name=""/> Away Win
			   </div>
			   <input type="submit" value="Place £2 Bet" class="sub_btn"/>
			</form>
		  </div>
	  </div>
	</div>	 
	<?php
	}
	}else{
	  echo '<div class="events_box clearfix">No upcoming events, please check tomorrow...</div>';
	}
	?>   
	</section>
</article>

</div>

<?php
  require_once "register.php"; 
?>
<?php
 // require_once "login.php"; 
?>

<?php  
require_once "footer.php"; 
?>