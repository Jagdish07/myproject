<?php
require_once "php/database.php"; 
$db = DB();

// Application library ( with DemoLib class )
require_once "function.php";
$app = new DemoLib();
/* ============= CHECK EMAIL =========*/
if(isset($_POST['check_email']) && $_POST['check_email'] == 1){
$email = $_POST['email'];
  $checkemail = $app->isEmail($_POST['email']);
if($checkemail == true){
   echo '1';
}
} 
/* if(isset($_POST['re_check']) && $_POST['re_check'] == 2){
$email = $_POST['email'];
  $user_id = $app->Login($email, $password); // check user login
        if($user_id > 0)
        {
            $_SESSION['user_id'] = $user_id; // Set Session
            header("Location: profile.php"); // Redirect user to the profile.php
        }
        else
        {
            $login_error_message = 'Invalid login details!';
        }
} 
 */
/* ============= REGISTER =========*/
if(isset($_POST['re_check']) && $_POST['re_check'] == 1){
$firstname = $_POST['firstname'];
$surname = $_POST['surname'];
$email = $_POST['email'];
$password = $_POST['password'];
$AccountVerified = 'N';
$DateRegistered = date("Y-m-d h:i");
$user_id = $app->Register($firstname, $surname, $password, $email, $DateRegistered, $AccountVerified);
if($user_id){
	
	 echo 'yes';
	sendMail($email,$user_id);
}
else {
	
	echo 'no';
}

//SYSDATE()
/* $data = mysql_query("INSET INTO `Clients` (FirstName,Surname,Password,EmailAddress,DateRegistered,AccountVerified) VALUES ($firstname,$surname,$password ,$email,SYSDATE(),'N')"); */
}



function sendMail($email,$user_id){
$url = 'http://www.footballbh.com/activate.php?data='.generateRandomString().'-'.$user_id;
//$to = $email;
$to = $email;
$subject = "HTML Email For Email confirmation";
$htmlContent = '
    <html>
    <head>
        <title>Welcome to Football</title>
    </head>
    <body>
        <h1>Thanks you for joining with us!</h1>
        <table cellspacing="0" style="border: 2px dashed #FB4314; width: 300px; height: 200px;">
            <tr style="background-color: #e0e0e0;">
            </tr>
            <tr>
                <th>Click here for Account activation:</th><td><a href='.$url.'>Click here</a></td>
            </tr>
        </table>
    </body>
    </html>';

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

$headers .= 'From: jag<jag@example.com>' . "\r\n";
$headers .= 'Cc: welcome@example.com' . "\r\n";
$headers .= 'Bcc: welcome2@example.com' . "\r\n"; 

if(mail($to,$subject,$htmlContent,$headers)):
    $successMsg = 'Email has sent successfully.';
else:
    $errorMsg = 'Email sending fail.';
endif;
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}







?>