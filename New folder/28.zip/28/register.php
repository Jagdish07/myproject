
<div class="popup" id="register_pop">
  <div class="overlay"></div>
  <div class="popup_content">

     <div class="mn_pop">
	  <div class="form">
	   <form method="post" >
	     <span class="msg"> </span>
	      <div>
		    <label>First Name</label>
			<input type="text" name="firstname" id="firstname"/>
			<span class="error"></span>
		  </div>
		  <div>
		    <label>Surname</label>
			<input type="text" name="surname" id="surname"/>
			<span class="error"></span>
		  </div>
		  <div>
		    <label>Email</label>
			<input type="Email" name="email" id="email"/>
			<span class="error"></span>
		  </div>
		  <div>
		    <label>Password</label>
			<input type="password" name="password" id="password" />
			<span class="error"></span>
		  </div>
		  <div>
		    <label>Re-Enter Password</label>
			<input type="password" name="re-password" id="re_password"  />
			<span class="error"></span>
		  </div>
		  <div>
			<input type="button" value="Register"  id="register" class="btn" />
		  </div>
	   </form>
	   </div> 
	 </div>     
  </div>
</div>