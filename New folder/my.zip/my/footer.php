</div>
</div>

<script type="text/javascript" src="js/function.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('#register_btn').click(function(){
	  $('#register_pop').fadeIn(500);
	});
	
	$('.overlay').click(function(){
	  $('.popup').fadeOut(500);
	});
  });
</script>
</body>
</html>