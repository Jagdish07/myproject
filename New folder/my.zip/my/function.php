<?php 
/*
 * PHP Login Registration system
 *
 * */

class DemoLib
{
    /*
     * Register New User
     *
     * @param $name, $email, $username, $password
     * @return ID
     * */
    public function Register($FirstName, $Surname, $Password, $EmailAddress,$DateRegistered,$AccountVerified )
    {
        try {
            $db = DB();
			
            $query = $db->prepare("INSERT INTO Clients(FirstName, Surname, Password, EmailAddress,DateRegistered,AccountVerified) VALUES (:FirstName,:Surname,:Password,:EmailAddress,:DateRegistered,:AccountVerified)");
            $query->bindParam("FirstName", $FirstName, PDO::PARAM_STR);
            $query->bindParam("Surname", $Surname, PDO::PARAM_STR);
			
			$enc_password = hash('sha256', $Password);
            $query->bindParam("Password", $enc_password, PDO::PARAM_STR);
			
             $query->bindParam("EmailAddress", $EmailAddress, PDO::PARAM_STR);
             $query->bindParam("DateRegistered", $DateRegistered, PDO::PARAM_STR);
             $query->bindParam("AccountVerified", $AccountVerified, PDO::PARAM_STR);
           /* $query->bindParam("DateRegistered", $DateRegistered PDO::PARAM_STR);
            $query->bindParam("AccountVerified", $AccountVerified, PDO::PARAM_STR);
            */
            $query->execute();
			

            return $db->lastInsertId();
        } catch (PDOException $e) {
            exit($e->getMessage());
        }
    }
    /*
     * Check Email
     *
     * @param $email
     * @return boolean
     * */
    public function isEmail($email)
    {
        try {
            $db = DB();
            $query = $db->prepare("SELECT ClientId FROM Clients WHERE EmailAddress=:email");
            $query->bindParam("email", $email, PDO::PARAM_STR);
            $query->execute();
            if ($query->rowCount() > 0) {
                return '1';
            } else {
                return '0';
            }
        } catch (PDOException $e) {
            exit($e->getMessage());
        }
    }

    /*
     * Login
     *
     * @param $username, $password
     * @return $mixed
     * */
    public function Login($email, $password)
    {
        try {
            $db = DB();
            $query = $db->prepare("SELECT ClientId FROM Clients WHERE EmailAddress=:EmailAddress AND Password=:Password");
            $query->bindParam("EmailAddress", $email, PDO::PARAM_STR);
            $enc_password = hash('sha256', $password);
            $query->bindParam("Password", $enc_password, PDO::PARAM_STR);
            $query->execute();
            if ($query->rowCount() > 0) {
                $result = $query->fetch(PDO::FETCH_OBJ);
                return $result->ClientId;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            exit($e->getMessage());
        }
    }

}