<?php
require_once "php/database.php"; 
$db = DB();

// Application library ( with DemoLib class )
require_once "function.php";
$app = new DemoLib();
/* ============= CHECK EMAIL =========*/
if(isset($_POST['check_email']) && $_POST['check_email'] == 1){
$email = $_POST['email'];
  $checkemail = $app->isEmail($_POST['email']);
if($checkemail == true){
   echo '1';
}
} 
/* if(isset($_POST['re_check']) && $_POST['re_check'] == 2){
$email = $_POST['email'];
  $user_id = $app->Login($email, $password); // check user login
        if($user_id > 0)
        {
            $_SESSION['user_id'] = $user_id; // Set Session
            header("Location: profile.php"); // Redirect user to the profile.php
        }
        else
        {
            $login_error_message = 'Invalid login details!';
        }
} 
 */
/* ============= REGISTER =========*/
if(isset($_POST['re_check']) && $_POST['re_check'] == 1){
$firstname = $_POST['firstname'];
$surname = $_POST['surname'];
$email = $_POST['email'];
$password = $_POST['password'];
$AccountVerified = 'N';
$DateRegistered = date("Y-m-d h:i");
$user_id = $app->Register($firstname, $surname, $password, $email, $DateRegistered, $AccountVerified);
if($user_id){
	
	 echo 'yes';
	
}
else {
	
	echo 'no';
}

//SYSDATE()
/* $data = mysql_query("INSET INTO `Clients` (FirstName,Surname,Password,EmailAddress,DateRegistered,AccountVerified) VALUES ($firstname,$surname,$password ,$email,SYSDATE(),'N')"); */
}













?>