<?php  
 // connecting to db
 require_once "php/db_connect.php"; 
 $db = new DB_CONNECT();  
?>
<!DOCTYPE html>
<html lang="en-US">
<head>  
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>THE FOOTBALL LOTTERY</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery.js"></script>
</head>
<body>
<div id="wrapper">
<header>
  <div class="container">
    <h1 class="logo">SITE LOGO</h1>
	<div class="ls_btns">
	  <a href="#" class="top_btn">Sign In</a>
	  <a href="javascript:void(0);" class="top_btn" id="register_btn">Register</a>
	</div>
  </div>
</header>


<div class="middle">


