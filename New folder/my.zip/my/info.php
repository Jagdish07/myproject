<?php 

phpinfo();
?>