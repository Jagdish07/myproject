
/* ------------- REGISTER-FORM ---------------*/

var form_actions;
$("#register").click(function (e){
	e.preventDefault();
	form_actions =0;
	register_form();
	
	console.log(form_actions);
	if(form_actions == '1') {
	    console.log('eeee');
		form_actions = '0';
		$('#register').attr('value', 'processing');
		$('#register').attr('disabled', 'disabled');
		
		var $firstname = $('#firstname').val();
		var $surname = $('#surname').val();
		var $email = $('#email').val();
		var $password = $('#password').val();
		
		$.ajax({ 
		type: 'POST', 
		url: 'handler.php',
		data: {
			re_check : 1,
			firstname : $firstname,
			surname : $surname,
			email : $email,
			password : $password
		},
		success: function (data) { 
		  if(data =='yes') {
			  $('.msg').html('<span style="color:red"> Register Successfully </span>');
			  $('#register').attr('value', 'Register');
				$('#register').prop("disabled", false); 
				 $('#firstname').val('');
				$('#surname').val('');
				$('#email').val('');
				$('#password').val('');
		
		  }
		}
		});
		
	}
});
  
function register_form() {
	form_actions = '1';

	if($("#firstname").val() == '') {
		$("#firstname").next('span').text('Please enter first name');
		form_actions = '0';
	}
	else {
		$("#firstname").next('span').text('');
		form_actions = '1';
	}
	
	if($("#surname").val() == '') {
		$("#surname").next('span').text('Please enter first name');
		form_actions = '0';
	}
	else {
		$("#surname").next('span').text('');
		form_actions = '1';
	}
	
	if($("#email").val() == '') {
		$("#email").next('span').text('Please enter email');
		form_actions = '0';
	}
	else if(!(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test($("#email").val()))) {
		$("#email").next('span').text('Please enter valid email');
		form_actions = '0';
	}
	else {
	    var email = $('#email').val();
		$.ajax({ 
			type: 'POST', 
			url: 'handler.php',
			data: {
				check_email : 1,
				email : email
			},
			success: function (data) { 
			  console.log(data);
			  if(data == '1'){
			    $("#email").next('span').text('Email already exists');
			  }else{
			    $("#email").next('span').text('');
		        form_actions = '1';
			  }
			}
		});
	}
	
	if($("#password").val() == '') {
		$("#password").next('span').text('Please enter password');
		form_actions = '0';
	}
	else {
		$("#password").next('span').text('');
		form_actions = '1';
	}
	
	if($("#re_password").val() == '') {
		$("#re_password").next('span').text('Please re-enter password');
		form_actions = '0';
	}
	else {
		$("#re_password").next('span').text('');
		form_actions = '1';
	}
	
	if($("#password").val() != '' && $("#re_password").val() != '') {
	   if($("#password").val() != $("#re_password").val()){
		 $("#re_password").next('span').text('Password not matched');
		 form_actions = '0';
	   }else {
		 $("#re_password").next('span').text('');
		 form_actions = '1';
	   }
	}
	
		
}   

/* ------------- REGISTER-FORM ---------------*/
/*-------------------------in-----------------*/

/* var form_action;
$("#Login").click(function (e){
	
	e.preventDefault();
	form_action =0;
	login_form();
	
	console.log(form_action);
	if(form_action == '1') {
	
		form_action = '0';
	
		var $emails = $('#emails').val();
		var $password = $('#passwords').val();
		
		$.ajax({ 
		type: 'POST', 
		url: 'handler.php',
		data: {
			re_check : 2,
			email : $emails,
			password : $passwords
		},
		success: function (data) { 
		  if(data =='yes') {
			  $('.msg').html('<span style="color:red"> Register Successfully </span>');
			  $('#register').attr('value', 'Register');
				$('#register').prop("disabled", false); 
		  }
		}
		});
		
	}
});
 */
/* function login_form() {
	form_action = '1';

	if($("#emails").val() == '') {
		$("#emails").next('span').text('Please enter email');
		form_action = '0';
	}
	else {
		
		$("#emails").next('span').text('');
		form_action = '1';
	}
	
	if($("#passwords").val() == '') {
		$("#passwords").next('span').text('Please enter password');
		form_action = '0';
	}
	else {
	
		$("#passwords").next('span').text('');
		form_action = '1';
	}
}    */
