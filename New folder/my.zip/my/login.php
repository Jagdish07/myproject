<div class="popups" id="login_pop">
  <div class="overlay"></div>
  <div class="popup_content">
  <span class="msg"> </span>
     <div class="mn_pop">
	  <div class="form">
	   <form method="post">
		  <div>
		    <label>Email</label>
			<input type="Email" name="email" id="emails"/>
			<span class="error"></span>
		  </div>
		  <div>
		    <label>Password</label>
			<input type="password" name="password" id="passwords" />
			<span class="error"></span>
		  </div>
		 
		  <div>
			<input type="button" value="Login"  id="Login" class="btn" />
		  </div>
	   </form>
	   </div> 
	 </div>     
  </div>
</div>