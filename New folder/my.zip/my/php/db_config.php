<?php 
/* 
* All database connection variables 
*/
define('DB_USER', "football"); // db user 
define('DB_PASSWORD', "F00tball"); // db password (mention your db password here) 
define('DB_DATABASE', "football_bh"); // database name 
define('DB_SERVER', "localhost"); // db server 
?>