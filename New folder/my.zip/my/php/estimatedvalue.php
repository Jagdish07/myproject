<?php 
  
/* 
 * The following code will add a row to Clients - basic footballbh test
  * to try out run: www.footballbh.com/insert_client.php?name='bobbybeech',email='rbeech23@yahoo'
 */
  
// array for JSON response 
$response = array(); 
  

    
    // include db connect class 
    require_once __DIR__ . '/db_connect.php'; 
  
    // connecting to db 
    $db = new DB_CONNECT(); 
  
    // mysql select total from Clients table
	$sql = "select * from Clients"; 
	$result = mysql_query($sql) or die(mysql_error()); 
    $estimatedvalue = mysql_num_rows($result);
    if (mysql_num_rows($result) > 0) {
    // output data of each row
    //while($row = $result->fetch_assoc()) {
    
        echo "estimated value: " . $estimatedvalue ;
    //}
	} else {
    echo "�0";
	}		
	
?>

