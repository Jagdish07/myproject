<?php 
  
/* 
 * The following code will add a row to Clients - basic footballbh test
  * to try out run: www.footballbh.com/insert_client.php?nickname='bobbybeech',emailaddress='rbeech23@yahoo'
 */
  
// array for JSON response 
$response = array(); 
  
// check for required fields 
$nickname = $_POST['nickname'];  
$emailaddress = $_POST['emailaddress'];  

//$nickname = 'bobby beech';
echo $nickname;

?>

