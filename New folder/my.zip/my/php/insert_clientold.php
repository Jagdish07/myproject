<?php 
  
/* 
 * The following code will add a row to Clients - basic footballbh test
  * to try out run: www.footballbh.com/insert_client.php?nickname='bobbybeech',emailaddress='rbeech23@yahoo'
 */
  
// array for JSON response 
$response = array(); 
  
// check for required fields 
//$nickname = $_POST['nickname'];  
//$emailaddress = $_POST['emailaddress'];  

$nickname = 'bobby bollock';
$emailaddress = 'rbeech231';
echo $nickname, $emailaddress;

  
	//$nickname = $_POST['nickname'];   
	//$emailaddress = $_POST['emailaddress'];   
	$timesent = date('Y-m-d H:i:s');
	//$newtimestamp = strtotime('2011-11-17 05:05 + 16 minute');
	//echo date('Y-m-d H:i:s', $newtimestamp);
	$timedueconvert = strtotime('$timesent + $TimeDue minute');
	$timedue = date('Y-m-d H:i:s', $timedueconvert);
	$timereturned = "";
	$ProcessedBy = "";
    
    // include db connect class 
    require_once __DIR__ . '/db_connect.php'; 
  
    // connecting to db 
    $db = new DB_CONNECT(); 
  
    // mysql inserting a new row  
    //$result = mysql_query("INSERT INTO Clients(NickName, EmailAddress, DateRegistered) VALUES('$nickname', '$VenueId', '$Status', '$TimeSent', '$TimeDue', '$CustomerId', '$ProcessedBy')"; 
	$sql = "insert into Clients(NickName,EmailAddress, DateRegistered) 
	VALUES('$nickname', '$emailaddress', '$timesent')"; 
	
	$result = mysql_query($sql) or die(mysql_error()); 
    	
	// check if row inserted or not 
    if ($result) { 
        // successfully updated Clients
		     
		$response["success"] = 1; 
		$response["message"] = "Client row successfully created."; 
		// echoing JSON response 
		echo json_encode($response); 
		return true;
	
    } else { 
        // failed to insert row 
        $response["success"] = 0; 
        $response["message"] = "Oops! An error occurred inserting into Clients."; 
  
        // echoing JSON response 
        echo json_encode($response); 
    } 

?>

