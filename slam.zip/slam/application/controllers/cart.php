<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {

    function __construct() {
        parent:: __construct();
    }
   public function index(){
      if($this->cart->total_items()<1){
        redirect(base_url());
      }
      $this->controller_common();
        $this->data['view'] = 'cart_view';
        $this->load->view('theme/front/layout_iner', $this->data);

   }
   public function controller_common() {
        $this->data['menu'] = 'theme/front/menu';
        $this->data['header'] = 'theme/front/header';
        $this->data['footer'] = 'theme/front/footer';
        return $this;
    }
    public function order($id){
      $this->load->model('orders/orders_model');
        if($id){
       $orderdetail=$this->orders_model->get_order_detail($id);

      }

      if($orderdetail->user_id == '0' && $orderdetail->guest_id!='0'){
         $shipdetail = get_guest_userdetail($orderdetail->guest_id);

         if($shipdetail->guest_id!='0'){
            $userdetail =get_guest_userdetail($shipdetail->guest_id);
         }else{
          $userdetail = $shipdetail;
         }
      }
      if($orderdetail->user_id != '0' && $orderdetail->guest_id != '0'){
          $userdetail =get_customer_billing_detail($orderdetail->user_id);
          $shipdetail = get_guest_userdetail($orderdetail->guest_id);
       }
       if($orderdetail->user_id != '0' && $orderdetail->guest_id == '0'){
          $userdetail =get_customer_billing_detail($orderdetail->user_id);
          $shipdetail=$userdetail;
       }



      $orderproductdetail=$this->orders_model->get_product_detail($id);

      $this->data['orderproductdetail'] = $orderproductdetail;
      $this->data['userdetail'] = $userdetail;
      $this->data['shipdetail'] = $shipdetail;
      $this->data['orderdetail'] = $orderdetail;
      $this->session->sess_destroy();
      $this->controller_common();
        $this->data['view'] = 'order_view';
        $this->load->view('theme/front/layout_iner', $this->data);

    }
           public function print_pdf($id){
     $this->load->model('orders/orders_model');
        if($id){
       $orderdetail=$this->orders_model->get_order_detail($id);

      }

      if($orderdetail->user_id == '0' && $orderdetail->guest_id!='0'){
         $shipdetail = get_guest_userdetail($orderdetail->guest_id);

         if($shipdetail->guest_id!='0'){
            $userdetail =get_guest_userdetail($shipdetail->guest_id);
         }else{
          $userdetail = $shipdetail;
         }
      }
      if($orderdetail->user_id != '0' && $orderdetail->guest_id != '0'){
          $userdetail =get_customer_billing_detail($orderdetail->user_id);
          $shipdetail = get_guest_userdetail($orderdetail->guest_id);
       }
       if($orderdetail->user_id != '0' && $orderdetail->guest_id == '0'){
          $userdetail =get_customer_billing_detail($orderdetail->user_id);
          $shipdetail=$userdetail;
       }



      $orderproductdetail=$this->orders_model->get_product_detail($id);

      require_once(APPPATH.'/tcpdf/config/tcpdf_config.php');
      require_once(APPPATH.'/tcpdf/tcpdf.php');
      // require_once(APPPATH.'tcpdf/examples/tcpdf_include.php');
       $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
       $pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('');
$pdf->SetTitle('EXCEPTIONAL INDIAN & BANGLADESHI FOOD');
$pdf->SetSubject('Receipt ');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, '60', PDF_HEADER_TITLE.'', PDF_HEADER_STRING, array(0,64,255), array(0,64,128));
$pdf->setFooterData(array(0,64,0), array(0,64,128));

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
  require_once(dirname(__FILE__).'/lang/eng.php');
  $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set default font subsetting mode
$pdf->setFontSubsetting(true);

// Set font
// dejavusans is a UTF-8 Unicode font, if you only need to
// print standard ASCII chars, you can use core fonts like
// helvetica or times to reduce file size.
$pdf->SetFont('dejavusans', '', 14, '', true);

// Add a page
// This method has several options, check the source code documentation for more information.
$pdf->AddPage();

// set text shadow effect
$pdf->setTextShadow(array('enabled'=>true, 'depth_w'=>0.2, 'depth_h'=>0.2, 'color'=>array(196,196,196), 'opacity'=>1, 'blend_mode'=>'Normal'));

// Set some content to print
 $pdfArray = array();
$top='<table cellpadding="1" cellspacing="1" border="0.5" style="text-align:center;">
  <tr>
    <th><small>Quantity</small></th>
    <th><small>Name</small></th>
    <th><small>Price</small></th>
    <th><small>Subtotal</small></th>
   </tr>';
   array_push($pdfArray, $top);

   foreach($orderproductdetail as $product){


      $html = '';
      $html =' <tr>
        <td><small>'.$product->qty.'</small></td>
        <td><small>'.$product->name.'</small><br/>';




      $html .= ' </td>
      <td><small>&pound; '.$product->price.'</small></td>
      <td><small>&pound; '.number_format($product->product_subtotal_price, 2).'</small></td>
      </tr>';
    array_push($pdfArray, $html);
 }
 $bottom ='</table>
   <table cellpadding="1" cellspacing="1" border="0.5" style="text-align:center;">
    <tr>

        <td  colspan="3" align="right"><small>Subtotal</small></td>
        <td><small>&pound;'. $orderdetail->pay.'</small></td>
    </tr>';
    array_push($pdfArray, $bottom);
  if(!empty($orderdetail->disct)) {
 $data ='<tr>
            <td  colspan="3" align="right"><small>Discount:</small></td>
            <td><small>&pound;-2.99</small></td>
        </tr>';
        array_push($pdfArray, $data);

  }
  if($orderdetail->preferece=='collection'){
    $data2 =' <tr>
                <td  colspan="3" align="right"><small>discount(15%off)</small></td>
                <td><small>&pound;'.$discount =  $orderdetail->pay - $orderdetail->order_total.'</small></td>
            </tr>';

 array_push($pdfArray, $data2);
  }
   $data1 =' <tr>
                <td  colspan="3" align="right"><small>Total</small></td>
                <td><small>&pound;'.$orderdetail->order_total.'</small></td>
            </tr>
              </table>';
    array_push($pdfArray, $data1);
   $table = implode(" ", $pdfArray);
$html = <<<EOD
{$table}
EOD;

// Print text using writeHTMLCell()
$pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);

$html = <<<EOD
<label><small><b>Payment Method : </b> Stripe</small>  </label><br/>

<label><small><b>Customer Name :  </b> {$userdetail->first_name} {$userdetail->last_name }</small>  </label><br/>
<label><small><b> Order : </b> {$orderdetail->preferece} </small></label> <br/>
<label><small><b> Address : </b></small>

                            <small><b>{$userdetail->title} {$shipdetail->first_name} {$shipdetail->last_name}</small></b><br/>
                            <small>{$shipdetail->address1}</small><br/>
                            <small>{$shipdetail->city}</small><br/>
                            <small>{$shipdetail->post_code}</small><br/>
                            <small>{$shipdetail->phone_no},{$shipdetail->phone2}</small><br/>
                            <small>United Kingdom</small></br>

                        </label>

EOD;


$pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
// ---------------------------------------------------------

// Close and output PDF document
// This method has several options, check the source code documentation for more information.
$pdf->Output('example_001.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+





    }

	public function add_cart(){
	  $product_id =   $this->input->post('product_id');
	  $productDetail = get_product_detail($product_id);
	   $attr_status =  $this->input->post('attr_status');
	   $pro_variation = $this->input->post('pro_variation');
	   $qty = $this->input->post('qty');
	   //$option = get_product_attribute($option_id);
	   if($attr_status== 0){

	   		$price = $productDetail->price;
	   		 $data = array(
               'id'      => $product_id,
               'qty'     => $qty,
               'price'   => $price,
               'name'    => $productDetail->title,

            );
	   }else{
     $i=0;
     $attrid = array();
     $attrprice = array();
      foreach($pro_variation as $variation){
        if(!empty($variation)){
              $variationarray = explode("_",$variation);
             $attrid[$i] = get_attribute_name($variationarray[1]);
              $attibute_detail = get_product_attribute($variationarray[2]);
              $attrprice[]=$attibute_detail->price;
               $attrid[$i]->attr = $attibute_detail;
       }
       ++$i;
      }

    $att_price = array_sum($attrprice);
      if($att_price!=0.00){

        $price = $att_price;

      }else{
        $price = $productDetail->price;
      }


	    $data = array(
               'id'      => $product_id,
               'qty'     => $qty,
               'price'   => $price,
               'name'    => $productDetail->title,
               'options' => array(
               	'attrdetail' => $pro_variation,

               	)
            );
	   }

		$this->cart->insert($data);
		$html = $this->load->view('cart_html',$data, TRUE);
          $response = new stdClass();
          $response->html = trim($html);

          $response->status = 'success';

          echo json_encode($response);

          die;

	}
  public function delete_cart(){
      $row_id = $this->input->post('id');
      $data = array(
               'rowid' => $row_id,
               'qty'   => 0
            );

      $this->cart->update($data);
      $html = $this->load->view('cart_html',$data, TRUE);
      $response = new stdClass();
      $response->html = trim($html);
      $response->status = 'success';
      echo json_encode($response);
       die;
  }
  public function remove_cart(){
    $row_id = $this->input->post('id');
      $data = array(
               'rowid' => $row_id,
               'qty'   => 0
            );

      $this->cart->update($data);
       $response = new stdClass();
      $response->subtotal = '&pound;'.$this->cart->total();
      $response->totalitem = 'Shopping Cart('.$this->cart->total_items().')';
      $response->status = 'success';
      echo json_encode($response);
       die;

  }
  public function edit_cart(){
    $row_id = $this->input->post('id');
    $qty    = $this->input->post('qty');
    $price  = explode("£",$this->input->post('price'));
   $price1 =$price[1]*$qty;
    $data = array(
               'rowid' => $row_id,
               'qty'   => $qty
            );

      $this->cart->update($data);
       $response = new stdClass();
      $response->subtotal = '&pound;'.$this->cart->total();
      $response->totalitem = 'Shopping Cart('.$this->cart->total_items().')';
      $response->totalprice = '&pound;'.$price1;
      $response->status = 'success';
      echo json_encode($response);
       die;
  }
  public function update_cart(){
       $row_id = $this->input->post('id');
        $qty = $this->input->post('qty');
      $data = array(
               'rowid' => $row_id,
               'qty'   => $qty
            );

      $this->cart->update($data);
      $html = $this->load->view('cart_html',$data, TRUE);
      $response = new stdClass();
      $response->html = trim($html);
      $response->status = 'success';
      echo json_encode($response);
       die;

  }

}
