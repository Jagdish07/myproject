<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Checkout extends CI_Controller {

    function __construct() {
        parent:: __construct();
        $this->load->model('checkout_model');
    }

    public function index(){
     // print_R($_POST); die;
      $newdata = array(
                   'comment'  => $this->input->post('comment'),
               );

        $this->session->set_userdata($newdata);
       if($this->cart->total_items()<1){
        redirect(base_url());
      }
        $this->controller_common();
        $this->data['view'] = 'checkout_view';
        $this->load->view('theme/front/layout', $this->data);

   }
   public function guestuser(){

    $result = $this->checkout_model->insert_data();
    redirect(base_url('payment/'.$result));

   }
   public function check(){
 //


//	print"<pre>";print_r($this->session->all_userdata());die;
    $setting = get_setting();
  //  print"<pre>";print_r($this->input->post('payment'));die;


    $total= $this->cart->total();
    if($this->input->post('payment')!='') {
    if($this->input->post('payment')=='delivery'){
    if($setting->max_item < $total){
      if($this->input->post('id')==0){
         $status = 1;
		$payment_mode= $this->input->post('payment');
		//echo $payment_mode;die;
		$payment_mode= array('payment'=>$payment_mode);
		$this->session->set_userdata($payment_mode);
      }
       if($this->input->post('id')==1){
         $status = 2;
      }

    }


    else{


      $status = 0;
    }
  }
  if($this->input->post('payment')=='pickup'){
    if($total > 5){
      if($this->input->post('id')==0){
         $status = 1;
    $payment_mode= $this->input->post('payment');
    //echo $payment_mode;die;
    $payment_mode= array('payment'=>$payment_mode);
    $this->session->set_userdata($payment_mode);
      }
       if($this->input->post('id')==1){
         $status = 2;
      }
    }
    else{
      $status = 3;
    }
  }
}
else{

  if($setting->max_item < $total){
    if($this->input->post('id')==0){
       $status = 1;
  $payment_mode= $this->input->post('payment');
  //echo $payment_mode;die;
  $payment_mode= array('payment'=>$payment_mode);
  $this->session->set_userdata($payment_mode);
    }
     if($this->input->post('id')==1){
       $status = 2;
    }

  }


  else{
    $status = 0;
  }

}
    echo $status;
 die;

   }
   public function discount_check(){
    $code=$this->input->post('value');
    $result =$this->checkout_model->validate_coupon($code);
    $response = new stdClass();
    if(!empty($result)){
      $total =$this->cart->total();
      $discount = $total*$result->discount/100;
      $discountprice = $total-$discount;
      $response->discount = number_format($discount,2);
      $response->discountpercent = $result->discount;
      $response->discountprice= number_format($discountprice,2);
      $response->status= 'success';
      echo json_encode($response);

    }else{
      $response->status= 'error';
      $response->alert ='discount code not valid';
      echo json_encode($response);

    }
    die;

   }
   public function process(){
    $result= $this->checkout_model->login_users();
        if(!$result){
        $this->session->set_flashdata('messagecartlogin','<div class="alert alert-danger">User Name,Password is Invalid. Please Try Again!<button class="close" data-dismiss="alert">×</button></div>');
         redirect(base_url('checkout'));

      }else{
        $data = array(
           'slamfrontuser_id'  => $result->id,
          'slamfrontuser_name' => $result->first_name,
          'slamfrontlast_name' =>$result->last_name,
          'slamfrontemail' => $result->email,
          'slamfrontlogged_in' => TRUE
        );
        $this->session->set_userdata($data);
          $this->session->set_flashdata('successmessage','<div class="alert alert-success">Login Successfully<button class="close" data-dismiss="alert">×</button></div>');
        redirect(base_url('checkout'));
        }
  }
   public function checkpostcode(){
      $result = $this->checkout_model->checkpostcode();
      if(!$result){
        $error = false;
      } else {
        $error =true;
      }
      echo json_encode($error);
      die;

    }
   public function controller_common() {
        $this->data['menu'] = 'theme/front/menu';
        $this->data['header'] = 'theme/front/header';
        $this->data['footer'] = 'theme/front/footer';
        return $this;
    }
}
