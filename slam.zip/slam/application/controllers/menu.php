<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller {

    function __construct() {
        parent:: __construct();
        $this->load->model('category_model');
        $this->load->model('page_model');
    }

    public function index() {
  //  print"<pre>"; print_R($this->cart->contents());
        $this->controller_common();
       // $this->data['category'] = $this->category_model->get_category();
        $this->data['view'] = 'menu_view';
        $this->load->view('theme/front/layout', $this->data);
    }

     public function chef() {
        $this->controller_common();
        $this->data['view'] = 'chef_view';
        $this->load->view('theme/front/layout', $this->data);
    }

     public function team() {
        $this->controller_common();
        $this->data['view'] = 'team_view';
        $this->load->view('theme/front/layout', $this->data);
    }

    public function searchdata(){
      $this->data['category'] = $this->category_model->get_data();
      //print_R($data); die;
      $html = $this->load->view('dynamic',$this->data, TRUE);
      print_R($html); die;
      $response = new stdClass();
      $response->html = trim($html);
      $response->status = 'success';
      echo json_encode($response);
      die;
     

     
    }
    public function contact_us() {
      $this->data['contact_us_page'] = $this->page_model->get_contact_data();
      if($this->input->post()) {
      $this->form_validation->set_rules('full_name', 'Full Name', 'required|trim|xss_clean');
      $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
      $this->form_validation->set_rules('message', 'Message', 'required|trim|xss_clean');
      if($this->form_validation->run() == FALSE) {
       
       // redirect(base_url('menu/contact_us'));
      } else {
        $message = "<table>
                    <tr>
                      <th>Name</th>
                      <td>".$this->input->post('name')."</td>
                    </tr>
                    <tr>
                      <th>Email</th>
                      <td>".$this->input->post('email')."</td>
                    </tr>
                    <tr>
                      <th>Message</th>
                      <td>".$this->input->post('message')."</td>
                    </tr>
                  </table>";
        
        $config = Array(
          'protocol' => 'smtp',
          'smtp_host' => 'ssl://server1.smlservers.co.uk',
          'smtp_port' => 465,
          'smtp_user' => 'noreply@anything4home.co.uk',
          'smtp_pass' => 'noreply',
          'mailtype'  => 'html', 
          'charset'   => 'iso-8859-1'
        );
        $this->load->library('email');  
        $this->email->initialize($config);
        $this->email->from("noreply@anything4home.co.uk", "Miiaan");
        $this->email->to('smlsolutions.co.uk'); 
        $this->email->subject('Contact Form Enquiry');
        $this->email->message($message);  
        $this->email->send();
        $this->session->set_flashdata('message', '<strong>Success!</strong> Your Message Is Successfully Sent.');
        redirect(base_url('menu/contact_us'));
      }
    }
        $this->controller_common();
        $this->data['view'] = 'contact_view';
        $this->load->view('theme/front/layout', $this->data);
    }
     public function menu_data(){
        $id=$this->input->post('value');
      $data = get_attr_name($id);
     echo $price = '&pound'.$data->price;
die;
     }
    public function controller_common() {
        $this->data['menu'] = 'theme/front/menu';
        $this->data['header'] = 'theme/front/header';
        $this->data['footer'] = 'theme/front/footer';
        return $this; 
    }

}
