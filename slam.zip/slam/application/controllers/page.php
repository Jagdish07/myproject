<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(E_ALL);
class Page extends CI_Controller {
	function __construct(){
		parent:: __construct();
		$this->load->model('page_model');
		
	}
	public function index($page){
		$contactdetail = $this->page_model->get_by_url($page)->row();
		if(!empty($contactdetail)){
			$this->data['meta_details'] = $contactdetail;
	   }else{
	   	$this->data['meta_details'] = '';
	   }
	    $this->data['page'] = $page;
		$this->data['view'] = 'page_view';
		$this->_render_page('theme/front/layout', $this->data);
	}

	public function gallery(){
        $this->data['gallery'] = $this->page_model->get_gallery();
		$this->data['view'] = 'gallery_view';
		$this->_render_page('theme/front/layout', $this->data);

	}
	public function contact_us(){
		
	
	if($this->input->post()) {
			$this->form_validation->set_rules('full_name', 'Full Name', 'required|trim|xss_clean');
			$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
			$this->form_validation->set_rules('message', 'Message', 'required|trim|xss_clean');
			if($this->form_validation->run() == FALSE) {
				
			} else {
				$message = "<table>
										<tr>
											<th>Name</th>
											<td>".$this->input->post('name')."</td>
										</tr>
										<tr>
											<th>Email</th>
											<td>".$this->input->post('email')."</td>
										</tr>
										<tr>
											<th>Message</th>
											<td>".$this->input->post('message')."</td>
										</tr>
									</table>";
				
				$config = Array(
					'protocol' => 'smtp',
					'smtp_host' => 'ssl://server1.smlservers.co.uk',
					'smtp_port' => 465,
					'smtp_user' => 'noreply@anything4home.co.uk',
					'smtp_pass' => 'noreply',
					'mailtype'  => 'html', 
					'charset'   => 'iso-8859-1'
				);
				$this->load->library('email');	
				$this->email->initialize($config);
				$this->email->from("noreply@anything4home.co.uk", "Miiaan");
				$this->email->to('ruchinainwal1947@gmail.com'); 
				$this->email->subject('Contact Form Enquiry');
				$this->email->message($message);	
				$this->email->send();
				$this->session->set_flashdata('message', '<strong>Success!</strong> Your Message Is Successfully Sent.');
				redirect(base_url('page/contact-us'));
			}
		}
	
	}
	
	public function _render_page($view, $data=null, $render=false){
		$this->viewdata = (empty($data)) ? $this->data: $data;
		$view_html = $this->load->view($view, $this->viewdata, $render);
		if (!$render) return $view_html;
	}
	}