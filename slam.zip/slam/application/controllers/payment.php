<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(E_ALL);
class Payment extends CI_Controller {
	private $stripe = array(
			'secret_key'      => 'sk_test_XNi1VhH99oBCr9em1pHfNL3W',
			'publishable_key' => 'pk_test_xKk3YNW6PGrzYwHzxDGLBH5N'
	);
	
/*	private $stripe = array(
			'secret_key'      => 'sk_live_9JZEvdsUxg2YFxnH2JGEPslS',
			'publishable_key' => 'pk_live_akRQAsBbTE9624mIBUccvcBo'
	);*/
	
	function __construct(){
		parent:: __construct();
		
		$this->load->model('checkout_model');

		require_once 'stripe/lib/Stripe.php';
		
	}
	public function index($id)
	{  

		Stripe::setApiKey($this->stripe['secret_key']);
		
		 $this->controller_common();
		$orderdetail=$this->checkout_model->order_detail($id);
		 $this->data['orderdetail'] = $orderdetail;
		 $this->data['stripe'] = $this->stripe;
         $this->data['view'] = 'payment_view';
        $this->load->view('theme/front/layout',$this->data);
	}
	public function charge(){
	 
		Stripe::setApiKey($this->stripe['secret_key']);

		$orderid =$this->input->post('orderid');
		$price =$this->input->post('planPrice')*100;
		$token = $this->input->post('stripeToken');
		$email= $this->input->post('stripeEmail');
	
		$charge = Stripe_Charge::create(array(
			'card'     => $token,
			'amount'   => $price,
			'currency' => 'GBP'
		));
		
		
     	if(!empty($charge)) {
     		$data = array(
				'charge_id' => $charge['id'],
				'order_id' =>$orderid,
				'email' =>$email,
				'Payment_Date'=>date('Y-m-d'),
				'amt'=> $charge['amount']/100,
			);
		
			$subs = $this->checkout_model->saveSubscriptionDetail($data);
			if($subs){
				$this->session->set_flashdata('message','<div class="flash-success">Plan Subscription Successfully Done!</div>');
				redirect('cart/order/'.$orderid);
			}
     	} else {
     		echo "not possible";die;
     	}

	}
	public function controller_common() {
        $this->data['menu'] = 'theme/front/order_layout/menu';
        $this->data['header'] = 'theme/front/order_layout/header';
        $this->data['footer'] = 'theme/front/order_layout/footer';
        return $this; 
    }
}