<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

    function __construct() {
        parent:: __construct();
        $this->load->model('register_model');
    }

    public function index(){
      $this->controller_common();
        $this->data['view'] = 'login_view';
        $this->load->view('theme/front/layout', $this->data);

   }
   public function process(){
    $result= $this->register_model->login_users();
    $this->form_validation->set_rules('email','Email','required|xss_clean');
    $this->form_validation->set_rules('Password','Password','required|xss_clean');
      if(!$result){
        $this->session->set_flashdata('messagelogin','<div class="alert alert-danger">User Name,Password is Invalid. Please Try Again!<button class="close" data-dismiss="alert">×</button></div>');
         redirect(base_url('register')); 
    
      }else{
        $data = array(
          'slamfrontuser_id'  => $result->id,
          'slamfrontuser_name' => $result->first_name,
          'slamfrontlast_name' =>$result->last_name,
          'slamfrontemail' => $result->email,
          'slamfrontlogged_in' => TRUE
        );
        $this->session->set_userdata($data);
        redirect(base_url());
        }

   }
   public function user(){
      if($this->input->post()){
        $rigester_user = $this->register_model->insert_userdata();
         $config = Array(
          'protocol' => 'smtp',
          'smtp_host' => 'ssl://server1.smlservers.co.uk',
          'smtp_port' => 465,
          'smtp_user' => 'info@smlsolutions.co.uk',
          'smtp_pass' => 'noreply',
          'mailtype'  => 'html', 
          'charset'   => 'iso-8859-1'
        );
          $this->load->library('email');  
        $this->email->initialize($config);
        $this->email->from("info@smlsolutions.co.uk", "slam");
        $this->email->to($this->input->post('email'));       
        $this->email->subject('Register');  
        $message='<p>Hello '.$this->input->post('fname').',<br />
      <br />
      Thank you for registering at slam. Your account is created and you can use it.<br />
      </p>
    <div class="a3s" id=":1br">
      <br />
       you may login to '.base_url('slam/register').' using the following username and password:<br />
      <br />
      Username: '.$this->input->post('username').'<br />
      Password: '.$this->input->post('password1').'</div>';
        $this->email->message(trim($message));  
        $this->email->send();
        $this->session->set_flashdata('successmessage','<div class="alert alert-success">Your account has been Created Check Your Email Please <button class="close" data-dismiss="alert">×</button></div>');
        redirect(base_url('register/user'));

      }
      $this->controller_common();
        $this->data['view'] = 'register_view';
        $this->load->view('theme/front/layout', $this->data);

   }
   public function forgetpassword(){
    
    if($this->session->userdata('logged_in')==true){
      redirect('account');
    }
      $result = $this->register_model->forget_password();
      if(!$result){
    
         $this->session->set_flashdata('mess','<div class="alert alert-danger">Forget Email is Invalid. Please Try Again!<button class="close" data-dismiss="alert">×</button></div>');
         redirect(base_url('register')); 
      
      } else {
      
        
        $config = Array(
          'protocol' => 'smtp',
          'smtp_host' => 'ssl://server1.smlservers.co.uk',
          'smtp_port' => 465,
          'smtp_user' => 'noreply@anything4home.co.uk',
          'smtp_pass' => 'noreply',
          'mailtype'  => 'html', 
          'charset'   => 'iso-8859-1'
        );
        $this->load->library('email');  
        $this->email->initialize($config);
        $this->email->from("smlsolutions.co.uk", "slam Chicken");
        $this->email->to(trim($this->input->post('email')));      
        $this->email->subject('Forget Password'); 
        $password = rand();
        $message='<p>
             Hello,<br />
              <br />
          A username reminder has been requested for your slam, Takeaway Menu account.<br />
     <br />
        Your username is '.$result->email.'<br />
        Your password is '.$password.'<br />
    <br />
     To login to your account, click on the link below.<br />
      <br />
     <br />
      Thank you.</div>';
        $this->email->message(trim($message));
        if($this->email->send()){
          $data = array();
          $data['password'] = md5($password);
          $result = $this->register_model->update_password($result->id,$data);
            if($result){
              $this->session->set_flashdata('mess','<div class="alert alert-success">Thanks .Please check your email we have send you login details!<button class="close" data-dismiss="alert">×</button></div>');
               redirect(base_url('login')); 
            }
        }else{
        echo"bbn"; die;
        }       
      }
  }
  public function logout(){
      $this->session->sess_destroy();
     redirect(base_url());
  } 
   public function checkemail(){

    if($this->session->userdata('logged_in')==true){
      redirect('account');
    }
    $result = $this->register_model->checkemail();
       if(!$result){
        $error = true;
      } else {
        $error =false;    
      }
      echo json_encode($error);
      die;
  }

    public function controller_common() {
        $this->data['menu'] = 'theme/front/menu';
        $this->data['header'] = 'theme/front/header';
        $this->data['footer'] = 'theme/front/footer';
        return $this; 
    }

}