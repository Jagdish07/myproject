<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    function __construct() {
        parent:: __construct();
         $this->load->model('welcome_model');
    }

    public function index() {
        $this->controller_common();
        // $this->load->model('welcome_model');
        $this->data['banner']=$this->welcome_model->get_banner();
       
        $this->data['view'] = 'welcome_view';
        $this->load->view('theme/front/layout', $this->data);
    }
    
    public function controller_common() {
        $this->data['menu'] = 'theme/front/menu';
        $this->data['header'] = 'theme/front/header';
        $this->data['footer'] = 'theme/front/footer';
        return $this; 
    }

}
