<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}
// ------------------------------------------------------------------------

/**
 * Script
 *
 * Generates link to a Script file
 *
 * @access	public
 * @param	mixed	Script src's or an array
 * @param	string	language
 * @param	string	type
 * @param	string	title
 * @param	boolean	should index_page be added to the script path
 * @return	string
 */
if (!function_exists('script_tag')) {

    function script_tag($src = '', $language = 'javascript', $type = 'text/javascript', $index_page = FALSE) {
        $CI = & get_instance();

        $script = '<script ';

        if (is_array($src)) {
            foreach ($src as $k => $v) {
                if ($k === 'src' AND strpos($v, '://') === FALSE) {
                    if ($index_page === TRUE) {
                        $script .= 'src="' . $CI->config->site_url($v) . '" ';
                    } else {
                        $script .= 'src="' . $CI->config->slash_item('base_url') . $v . '" ';
                    }
                } else {
                    $script .= "$k=\"$v\" ";
                }
            }

            $script .= "></script>";
        } else {
            if (strpos($src, '://') !== FALSE) {
                $script .= 'src="' . $src . '" ';
            } elseif ($index_page === TRUE) {
                $script .= 'src="' . $CI->config->site_url($src) . '" ';
            } else {
                $script .= 'src="' . $CI->config->slash_item('base_url') . $src . '" ';
            }

            $script .= 'language="' . $language . '" type="' . $type . '" ';

            $script .= '></script>';
        }


        return $script;
    }

}


/*
 * Default used function
 */

/*
 * Get all the default user defined properties (Not Used)
 */
if (!function_exists('_properties')) {

    function _properties() {
        $ci = & get_instance();
        $properties = $ci->config->item('properties');
        return $properties;
    }

}
/*
 * Default used function
 */

/*
 * Get the site name
 */
if (!function_exists('site_name')) {

    function site_name() {
        $properties = _properties();
        $site_name = $properties->properties;
        return $site_name->site_name;
    }

}
//-----------------------------------------------------------------------
/*
 * Get module name (Used)
 */
if (!function_exists('get_module_name')) {

    function get_module_name() {
        $ci = & get_instance();
        return $ci->router->fetch_module();
    }

}

if (!function_exists('get_module')) {

    function get_module() {

        $CI =& get_instance();
       $role_id = $CI->session->userdata('slamroles');
          $CI->db->select('tbl_modules_roles.module_id,tbl_modules.module_name'); // you can write other fields using comma
          $CI->db->from("tbl_modules_roles");
          $CI->db->join("tbl_modules",'tbl_modules.id = tbl_modules_roles.module_id','LEFT');
          $CI->db->where('tbl_modules_roles.role_id',$role_id);
         $result  =$CI->db->get()->result();
         $modules='';
          if($result) {
            $modules = array();
            foreach ($result as $key => $value) {
              $modules[$value->module_id] = $value->module_name;
            }
          }
          return $modules;

    }

}


if (!function_exists('Myfunction')) {
function Myfunction(){
    $CI =& get_instance();
      $class = $CI->router->fetch_class();
      $not_used_class = array('admin', 'auth','build_list');
      if(!in_array($class, $not_used_class)) {
          $role_id = $CI->session->userdata('slamroles');
          $CI->db->select('tbl_modules_roles.module_id,tbl_modules.module_name'); // you can write other fields using comma
          $CI->db->from("tbl_modules_roles");
          $CI->db->join("tbl_modules",'tbl_modules.id = tbl_modules_roles.module_id','LEFT');
          $CI->db->where('tbl_modules_roles.role_id',$role_id);
          $result = $CI->db->get()->result();
          if($result) {
            $modules = array();
            foreach ($result as $key => $value) {
              $modules[$value->module_id] = $value->module_name;
            }
          }

          if(!in_array($class, $modules)) {
            redirect(base_url('admin'));
          }
      }

   }
}
//-----------------------------------------------------------------------
/*
 * Get class method (Used)
 */
if (!function_exists('get_method')) {

    function get_method() {
        $ci = & get_instance();
        return $ci->router->fetch_method();
    }

}

//--------------------------------------------------------------------------------------
/*
 * Check user login (Not Used)
 */
if (!function_exists('is_login')) {

    function is_login() {
        $ci = & get_instance();
        $ci->load->library('auth/ion_auth');
        if (!$ci->ion_auth->logged_in()) {
            redirect('auth/login', 'refresh');
        }
    }

}
//--------------------------------------------------------------------------------------
/*
 * Check user login (Not Used)
 */
if (!function_exists('is_admin')) {

    function is_admin() {
        $ci = & get_instance();
        $ci->load->library('auth/ion_auth');
        if (!$ci->ion_auth->is_admin()) {
            return show_error('You must be an administrator to view this page.');
        }
    }

}
//--------------------------------------------------------------------------------------
/*
 * Get all the default user defined properties (Used)
 */
if (!function_exists('get_properties')) {

    function get_properties() {
        $ci = & get_instance();
        $properties = _properties()->properties;
        return $properties;
    }

}
/*
 * Get all the default user defined asstes (Used)
 */
if (!function_exists('get_assets')) {

    function get_assets() {
        $ci = & get_instance();
        $properties = _properties()->properties;
        return $properties->assets;
    }

}
/*
 * Dump array data (Used)
 * @Params Array
 * @Return print all data
 */
if (!function_exists('dump')) {

    function dump($array) {
        print "<pre>";
        print_r($array);
        die;
    }

}
/*
 * Link front css (Used)
 * @Params Array (css files)
 * @Return link all css files
 */
if (!function_exists('link_front_css')) {

    function link_front_css($css_files) {
        $css = '';
        $assets = get_assets();
        if (is_array($css_files)) {
            foreach ($css_files as $css_file) {
                $css .= link_tag($assets->front_assets->css_path . $css_file);
            }
        } else {
            $css = link_tag($assets->front_assets->css_path . $css_files);
        }
        return $css;
    }

}
/*
 * Link admin css (Used)
 * @Params Array (css files)
 * @Return link all css files
 */
if (!function_exists('link_admin_css')) {

    function link_admin_css($css_files) {
        $css = '';
        $assets = get_assets();
        if (is_array($css_files)) {
            foreach ($css_files as $css_file) {
                $css .= link_tag($assets->admin_assets->css_path . $css_file);
            }
        } else {
            $css = link_tag($assets->admin_assets->css_path . $css_files);
        }
        return $css;
    }

}
/*
 * Link admin script (Used)
 * @Params Array (script files)
 * @Return link all script files
 */
if (!function_exists('link_admin_js')) {

    function link_admin_js($js_files) {
        $script = '';
        $assets = get_assets();
        if (is_array($js_files)) {
            foreach ($js_files as $js_file) {
                $script .= script_tag($assets->admin_assets->js_path . $js_file);
            }
        } else {
            $script = script_tag($assets->admin_assets->js_path . $js_files);
        }
        return $script;
    }

}
/*
 * Link front script (Used)
 * @Params Array (script files)
 * @Return link all script files
 */
if (!function_exists('link_front_js')) {

    function link_front_js($js_files) {
        $script = '';
        $assets = get_assets();
        if (is_array($js_files)) {
            foreach ($js_files as $js_file) {
                $script .= script_tag($assets->front_assets->js_path . $js_file);
            }
        } else {
            $script = script_tag($assets->front_assets->js_path . $js_files);
        }
        return $script;
    }

}
/*
 * Link admin module script (Used)
 * @Params Array (script files)
 * @Return link all script files
 */
if (!function_exists('link_admin_module_js')) {

    function link_admin_module_js($js_files, $module) {
        $script = '';
        $properties = get_properties();
        if (is_array($js_files)) {
            foreach ($js_files as $js_file) {
                $script .= script_tag($module . '/' . $properties->module_js_path . $js_file);
            }
        } else {
            $script = script_tag($module . '/' . $properties->module_js_path . $js_files);
        }
        return $script;
    }

}
/*
 * Link admin module css (Used)
 * @Params Array (css files)
 * @Return link all css files
 */
if (!function_exists('link_admin_module_css')) {

    function link_admin_module_css($css_files, $module) {
        $css = '';
        $properties = get_properties();
        if (is_array($css_files)) {
            foreach ($css_files as $css_file) {
                $css .= link_tag($module . '/' . $properties->module_css_path . $css_file);
            }
        } else {
            $css = link_tag($module . '/' . $properties->module_css_path . $css_files);
        }
        return $css;
    }

}

/*
 * Link admin image (Used)
 * @Params Image (String)
 * @Return Image with path
 */
if (!function_exists('link_admin_image')) {

    function link_admin_image($image) {
        $assets = get_assets();
        $image_with_path = $assets->admin_assets->img_path . $image;
        return $image_with_path;
    }

}

/*
 * Link front image (Used)
 * @Params Image (String)
 * @Return Image with path
 */
if (!function_exists('link_front_image')) {

    function link_front_image($image) {
        $assets = get_assets();
        $image_with_path = $assets->front_assets->img_path . $image;

        return $image_with_path;
    }

}
// ------------------------------------------------------------------------

/**

 * Get lang Costants
 *
 *
 * @access	public
 * @param	variable
 * @return	define string
 */
if (!function_exists('lang')) {

    function lang($string) {
        $anything->ci = & get_instance();
        $lang = $anything->ci->lang->line($string);
        return $lang;
    }

}
if (!function_exists('build_pagingation')) {

    function build_pagination($lastpage, $page, $next, $prev, $lpm1, $field) {
        $targetpage = 'page';
        $idString = 'page__' . $field . '__';
        $pagination = "";
        $adjacents = 1;
        if ($page == '') {
            $page = 1;
        }
        if ($lastpage > 1) {

            $pagination .= "<ul class=\"pagination pagination_1\">";

            if ($page > 1) {
                $pagination.= "<li><a href=\"$targetpage/$prev\" id=\"$idString$prev\"><span class=\"glyphicon glyphicon-chevron-left\"></span> Prev</a></li>";
            } else {
                $pagination.= "<li class=\"disabled\"><span><span class=\"glyphicon glyphicon-chevron-left\"></span> Prev</span></li>";
            }

            if ($lastpage < 7 + ($adjacents * 2)) {

                for ($counter = 1; $counter <= $lastpage; $counter++) {
                    if ($counter == $page) {
                        $pagination.= "<li class=\"active\"><span>$counter</span></li>";
                    } else {
                        $pagination.= "<li><a href=\"$targetpage/$counter\" id=\"$idString$counter\">$counter</a></li>";
                    }
                }
            } elseif ($lastpage > 5 + ($adjacents * 2)) {

                if ($page < 1 + ($adjacents * 2)) {

                    for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++) {
                        if ($counter == $page) {
                            $pagination.= "<li class=\"active\"><span>$counter</span></li>";
                        } else {
                            $pagination.= "<li><a href=\"$targetpage/$counter\" id=\"$idString$counter\">$counter</a></li>";
                        }
                    }

                    $pagination.= "<li><a>...</a></li>";
                    $pagination.= "<li><a href=\"$targetpage/$lpm1\" id=\"$idString$lpm1\">$lpm1</a></li>";
                    $pagination.= "<li><a href=\"$targetpage/$lastpage\" id=\"$idString$lastpage\">$lastpage</a></li>";
                } elseif ($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2)) {
                    if ($page == 1) {
                        $pagination.= "<li class=\"active\"><span>1</span></li>";
                    } else {
                        $pagination.= "<li><a href=\"$targetpage/1\" id='" . $idString . "1'>1</a></li>";
                    }
                    if ($page == 2) {
                        $pagination.= "<li class=\"active\"><span>2</span></li>";
                    } else {
                        $pagination.= "<li><a href=\"$targetpage/2\" id='" . $idString . "2'>2</a></li>";
                    }
                    $pagination.= "<li><a>...</a></li>";

                    for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++) {
                        if ($counter == $page) {
                            $pagination.= "<li class=\"active\"><span>$counter</span></li>";
                        } else {
                            $pagination.= "<li><a href=\"$targetpage/$counter\" id=\"$idString$counter\">$counter</a></li>";
                        }
                    }

                    $pagination.= "<li><a>...</a></li>";
                    $pagination.= "<li><a href=\"$targetpage/$lpm1\" id=\"$idString$lpm1\">$lpm1</a></li>";
                    $pagination.= "<li><a href=\"$targetpage/$lastpage\" id=\"$idString$lastpage\">$lastpage</a></li>";
                } else {

                    $pagination.= "<li><a href=\"$targetpage/1\" id='" . $idString . "1'>1</a></li>";
                    $pagination.= "<li><a href=\"$targetpage/2\" id='" . $idString . "2'>2</a></li>";
                    $pagination.= "<li><a>...</a></li>";
                    for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++) {
                        if ($counter == $page) {
                            $pagination.= "<li class=\"active\"><span>$counter</span></li>";
                        } else {
                            $pagination.= "<li><a href=\"$targetpage/$counter\" id=\"$idString$counter\">$counter</a></li>";
                        }
                    }
                }
            }

            if ($page < $lastpage) {
                $pagination.= "<li><a href=\"$targetpage/$next\" id=\"$idString$next\">Next <span class=\"glyphicon glyphicon-chevron-right\"></span></a></li>";
            } else {
                $pagination.= "<li class=\"disabled\"><span>Next<span class=\"glyphicon glyphicon-chevron-right\"></span></span></li>";
                $pagination.= "</ul>\n";
            }
        }

        return $pagination;
    }

}

if (!function_exists('request_params')) {

    function request_params($num_records, $sort, $order, $limit, $page, $start, $field) {
        $params = new stdClass();
        $params->num_records = $num_records;
        $params->sort = $sort;
        $params->order = $order;
        $params->limit = $limit;
        $params->current_page = $page;
        $params->next_page = $page + 1;
        $params->prev_page = $page - 1;
        $params->total_pages = ceil($num_records / $limit);
        $params->start_page = $start;
        $params->last_page = ceil($num_records / $limit);
        $params->lpm1 = $params->last_page - 1;
        $params->field = $field;
        return $params;
    }

}
/**
 * set user define limit to the query
 *
 *
 * @access	public
 * @param	page and limit
 * @return	response object
 */
if (!function_exists('set_limit')) {

    function set_limit($page = false, $limit) {
        if (!$limit) {
            $limit = 10;
        }
        if ($page) {
            $start = ($page - 1) * $limit;    //first item to display on this page
        } else {
            $start = 0;
        }
        $queryString = " LIMIT " . $start . ", " . $limit;

        $response = new stdClass();
        $response->query_string = $queryString;
        $response->limit = $limit;
        $response->page = $page;
        $response->start = $start;

        return $response;
    }

}
/**
 * set user define order by to the query
 *
 *
 * @access	public
 * @param	sort and order
 * @return	response object
 */
if (!function_exists('set_order')) {

    function set_order($sort = false, $order = false) {
        if ($sort) {
            $queryString = " ORDER BY " . $sort . " DESC";
            $order = 'DESC';
            if ($order) {
                $queryString = " ORDER BY " . $sort . $order;
            }
        } else if ($order) {
            $queryString = " ORDER BY id " . $order;
            $sort = 'id';
        } else {
            $queryString = " ORDER BY id DESC";
            $order = 'DESC';
            $sort = 'id';
        }

        $response = new stdClass();
        $response->query_string = $queryString;
        $response->sort = $sort;
        $response->order = $order;

        return $response;
    }

}
// ------------------------------------------------------------------------

/**
 * set auto increment by last number
 *
 *
 * @access	public
 * @param	table
 * @return	true
 */
if (!function_exists('alter_auto_increment')) {

    function alter_auto_increment($table, $field) {
        $anything->ci = & get_instance();
        $query = "SELECT MAX(" . $field . ") as increment  FROM " . $table;
        $queryRun = $anything->ci->db->query($query)->row();
        $increment = $queryRun->increment + 1;

        $queryAlter = "ALTER TABLE " . $table . " auto_increment =" . $increment;
        $queryRun = $anything->ci->db->query($queryAlter);

        return true;
    }

}
// ------------------------------------------------------------------------
/**
 * Get database date
 *
 *
 * @access	public
 * @param	date(date by datepicker)
 * @return	true
 */
if (!function_exists('get_db_date')) {

    function get_db_date($date, $type = false) {
        if ($date == "") {
            return "";
        } else {
            if ($type) {
                $date_time = date("Y-m-d H:i:s", strtotime($date));
                return $date_time;
            } else {
                list( $day, $month, $year ) = explode('/', $date);
                return "$year-$month-$day";
            }
        }
    }

}
// ------------------------------------------------------------------------
/**
 * Get datepicker date
 *
 *
 * @access	public
 * @param	date(date by db)
 * @return	true
 */
if (!function_exists('get_datepicker_date')) {

    function get_datepicker_date($date, $type = false) {
        if ($date == "") {
            return "";
        } else {
            if ($type) {
                $date_time = date("d M, Y h:i a", strtotime($date));
                return $date_time;
            } else {
                list( $year, $month, $day ) = explode('-', $date);
                return "$day/$month/$year";
            }
        }
    }

}
/**
 * Render the view page
 *
 *
 * @access	public
 * @param	view(string), view data(Array), render(BOOL)
 * @return	true
 */
if (!function_exists('_render_page')) {

    function _render_page($view, $data = null, $render = false) {
        $aroma = & get_instance();
        $aroma->viewdata = (empty($data)) ? $aroma->data : $data;
        $view_html = $aroma->load->view($view, $aroma->viewdata, $render);
        if (!$render) {
            return $view_html;
        }
    }

}

/*
 * Project define functions
 */
if (!function_exists('check_user_logged')) {

    function check_user_logged() {
        $aroma = &get_instance();
        if ($aroma->session->userdata('slamadminis_logged_user')) {
            redirect('admin');
        }
    }

}
if (!function_exists('check_logged_user')) {

    function check_logged_user() {
        $aroma = & get_instance();
        if (!$aroma->session->userdata('slamadminis_logged_user')) {
            redirect('login');
        }
    }

}



if (!function_exists('get_all_banner')) {

    function get_all_banner() {
        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('status', 1);
        $aroma->db->order_by('sequence ASC');
        return $aroma->db->get('tbl_banners')->result();
    }

}


if (!function_exists('get_category_by_product_id')) {

    function get_category_by_product_id($id,$limit=false) {
        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('category_id', $id);
        $aroma->db->order_by('sequence',' ASC');
        $aroma->db->where('status',1);
        if($limit==false){
            $category = $aroma->db->get('tbl_products')->result();
        }else{
             $category = $aroma->db->get('tbl_products',$limit)->result();
        }

       return $category;

    }

}

if (!function_exists('get_product_icon')) {

    function get_product_icon($product_id) {
        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('product_id', $product_id);
       $product_icons = $aroma->db->get('tbl_product_icon')->result();
       $complete_icon_arr = array();
        foreach($product_icons as $product_icon){
          $icon_id = $product_icon->icon_id;
          $complete_icon_arr[$icon_id] = $product_icon;
          if($icon_id){
            $icon_img = get_product_icon_image($icon_id);
            $complete_icon_arr[$icon_id]->icon_img = $icon_img;
          }
        }
      //  print '<pre>'; print_r($complete_icon_arr);

       if(!empty($complete_icon_arr)){
         return $complete_icon_arr;
       }
      else {
            return false;
          }
        }
    }

    if (!function_exists('get_product_icon_image')) {

        function get_product_icon_image($icon_id) {
            $aroma = &get_instance();
            $aroma->db->select('*');
            $aroma->db->where('id', $icon_id);
           $image_icon = $aroma->db->get('tbl_icons')->result();
//  print '<pre>'; print_r($image_icon);die;
           if(!empty($image_icon)){
             return $image_icon[0]->image;
           }
          else {
                return false;
              }
            }
        }

if (!function_exists('get_product_detail')) {

    function get_product_detail($id) {
        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('id', $id);
        $productDetail = $aroma->db->get('tbl_products')->row();
        return $productDetail;

    }

}

if (!function_exists('get_product_attribute')) {

    function get_product_attribute($id) {
        $aroma = &get_instance();
        $aroma->db->select('title,price,attr_name_id');
        $aroma->db->where('id', $id);
       $productAttrbuteDetail = $aroma->db->get('tbl_products_attr')->row();
      return $productAttrbuteDetail;

    }

}

if (!function_exists('get_product_attribute_data')) {

    function get_product_attribute_data($id) {
        $aroma = &get_instance();
        $aroma->db->where('product_id', $id);
        $attrname = $aroma->db->get('tbl_attrname')->result();
        if(!empty($attrname)){
        $attrdata = array();
        $i=0;
       foreach($attrname as $data){
          $attrdata[$i]['name'] = $data->name;
          $attrdata[$i]['nameid'] = $data->id;
            $aroma->db->where('attr_name_id',$data->id);

          $attrdata[$i]['attr']= $aroma->db->get('tbl_products_attr')->result();

           ++$i;
        }
        return $attrdata;
     }else{
        return true;
     }
    }

}
if (!function_exists('get_product_option')) {

    function get_product_option($id) {
        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('product_id', $id);
       $productAttrbuteDetail = $aroma->db->get('tbl_product_option')->row();
      return $productAttrbuteDetail;

    }

}

if (!function_exists('get_customer_billing_detail')) {

    function get_customer_billing_detail($id) {
        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('id', $id);
       $userdetail = $aroma->db->get('tbl_users')->row();
      return $userdetail;

    }

}
if (!function_exists('get_guest_userdetail')) {

    function get_guest_userdetail($id) {
        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('id', $id);
       $userdetail = $aroma->db->get('tbl_guest_users')->row();
      return $userdetail;

    }

}

if (!function_exists('time_elapsed_string')) {

    function time_elapsed_string($datetoday,$id) {
        $date = date('Y-m-d');

        $aroma = &get_instance();
        if($date==$datetoday){
            $data['status']=1;
        $aroma->db->where('id', $id);
       $userdetail = $aroma->db->update('tbl_reservationmanage',$data);
            return 'Today';

    }else if($datetoday>$date)
    {
        $data['status']=1;
        $aroma->db->where('id', $id);
       $userdetail = $aroma->db->update('tbl_reservationmanage',$data);
       return 'Pending';
      }else{
       $data['status']=0;
        $aroma->db->where('id', $id);
       $userdetail = $aroma->db->update('tbl_reservationmanage',$data);
       return 'Ended';
   }


    }

}
if (!function_exists('get_category_detail')) {

    function get_category_detail($limit=false) {
        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('parent', 0);
        $aroma->db->order_by('sequence',' ASC');
        $aroma->db->where('status',1);
        if($limit==false){
            $category = $aroma->db->get('tbl_category')->result();
        }else{
       $category = $aroma->db->get('tbl_category',$limit)->result();
      }
       return $category;

    }

}
if (!function_exists('get_cetgory_by_special')) {

    function get_cetgory_by_special() {
        $aroma = &get_instance();
        $aroma->db->select('*');

        $aroma->db->where('status',1);
         $aroma->db->where('special',1);

       $category = $aroma->db->get('tbl_category')->row();

       return $category;

    }

}

if (!function_exists('get_attr_name')) {

    function get_attr_name($id) {

        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('id',$id);
        $result = $aroma->db->get('tbl_products_attr')->row();

        return $result;
    }

}
if (!function_exists('get_attribute_name')) {

    function get_attribute_name($id) {

        $aroma = &get_instance();
        $aroma->db->select('name');
        $aroma->db->where('id',$id);
        $result = $aroma->db->get('tbl_attrname')->row();

        return $result;
    }

}

if (!function_exists('get_option_name')) {

    function get_option_name($id) {
        $aroma = &get_instance();
        $aroma->db->select('*');
       $aroma->db->where('id', $id);
        $result = $aroma->db->get('tbl_product_option')->row();
         return $result;
    }

}

if (!function_exists('get_shipping_userdetail')) {

    function get_shipping_userdetail($id) {
        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('user_id', $id);
       $userdetail = $aroma->db->get('tbl_shipping_address')->result();
      return $userdetail;

    }

}

if (!function_exists('get_testmonial')) {

    function get_testmonial() {
        $aroma = &get_instance();
        $aroma->db->select('*');
         $reservation = $aroma->db->get('tbl_testmonial')->result();
      return $reservation;

    }

}
if (!function_exists('get_tot_orders')) {

    function get_tot_orders() {
        $aroma = &get_instance();
        $aroma->db->select('*');

        $aroma->db->from('tbl_order');
        //$aroma->db->where('tbl_order.id',$id);
        $aroma->db->join('tbl_payment_method','tbl_order.id=tbl_payment_method.order_id');
        $data = count($aroma->db->get()->result());
        return $data;

    }

}

if (!function_exists('get_tot_shoppers')) {

    function get_tot_shoppers() {
        $aroma = &get_instance();
        $aroma->db->select('*');
         $get_tot_shoppers = count($aroma->db->get('tbl_users')->result());
      return $get_tot_shoppers;

    }

}

if (!function_exists('get_page')) {

    function get_page($slug) {
        $aroma = &get_instance();
        $aroma->db->select('*');
         $aroma->db->where('slug',$slug);
         $get_setting = $aroma->db->get('tbl_pages')->row();
      return $get_setting;

    }

}

if (!function_exists('get_setting')) {

    function get_setting() {
        $aroma = &get_instance();
        $aroma->db->select('*');

         $get_setting = $aroma->db->get('tbl_setting')->row();
      return $get_setting;

    }

}

if (!function_exists('get_category')) {

    function get_category($id) {
        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('id', $id);

        return $aroma->db->get('tbl_category')->row();
    }

}
if (!function_exists('get_child_category')) {

    function get_child_category($id) {
        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('parent', $id);
        $aroma->db->order_by('sequence','ASC');
        return $aroma->db->get('tbl_category')->result();
    }

}

/*
 * Get Product Icon
 */
if (!function_exists('get_product_icon')) {

    function get_product_icon($id) {

        $aroma = &get_instance();
        $aroma->db->select('*');
        $aroma->db->where('product_id', $id);
        return $aroma->db->get('tbl_product_icon')->result();
    }

}
if (!function_exists('get_icon_image')) {

    function get_icon_image($id) {

        $aroma = &get_instance();
        $aroma->db->select('image');
        $aroma->db->where('id', $id);
        return $aroma->db->get('tbl_icons')->row();
    }

}

/*
 * Get Welcome Image
 */

if (!function_exists('get_welcome_image')) {

    function get_welcome_image() {

        $aroma = &get_instance();
        $aroma->db->select('image');
        $aroma->db->where('status', '1');
        return $aroma->db->get('tbl_welcome_image')->row();
    }

}
/*
 * Get header social media
 */

if (!function_exists('get_social_media')) {

    function get_social_media() {

        $slam = &get_instance();
        $slam->db->select('*');
        $slam->db->where('status', '1');
        return $slam->db->get('	tbl_social')->result();
    }

}

/*
 * Get header we are open now time
 */

if (!function_exists('get_open_time')) {
    function get_open_time() {
        $slam = &get_instance();
        $slam->db->select('*');
        $slam->db->where('id', '13');
        return $slam->db->get('tbl_pages')->row();
    }

}

/*
 * Get header we are open now time
 */

if (!function_exists('get_number')) {
    function get_number() {
        $slam = &get_instance();
        $slam->db->select('*');
        $slam->db->where('id', '12');
        return $slam->db->get('tbl_pages')->row();
    }

}
