<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Category_model extends CI_Model {

	private $user = "tbl_users";
	private $tbl_guest_users = "tbl_guest_users";
	private $tbl_order = "tbl_order";
  private $tbl_buy_product = "tbl_buy_product";
  private $tbl_promotion = "tbl_promotion";
  private $tbl_payment_method = "tbl_payment_method";
	
	function __construct(){
		parent:: __construct();
	}
	

public function get_data(){
  $this->db->select('*');
  if($this->input->post('name')){
    $this->db->like('title', $this->input->post('name')); 

  }else if($this->input->post('yourArray')){
     $this->db->where_in('category_id', $this->input->post('yourArray'));
   }else{

   }
 
  return $this->db->get('tbl_products')->result();
}


}
?>
