<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Checkout_model extends CI_Model {

	private $user = "tbl_users";
	private $tbl_guest_users = "tbl_guest_users";
	private $tbl_order = "tbl_order";
  private $tbl_buy_product = "tbl_buy_product";
  private $tbl_promotion = "tbl_promotion";
  private $tbl_payment_method = "tbl_payment_method";
	
	function __construct(){
		parent:: __construct();
	}
	
public function insertemail(){
	
	$this->db->select('email');
	$re = $this->db->get($this->tbl_subscribers)->result();
	foreach($re as $email){
		$array[]=$email->email;
	}
  	if (in_array($this->input->post('Email'), $array, true)) {
		
		return true;
	}else{
		$data['email']=$this->input->post('Email');
 		$this->db->insert($this->tbl_subscribers,$data);
		return true;

	}
}
/* change checkpost model*/
public function checkpostcode()
    { 

    if($this->input->get('postcode')!=''){
      
      $postcode = $this->input->get('postcode');
//echo "sumit";die;
      $postcode = preg_replace('/\s+/', '', $postcode);
       $checkLength = strlen($postcode);
       if($checkLength==5)
       {
        //echo "sumit11";die;
        // make two substrings
        $postcode = substr_replace($postcode, ' ', 2, 0);
  
       }
        else if($checkLength==6){
           $postcode = substr_replace($postcode, ' ', 3, 0);
        }
    }
    
     if($this->input->get('ship_postcode')!=''){
      $postcode = $this->input->get('ship_postcode');
    }
    $this->db->select('*');
    $this->db->where('postcode',$postcode);
     return $this->db->get('tbl_postcode')->row(); 
   
    }
/* public function checkpostcode()
    {
    if($this->input->get('postcode')!=''){
      $postcode = $this->input->get('postcode');
    }
     if($this->input->get('ship_postcode')!=''){
      $postcode = $this->input->get('ship_postcode');
    }
    $this->db->select('*');
    $this->db->where('postcode',$postcode);
     return $this->db->get('tbl_postcode')->row(); 
   
    }
*/
 public function inesrt_postcode($post){
  return  $this->db->insert('tbl_postcode',$post);

    }
public function userdata_insert(){
      // $data['title']=$this->input->post('title');
       // $data['user_name']=$this->input->post('username');
        $data['first_name']=$this->input->post('fname');
        $data['middle_name']=$this->input->post('mname');
        $data['last_name']=$this->input->post('lname');
        $data['address1']=$this->input->post('add1');
        $data['address2']=$this->input->post('add2');
        $data['city']=$this->input->post('city');
        $data['post_code']=$this->input->post('postcode');
        $data['phone_no']=$this->input->post('mobile');
        
        $data['email']=$this->input->post('email');
        $data['created_on']=date('Y-m-d');
       
        return $data;
        
    }
    public function userdata_shipaddress($id){
       $ship['first_name']=$this->input->post('ship_fname');
        $ship['middle_name']=$this->input->post('ship_mname');
        $ship['last_name']=$this->input->post('ship_lname');
        $ship['address1']=$this->input->post('ship_add1');
        $ship['address2']=$this->input->post('ship_add2');
        $ship['city']=$this->input->post('ship_city');
        $ship['post_code']=$this->input->post('ship_postcode');
        $ship['phone_no']=$this->input->post('ship_mobile');
        if($id){
          $ship['user_id']=0;
         $ship['guest_id']= $id; 
        }
      if($this->session->userdata('user_id')!=''){
        $ship['user_id']=$this->session->userdata('user_id');
         $ship['guest_id']= 0; 
      }
      $this->db->insert($this->tbl_guest_users,$ship); 
      return $this->db->insert_id();



    }
	public function insert_data(){
		if($this->input->post('ship_address')==1){
			if($this->session->userdata('slamfrontuser_id')!=''){
              $userdata =$this->userdata_insert();
              $this->db->where('id',$this->session->userdata('slamfrontuser_id'));
              $this->db->update($this->user,$userdata);
              $products['user_id']= $this->session->userdata('slamfrontuser_id');
              $products['guest_id']= 0; 

           }else{
              $insertuserdata =$this->userdata_insert();
              $this->db->insert($this->tbl_guest_users,$insertuserdata); 
              $insert_id= $this->db->insert_id();
              $products['user_id']= 0;
              $products['guest_id']= $insert_id;
           }

		}else{
			if($this->session->userdata('slamfrontuser_id')!=''){
              $userdata =$this->userdata_insert();
              $this->db->where('id',$this->session->userdata('slamfrontuser_id'));
              $this->db->update($this->user,$userdata);
              $usershipdata =$this->userdata_shipaddress();
             
              $products['user_id']= $this->session->userdata('slamfrontuser_id');
              $products['guest_id']= $usershipdata; 

           }else{
              $insertuserdata =$this->userdata_insert();
              $this->db->insert($this->tbl_guest_users,$insertuserdata); 
              $insert_id= $this->db->insert_id();
              $usershipdata =$this->userdata_shipaddress($insert_id);
              $products['user_id']= 0;
              $products['guest_id']= $usershipdata;
           }
		}

        $products['order_date']= date('Y-m-d');
        $products['disct']=$this->input->post('disct');
        $products['payment_method']= 1;
        $products['order_status']=1;
        //$products['note']=$this->session->userdata('usernote');
        $products['order_number'] = rand();
        if($this->input->post('discountvalue')!=''){
          $products['pay'] = number_format($this->cart->total(),2);
        $products['order_total']= $this->input->post('discountvalue');
      
        $products['disct_percent']= $this->input->post('disct_percent');

        }else{
          $products['pay'] = number_format($this->cart->total(),2);
         	$products['order_total']= number_format($this->cart->total(),2);
        }
        if($this->session->userdata('comment')!=''){
          $products['note']= $this->session->userdata('comment');
        }
		if($this->session->userdata('payment')!=''){
          $products['preferece']= $this->session->userdata('payment');
        }else{
			$products['preferece']= 'delivery';
		}
        $this->db->insert($this->tbl_order,$products);
        
        $order_id = $this->db->insert_id();
        $item =$this->cart->contents();
        foreach ($this->cart->contents() as $items){
        	$productsdata['product_id'] = $items['id'];
        	$productsdata['order_id'] = $order_id;
        	$productsdata['name'] = $items['name'];
        	$productsdata['price'] = $items['price'];
        	$productsdata['qty'] = $items['qty'];
        	$productsdata['product_subtotal_price'] = $items['subtotal'];
        	if(!empty($items['options'])){
        	$productsdata['attribute'] = serialize($items['options']);
       		 }
       		$this->db->insert($this->tbl_buy_product,$productsdata);

        }

 	return $order_id;


	}

	public function order_detail($id){
      $this->db->select('*');
        $this->db->where('id',$id);
        return $this->db->get($this->tbl_order)->row();

    }
	
	public function validate_coupon($coupon){
		$this->db->select('*');
		$this->db->where('code', $coupon);
		return $this->db->get($this->tbl_promotion)->row();
	}
	
	public function get_coupan_data(){
		$this->db->select('*');
		$this->db->where('code',$this->input->post('code'));
		return $this->db->get($this->discount_code)->row();
	
	}

	public function login_users(){
        $email = $this->input->post('email');
		$pass = $this->input->post('password');
	    $this->db->select('*');
		$this->db->where('email',$email);
		$this->db->where('password',md5($pass));
        return $this->db->get($this->user)->row();
	}
	
	 public function saveSubscriptionDetail($data){
         
        return $this->db->insert($this->tbl_payment_method,$data);
        return true;

    }
	
}
?>
