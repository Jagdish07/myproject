<?php if(!defined('BASEPATH'))exit('No Direct Script access allowed');
class Page_model extends CI_Model{
    private $tbl_content_pages= "tbl_pages";
    private $tbl_gallery= "tbl_gallery";
   
         function __construct() {
		   parent::__construct(); 
		}
	function get_by_url($page){
		$this->db->where('slug', $page);
		$this->db->where('status', '1');
		return $this->db->get($this->tbl_content_pages);
		
	}

        function get_contact_data(){
		$this->db->where('id', '12');
		$this->db->where('status', '1');
		return $this->db->get($this->tbl_content_pages)->row();
		
	}


	public function get_gallery(){
		$this->db->select('*');
$this->db->where('status', '1');
$this->db->order_by('sequence', 'desc');
		return $this->db->get($this->tbl_gallery)->result();


	}
		}