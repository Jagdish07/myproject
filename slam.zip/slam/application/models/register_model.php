<?php if(!defined('BASEPATH'))exit('No Direct Script access allowed');
class Register_model extends CI_Model{
    private $user = "tbl_users";
   
         function __construct() {
		   parent::__construct(); 
		}
	public function login_users(){
        $email = $this->input->post('email');
		$pass = $this->input->post('password');
	    $this->db->select('*');
		$this->db->where('email',$email);
		$this->db->where('password',md5($pass));
        return $this->db->get($this->user)->row();
	}
	public function insert_userdata(){

        $data['first_name']=$this->input->post('fname');
        $data['last_name']=$this->input->post('lname');
        $data['password']=md5($this->input->post('pass'));
        $data['email']=$this->input->post('email');
        $data['created_on']=date('Y-m-d');
        
        $this->db->insert($this->user,$data);
        return $this->db->insert_id();

    }
    public function update_password($id,$data){
		$this->db->where('id',$id);
	 return $this->db->update($this->user,$data);
	 
	}
    public function forget_password(){
	  $email = $this->input->post('email');
	  $this->db->select('*');
	  $this->db->where('email',$email);
	  return $this->db->get($this->user)->row();
	}
	public function checkemail(){
	    $email= $this->input->get('email');
	    $this->db->select('*');
		$this->db->where('email',$email);
		return $this->db->get($this->user)->result();		
	}
}