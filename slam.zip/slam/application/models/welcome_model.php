<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of order_model
 *
 * @author wiesoftware26
 */
class Welcome_model extends CI_Model {
    
   private  $tbl_banners = 'tbl_banners';
   
    
    
    
    function __construct() {
        parent::__construct();
    }

    public function get_banner(){
      $this->db->select('*');
      $this->db->where('status',1);
      return $this->db->get('tbl_banners')->result();
    }
  }
    ?>