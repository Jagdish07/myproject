<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    function __construct() {
        parent:: __construct();
        check_logged_user();
        $this->load->model('admin_model');

    }

    public function index() {
        $this->data['view'] = 'main';
        $this->load->view('theme/admin/layout', $this->data);
    }
    public function manage() {
         $this->data['module_assets'] = 'module_assets';
        $this->data['view'] = 'main_admin';
        $this->load->view('theme/admin/layout', $this->data);
    }
      public function create() {
        $roles = $this->admin_model->get_roles();
        $rolearray = array();
        foreach($roles as $role){
            $rolearray[$role->id]=$role->role_name;
        }   
        $this->data['role_data'] = $rolearray;
        $this->data['view'] = 'create';
        $this->load->view('theme/admin/layout', $this->data);
    }
    public function adminsite(){
        $this->admin_model->insert_site();
             
    }
    public function site(){

        $this->data['module_assets'] = 'module_assets';
       $this->data['view'] = 'site';
        $this->load->view('theme/admin/layout', $this->data);

    }
    public function edit($id = false) {
        if (!$id) {
            redirect('admin');
        } else {
             $roles = $this->admin_model->get_roles();
        $rolearray = array();
        foreach($roles as $role){
            $rolearray[$role->id]=$role->role_name;
        }   
        $this->data['role_data'] = $rolearray;
            $this->data['record'] = $this->get_model_data($id);
            $this->data['view'] = 'edit';
            $this->load->view('theme/admin/layout', $this->data);
        }
    }
    public function change_password() {
        if($this->input->post()) {
            $this->load->model('login/auth_model');
            $this->form_validation->set_error_delimiters('<span class="error">', '</span>');
            $this->form_validation->set_rules('old_password', 'old password', 'trim|required|callback_password_check');
            $this->form_validation->set_rules('new_password', 'new password', 'trim|required');
            $this->form_validation->set_rules('confirm_password', 'confirm password', 'trim|required|matches[new_password]');
            if($this->form_validation->run() == TRUE) {
                $password = $this->input->post('new_password');
                $this->auth_model->setPassword($password);
                $updated = $this->auth_model->update_password();
                if($updated){
                    $this->session->set_flashdata('message', 'Your password is changed.');
                    redirect('admin/change_password');
                }
            }
        }
        $this->data['view'] = 'change_password';
        $this->load->view('theme/admin/layout', $this->data);
    }
    

     public function process() {
        if ($this->input->post()) {
            $this->form_validation->set_error_delimiters('<span class="error">', '</span>');
            $this->form_validation->set_rules('username', 'UserName', 'required|trim|xss_clean');
           if ($this->input->post('id') == 'new') {
           $this->form_validation->set_rules('password', 'Password', 'required');
       }
            $this->form_validation->set_rules('email', 'Email', 'required');
            $this->form_validation->set_rules('first_name', 'First Name', 'required|trim|xss_clean');
            $this->form_validation->set_rules('last_name', 'Last name', 'required|trim|xss_clean');
            if ($this->form_validation->run() == TRUE) {
                $this->set_model_data();
                if ($this->input->post('id') == 'new') {
                 
                    $inseretd = $this->admin_model->insert_data();
                    if($inseretd) {
                         $this->session->set_flashdata('success_message', 'Data inserted successfully.');
                    } else {
                        $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
                    }
                } else {
                    $updated = $this->admin_model->update_data();
                     if($updated) {
                         $this->session->set_flashdata('success_message', 'Data updated successfully.');
                    } else {
                        $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
                    }
                }
                redirect('admin/manage');
            } else {
                if ($this->input->post('id') == 'new') {
                    $this->create();
                } else {
                    $this->edit($this->input->post('id'));
                }
            }
        }
    }
     public function delete($id = false) {
        if (!$id) {
            redirect('admin/manage');
        } else {
            $this->admin_model->setId($id);
            $deleted = $this->admin_model->delete_data();
            if ($deleted) {
                $this->session->set_flashdata('success_message', 'Data deleted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
               redirect('admin/manage');
        }
    }

    public function set_model_data() {
       
        $adminObj = $this->admin_model;
       
        if ($this->input->post('id') != 'new') {
            $id = $this->input->post('id');
            $adminObj->setId($id);
        }
        $username = $this->input->post('username');
        $adminObj->setUsername($username);

        $role_id = $this->input->post('roles');
        $adminObj->setRole($role_id);

        $email = $this->input->post('email');
        $adminObj->setEmail($email);

        $password = $this->input->post('password');
        $adminObj->setPassword($password);

        $first_name = $this->input->post('first_name');
        $adminObj->setFirst_name($first_name);

        $last_name = $this->input->post('last_name');
        $adminObj->setLast_name($last_name);

        $adminObj->setStatus(1);
       
        return true;
    }
    
    public function get_model_data($id) {
        $cmsObj = $this->admin_model;

        $cmsObj->setId($id);
        $cmsObj->get_row();

        $response = new stdClass();
        $response->id = $cmsObj->getId();
        $response->username = $cmsObj->getUsername();
        $response->email = $cmsObj->getEmail();
         $response->roles = $cmsObj->getRole();
        $response->password = $cmsObj->getPassword();
        $response->first_name = $cmsObj->getFirst_name();
        $response->last_name = $cmsObj->getLast_name();
        return $response;
    }
    public function change_site(){
        if($this->input->post('value')){
        $this->load->model('login/auth_model');
       $setting_update = $this->auth_model->change_site_status();
       echo"update";


        }else{
       $this->load->model('login/auth_model');
       $setting_update = $this->auth_model->change_site_status();
       echo"update";
       die;
        }

    }
    public function update_status() {
        //print"<pre>";print_R($_POST); die;
        $id = $this->input->get('id');
        if (!$id) {
            redirect('admin');
        } else {
            $this->admin_model->setId($id);

            $status = $this->input->get('status');
            $this->admin_model->setStatus($status);
            $this->admin_model->update_status();
            die;
        }
    }

    public function password_check($param) {
        $this->auth_model->setPassword($param);
        $validate = $this->auth_model->password_validate();
        if(!empty($validate)) {
            return TRUE;
        } else {
            $this->form_validation->set_message('password_check', '%s not validate.');
            return FALSE;
        }
    }
    public function logout() {
        $array_items = array('slamusername' => '', 'slamemail' => '', 'slamfirst_name' =>'', 'slamlast_name' => '', 'slamadminis_logged_user' => FALSE);
        $this->session->unset_userdata($array_items);
        redirect('login');
    }
}
