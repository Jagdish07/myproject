<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Build_list extends CI_Controller {

    function __construct() {
        parent::__construct();
    }

    public function index() {
        $field = $this->input->post('type');
        $result = $this->get_data($field);
      
        $params = $result->params;
        $pagination = build_pagination($params->last_page, $params->current_page, $params->next_page, $params->prev_page, $params->lpm1, $params->field);
        /*
         * Build Final response
         */
        $response = new stdClass();
        $response->result = $result->result;
        $response->param = $result->params;
        $response->pagination = $pagination;
        
        if($this->input->post('other_type') == 'special') {
             echo $this->load->view('dynamic/' . $field . '_list_special', $response);
        } else {
            echo $this->load->view('dynamic/' . $field . '_list', $response);
        }
    }

    public function get_data($field) {

        switch ($field) {
            case 'banner':
                $this->load->model('banner/banner_model');
                $result = $this->banner_model->get_list();
                break;

                 case 'special':
                $this->load->model('special/special_model');
                $result = $this->special_model->get_list();
                break;
            case 'testmonial':
                $this->load->model('testmonial/testmonial_model');
                $result = $this->testmonial_model->get_list();
                break;
            case 'icons':
                $this->load->model('icons/icons_model');
                $result = $this->icons_model->get_list();
                break;
            case 'cms':
                $this->load->model('cms/cms_model');
                $result = $this->cms_model->get_list();
               break;

           case 'module':
                $this->load->model('settings/module_manage_model');
                $result = $this->module_manage_model->get_list();
                break;

            case 'role':
                $this->load->model('settings/role_manage_model');
                $result = $this->role_manage_model->get_list();
                break;
            case 'gallery':
                $this->load->model('gallery/gallery_model');
                $result = $this->gallery_model->get_list();
               break;
           
            case 'category':
                $this->load->model('category/category_model');
                $result = $this->category_model->get_list();
               break;
           
            case 'products':
                $this->load->model('products/products_model');
                $result = $this->products_model->get_list();
               break;
	   
	     case 'shoppers':
                $this->load->model('shoppers/shoppers_model');
                $result = $this->shoppers_model->get_list();
               break;	
         case 'discount':
            
            $this->load->model('discount/discount_model');
            $result = $this->discount_model->get_list();
            
            
            break;  
	     case 'orders':
                         $this->load->model('orders/orders_model');
                         $result = $this->orders_model->get_list();
                         break;	

            case 'image':
			$this->load->model('image/image_model');
			$result = $this->image_model->get_list();
			break;	

            case 'social':
			$this->load->model('social/social_model');
			$result = $this->social_model->get_list();
			break;	

               case 'admin':
                $this->load->model('admin/admin_model');
                $result = $this->admin_model->get_list();
                //print_r($result); die;
               break;   
        }
        
        return $result;
    }

}
