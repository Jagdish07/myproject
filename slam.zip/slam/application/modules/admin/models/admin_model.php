<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of banner_model
 *
 * @author wiesoftware26
 */
class Admin_model extends CI_Model{
    private $id;
    
    private $username;
    
    private $password;
    
    private $email;
    
    private $first_name;
    
    private $last_name; 
    
    private $status;
    
    private $queryString;
    
    private $whereOrAnd;
    
    private $where;

    private $tbl_name = 'tbl_login';

    private $tbl_setting = 'tbl_setting';
    function __construct() {
        parent::__construct();
    }
      public function getId(){
        return $this->id;
    }
    
    public function setId($param) {
        $this->id = $param;
    }

    public function setUsername($username){
        $this->username = $username;
    }
    
    public function getUsername(){
        return $this->username;
    }
    
    public function setPassword($password){
        $this->password = $password;
    }
    
    public function getPassword() {
        return $this->password;
    }
    
    public function setEmail($email) {
        $this->email = $email;
    }
    
    public function getEmail() {
        return $this->email;
    }
     public function setRole($role_id) {
        $this->role_id = $role_id;
    }
    
    public function getRole() {
        return $this->role_id;
    }
    
    public function setStatus($param) {
        $this->status = $param;
    }
    
    public function getStatus() {
        return $this->status;
    }
    
    public function setFirst_name($first_name) {
        $this->first_name = $first_name;
    }
    
    public function getFirst_name() {
        return $this->first_name;
    }
    
    public function setLast_name($last_name) {
        $this->last_name = $last_name;
    }
    
    public function getLast_name() {
        return $this->last_name;
    }
    
    public function insert_data() {
        $post_data = $this->get_post_values();
        
        return $this->db->insert($this->tbl_name, $post_data);
    }
    
    public function get_post_values() {
      
        $post_data = new stdClass();
        $post_data ->username = $this->getUsername();
        $post_data->password = md5($this->getPassword());
        $post_data->email = $this->getEmail();
        $post_data->roles = $this->getRole();
        $post_data->first_name = $this->getFirst_name();
        $post_data->last_name = $this->getLast_name();
        $post_data->status = $this->getStatus();
        return $post_data;
    }
    
    public function get_row() {
        $id = $this->getId();
        $this->db->where('id', $id);
        $row = $this->db->get($this->tbl_name)->row();
        if($row) {
            $this->setId($row->id);
           
            $this->setUsername($row->username);
            $this->setPassword($row->password);
            $this->setRole($row->roles);
            $this->setEmail($row->email);
            $this->setFirst_name($row->first_name);
            $this->setLast_name($row->last_name);
            return $this;
        } else {
            return false;
        }
    }
    
    public function insert_site(){
        if($this->input->post('address')){
            $data['address']=$this->input->post('address');
        }
        if($this->input->post('contact')){
             $data['contact']=$this->input->post('contact');
        }
        if($this->input->post('timimg')){
             $data['timing']=$this->input->post('timimg');
        }
        $this->db->where('id',1);
     return   $this->db->update('tbl_setting',$data);

    }
    public function get_roles(){
        $this->db->select('*');
        return $this->db->get('tbl_roles')->result();
    }
     public function update_data() {
        $post_data = $this->get_post_values();
        $id = $this->getId();
         $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    
    public function delete_data() {
        $id = $this->getId();
        $this->db->where('id', $id);
        $deleted = $this->db->delete($this->tbl_name);
       
            return true;
      
    }
    
    public function update_status() {
        $id = $this->getId();
        $post_data = new stdClass();
        $post_data->status = $this->getStatus();
        $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    
    public function update_sequence() {
        $id = $this->getId();
        $post_data = new stdClass();
        $post_data->sequence = $this->getSequence();
        $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    public function set_where_name($name=false) {
        if ($name) {
            $this->whereOrAnd = " WHERE ";
            $this->where = " title LIKE '%" . $name . "%' ";
        }
        $this->queryString = $this->whereOrAnd . $this->where;

        $response = new stdClass();
        $response->query_string = $this->queryString;
        $response->title = $name;

        return $response;
    }
    public function get_post_data() {
        $postData = new stdClass();
        $postData->sort = $this->input->post('sort');
        $postData->order = $this->input->post('order');
        $postData->page = $this->input->post('page');
        $postData->limit = $this->input->post('limit');
        $postData->name = $this->input->post('name');
        $postData->field = $this->input->post('type');
        $postData->section = $this->input->post('section');
        return $postData;
    }

    public function get_list() {
        $postData = $this->get_post_data();
        /*
         * Count All results
         */
        $this->set_where_name($postData->name);
        $queryCount = "SELECT count(*) as num_records FROM " . $this->tbl_name;
        $queryCountRun = $this->db->query($queryCount . $this->whereOrAnd . $this->where);
        $queryCountResult = $queryCountRun->row();

        /*
         * Get All records
         */
        $query = "SELECT * FROM " . $this->tbl_name;
        $orderObj = set_order($postData->sort, $postData->order);
        $limitObj = set_limit($postData->page, $postData->limit);
        $queryString = $query . $this->whereOrAnd . $this->where . $orderObj->query_string . $limitObj->query_string;
        $queryRun = $this->db->query($queryString);
        $queryResult = $queryRun->result();

        $params = request_params($queryCountResult->num_records, $orderObj->sort, $orderObj->order, $limitObj->limit, $limitObj->page, $limitObj->start, $postData->field);

        $response = new stdClass();
        $response->params = $params;
        $response->result = $queryResult;
        return $response;
    }
    public function change_setting(){
        $this->db->select('*');
        $result= $this->db->get($this->tbl_setting)->row();
        $data=array(
          'status'=> $this->input->post('status'),
            );
        $this->db->where('id',$result->id);
        $this->db->update($this->tbl_setting,$data);
        return true;

    }
}