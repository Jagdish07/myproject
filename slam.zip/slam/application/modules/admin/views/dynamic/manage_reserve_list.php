<table class="table table-hover table-striped">
    <tr>
        <th>Time To</th>
        <th>Time From</th>
        <th>No of Guest User</th>
        <th>Date</th>
        <th>Action</th>
    </tr>
    <?php
    if (!empty($result)) {
        foreach ($result as $row) {
            ?>
            <tr>
                <td><?php echo $row->time_to; ?></td>
                <td><?php echo $row->time_from; ?></td>
              <td><?php echo $row->guestuser; ?></td>
                    <td><?php echo time_elapsed_string($row->date,$row->id);?></td>    
                <td>
                    <a class="btn btn-primary btn-sm" href="<?php echo base_url('manage_reserve/edit/' . $row->id); ?>">
                        <span class="glyphicon glyphicon-pencil"></span>
                    </a>
                    <a class="btn btn-danger btn-sm" onClick="javascript:return confirm('Are you sure you want to Delete?');" href="<?php echo base_url('manage_reserve/delete/' . $row->id); ?>">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
        <?php
        }
    } else {
        ?>
        <tr>
            <td colspan="5" align="center">No record found</td>
        </tr>
<?php } ?>

</table>

<div class="pagination pull-right">
    <?php echo $pagination;?>
</div>