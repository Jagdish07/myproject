<table class="table table-hover table-striped">
    <tr>    
	<td><strong>module name</strong></td>
        <td align="center"><strong>status</strong></td>
    </tr>
    <?php
    if (!empty($result)) {
	$count=0;
        foreach ($result as $row) {
            ?>
            <tr>
                <td><?php echo $row->module_name; ?></td>
		<td align="center">
                <?php if ($row->status == 1) { ?>
                    <a href="javascript:void(0);" onclick="update_status('<?php echo $row->id; ?>', 'module', '0');" class="btn btn-success btn-sm" style="width: 70px ;">enabled</a>
                <?php } else { ?>
                    <a href="javascript:void(0);" onclick="update_status('<?php echo $row->id; ?>', 'module', '1');" class="btn btn-warning btn-sm" style="width: 70px ;">disabled</a>
                <?php } ?>
		</td>
            </tr>
        <?php
        }
    } else {
        ?>
        <tr>
            <td colspan="5" align="center"><?php echo lang('no_record_found');?></td>
        </tr>
<?php } ?>

</table>

<div class="pagination pull-right">
    <?php echo $pagination;?>
</div>
