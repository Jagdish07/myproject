<script>

$(document).ready(function(){

$('body').delegate('#checkprint','click',function(e){ 

$('.checkdata').prop('checked', this.checked);


}); 


$('#print_all_ords').on('click', function(){
	
	 var count_checked= $('input[name="order_data_view[]"]:checked').length;
	 //alert(count_checked);
	 
 if(!count_checked){
	 alert("Please select checkbox");
	 return false;
 }else{
	 
	 $('#print_order').submit();
	// alert("sk");
 }
	
	
})

});

</script>
<form name="print_order" action="<?php echo base_url('orders/print_all_order');?>" method="post" id="print_order">
<table class="table table-hover table-striped">
    <tr>
	<th>Order Number</th>
	
	<th>Order Date</th>        
        <th>Order Status</th>
        <th>Preferece</th>
	<th>Total</th>
	
        <th>Action</th>
       
          
		 <th> <input type="checkbox" id="checkprint" name="checkprint">Check All</th>
		  <input type="button" name="printOrders"  value="Print orders" id="print_all_ords"/>
		 
    </tr>
    <?php
    if (!empty($result)) {
        foreach ($result as $row) {
            ?>
            <tr>
		<td><?php echo $row->id; ?></td>
		
		<td><?php echo get_datepicker_date($row->order_date , 'full');?></td> 
		<td>

		<select id="order_status<?php echo $row->id;?>">
		<option value="1" <?php echo $selected = $row->order_status=='1'?$selected = 'selected="selected"':'';?>>Pending</option>
			<option value="2" <?php echo $selected = $row->order_status=='2'?$selected = 'selected="selected"':'';?>>InProgress</option>
			<option value="3" <?php echo $selected = $row->order_status=='3'?$selected = 'selected="selected"':'';?>>ReadyToCollect</option>
			<option value="4" <?php echo $selected = $row->order_status=='4'?$selected = 'selected="selected"':'';?>>Completed</option>
			<option value="5" <?php echo $selected = $row->order_status=='5'?$selected = 'selected="selected"':'';?>>Cancelled</option>
		</select>
</td> 
                 <td><?php echo $row->preferece;?></td> 
                 <td><?php echo $row->order_total;?></td>      
                <td>
                     <a class="btn btn-success btn-sm" href="<?php echo base_url('orders/view_data/'.$row->id);?>" >
                        <span class="glyphicon glyphicon-align-justify"></span>
                    </a>
                    <a class="btn btn-primary btn-sm" href="javascript:void(0);"  onClick="update_order_status('<?php echo $row->id; ?>','orders')">
                        <span class="glyphicon glyphicon-pencil"></span>
                    </a>
                    <a class="btn btn-danger btn-sm" onClick="javascript:return confirm('Are you sure you want to Delete?');" href="<?php echo base_url('orders/delete/' . $row->id); ?>">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
                 <td>
                <input type="checkbox" class="checkdata" name="order_data_view[]" value="<?php echo $row->id;?>"/>
                </td>
			
            </tr>
        <?php
        }
    } else {
        ?>
        <tr>
            <td colspan="5" align="center">No record found</td>
        </tr>
<?php } ?>

</table>
</form>

<div class="pagination pull-right">
    <?php echo $pagination;?>
</div>
