
<table class="table table-hover table-striped">
    <tr>
	<th>Order Number</th>
	
	<th>Order Date</th>        
        <th>Order Status</th>
	<th>Total</th>
	
        <th>Action</th>
          <th><input type="button" name="checkall" value="Check"/></th>
    </tr>
    <?php
    if (!empty($result)) {
        foreach ($result as $row) {
            ?>
            <tr>
		<td><?php echo $row->id; ?></td>
		
		<td><?php echo get_datepicker_date($row->order_date , 'full');?></td> 
		<td>

		<select id="order_status<?php echo $row->id;?>">
		<option value="1" <?php echo $selected = $row->order_status=='1'?$selected = 'selected="selected"':'';?>>Pending</option>
			<option value="2" <?php echo $selected = $row->order_status=='2'?$selected = 'selected="selected"':'';?>>InProgress</option>
			<option value="3" <?php echo $selected = $row->order_status=='3'?$selected = 'selected="selected"':'';?>>ReadyToCollect</option>
			<option value="4" <?php echo $selected = $row->order_status=='4'?$selected = 'selected="selected"':'';?>>Completed</option>
			<option value="5" <?php echo $selected = $row->order_status=='5'?$selected = 'selected="selected"':'';?>>Cancelled</option>
		</select>
</td> 
                 <td><?php echo $row->order_total;?></td>      
                <td>
                     <a class="btn btn-success btn-sm" href="<?php echo base_url('orders/view_data/'.$row->id);?>" >
                        <span class="glyphicon glyphicon-align-justify"></span>
                    </a>
                    <a class="btn btn-primary btn-sm" href="javascript:void(0);"  onClick="update_order_status('<?php echo $row->id; ?>','orders')">
                        <span class="glyphicon glyphicon-pencil"></span>
                    </a>
                    <a class="btn btn-danger btn-sm" onClick="javascript:return confirm('Are you sure you want to Delete?');" href="<?php echo base_url('reservations/delete/' . $row->id); ?>">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
                 <td>
                 <input type="checkbox" name="checkdata" value="<?php echo $row->id;?>"/>
                </td>
            </tr>
        <?php
        }
    } else {
        ?>
        <tr>
            <td colspan="5" align="center">No record found</td>
        </tr>
<?php } ?>

</table>

<div class="pagination pull-right">
    <?php echo $pagination;?>
</div>
