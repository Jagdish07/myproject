<table class="table table-hover table-striped">
    <tr>
        <th>Title</th>
        <th>Status</th>
        <th>Date</th>
        <th>Action</th>
    </tr>
    <?php
    if (!empty($result)) {
        foreach ($result as $row) {
            ?>
            <tr>
                <td><?php echo $row->title; ?></td>
                <?php if ($row->status == 1) { ?>
                    <td><a href="javascript:void(0);" onclick="update_status('<?php echo $row->id; ?>', 'products', '0');" class="btn btn-success">Enabled</a></td>
                <?php } else { ?>
                    <td><a href="javascript:void(0);" onclick="update_status('<?php echo $row->id; ?>', 'products', '1');" class="btn btn-warning">Disabled</a></td>
                <?php } ?>
                    <td><?php echo get_datepicker_date($row->created_on, 'full');?></td>    
                <td>
                    <a class="btn btn-primary btn-sm" href="<?php echo base_url('products/edit/' . $row->id); ?>">
                        <span class="glyphicon glyphicon-pencil"></span>
                    </a>
                    <a class="btn btn-danger btn-sm" onClick="javascript:return confirm('Are you sure you want to Delete?');" href="<?php echo base_url('products/delete/' . $row->id); ?>">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
        <?php
        }
    } else {
        ?>
        <tr>
            <td colspan="5" align="center">No record found</td>
        </tr>
<?php } ?>

</table>

<div class="pagination pull-right">
    <?php echo $pagination;?>
</div>