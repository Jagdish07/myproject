<table class="table table-hover table-striped">
    <tr>
        <th>Title</th>
    </tr>
    <?php
    if (!empty($result)) {
        foreach ($result as $row) {
            ?>
            <tr onClick="add_new_special(<?php echo $row->id;?>, 'product');">
                <td><?php echo $row->title; ?></td>
        
            </tr>
        <?php
        }
    } else {
        ?>
        <tr>
            <td colspan="5" align="center">No record found</td>
        </tr>
<?php } ?>

</table>

<div class="pagination pull-right">
    <?php echo $pagination;?>
</div>