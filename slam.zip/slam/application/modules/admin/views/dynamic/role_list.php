<table class="table table-hover table-striped">
    <tr>	
	<td><strong><?php echo lang('role_name');?></strong></td>
        <td align="center"><strong><?php echo lang('status');?></strong></td>
	<td align="center"><strong><?php echo lang('action');?></strong></td>
    </tr>
    <?php
    if (!empty($result)) {
	$count=0;
        foreach ($result as $row) {
            ?>
            <tr>
		<td><?php echo $row->role_name; ?></td>
		
		<td align="center">
                <?php if ($row->status == 1) { ?>
                    <a href="javascript:void(0);" <?php echo ($row->role_name == 'admin') ? 'disabled="disabled"' : "";?> onclick="update_status('<?php echo $row->id; ?>', 'role', '0');" class="btn btn-success btn-sm" style="width: 70px ;">enabled</a>
                <?php } else { ?>
                    <a href="javascript:void(0);" <?php echo ($row->role_name == 'admin') ? 'disabled="disabled"' : "";?> onclick="update_status('<?php echo $row->id; ?>', 'role', '1');" class="btn btn-warning btn-sm" style="width: 70px ;">disabled</a>
                <?php } ?>
		</td>
		<td align="center">
                    <a class="btn btn-primary btn-sm <?php echo ($row->role_name == 'admin') ? 'disabled' : '';?>" href="<?php echo base_url('settings/role_manage/edit/' . $row->id); ?>">
                        <span class="glyphicon glyphicon-pencil"></span>
                    </a>
                    <a class="btn btn-danger btn-sm <?php echo ($row->role_name == 'admin') ? 'disabled' : '';?>" onClick="javascript:return confirm('Are you sure you want to Delete?');" href="<?php echo base_url('settings/role_manage/delete/' . $row->id); ?>">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
        <?php
        }
    } else {
        ?>
        <tr>
            <td colspan="5" align="center"><?php echo lang('No record found');?></td>
        </tr>
<?php } ?>

</table>

<div class="pagination pull-right">
    <?php echo $pagination;?>
</div>
