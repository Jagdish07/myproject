<?php
    $input_div_open = '<div class="form-group">';
    $input_div_close = '</div>';
    $required = ' <abbr class="required"><i class="fa fa-asterisk"></i></abbr>';
    $action = 'admin/process';
    echo form_open_multipart($action);
    
        echo (isset($record->id)) ? form_hidden('id', $record->id) : form_hidden('id', 'new');
    
        echo $input_div_open;
            echo form_label('UserName'.$required, 'username');
            $username = array(
                'name' => 'username',
                'class' => 'form-control',
                'id' => 'username',
                'value' => (isset($record->username)) ? $record->username : set_value('username')
            );
            echo form_input($username);
            echo form_error('username');
        echo $input_div_close;
        
          echo $input_div_open;
            echo form_label('First Name'.$required, 'first_name');
            $first_name = array(
                'name' => 'first_name',
                'class' => 'form-control',
                'id' => 'first_name',
                'value' => (isset($record->first_name)) ? $record->first_name : set_value('first_name')
            );
            echo form_input($first_name);
            echo form_error('first_name');
        echo $input_div_close;

         echo $input_div_open;
            echo form_label('Last name'.$required, 'last_name');
            $last_name = array(
                'name' => 'last_name',
                'class' => 'form-control',
                'id' => 'last_name',
                'value' => (isset($record->last_name)) ? $record->last_name : set_value('last_name')
            );
            echo form_input($last_name);
            echo form_error('last_name');
        echo $input_div_close;
  if(isset($record->id) =='') {
        echo $input_div_open;
            echo form_label('password', 'password');
            $subtitle = array(
                'name' => 'password',
                'class' => 'form-control',
                'id' => 'password',
                'value' => (isset($record->password)) ? $record->password : set_value('password')
            );
            echo form_password($subtitle);
             echo form_error('password');
        echo $input_div_close;
     } 

    echo $input_div_open;
            echo form_label('Role', 'Role');
           echo form_dropdown('roles', $role_data, $record->roles);
            echo form_error('email');
        echo $input_div_close;




        echo $input_div_open;
            echo form_label('email', 'email');
            $subtitle = array(
                'name' => 'email',
                'class' => 'form-control',
                'id' => 'email',
                'value' => (isset($record->email)) ? $record->email : set_value('email')
            );
            echo form_input($subtitle);
            echo form_error('email');
        echo $input_div_close;
        
      
        $submit = array(
            'name' => 'submit',
            'class' => 'btn btn-info',
            'id' =>'submit',
            'value' => 'Submit'
        );
        echo form_submit($submit);
   echo form_close();