<div class="row">
    <div class="col-md-12">
        <h1 class="page-header">
            Dashboard <small>Summary of <?php echo site_name();?></small>
        </h1>
    </div>
</div>

<div class="row">
   

   <div class="col-md-5 col-sm-12 col-xs-12">
      <a href="<?php echo base_url('orders');?>" class="hover-5x" id="blue">
        <div class="panel panel-primary text-center no-boder bg-color-blue">
	    <div class="panel-body">
		<i class="fa fa-shopping-cart fa-5x"></i>
		<h3> <?php echo get_tot_orders();?> </h3>
	    </div>
	    <div class="panel-footer back-footer-blue">
		Orders
	    </div>
        </div>
      </a>
   </div>
   

   <div class="col-md-5 col-sm-12 col-xs-12">
    <a href="<?php echo base_url('shoppers');?>" class="hover-5x" id="red">
        <div class="panel panel-primary text-center no-boder bg-color-red">
            <div class="panel-body">
                <i class="fa fa fa-user fa-5x"></i>
                <h3><?php echo get_tot_shoppers();?></h3>
            </div>
            <div class="panel-footer back-footer-red">
                Shoppers
            </div>
        </div>
    </a>
   </div>

   
</div>


<div class="row">
  <div class="col-md-3 col-sm-12 col-xs-12">
    <?php $get_setting=get_setting(); 
    if($get_setting->status=='1'){?>
	<button name="online-offline" id="siteofflineOnline" class="btn btn-success btn-lg site-online-offline">Site Online</button>
 <?php } else { ?>
 <button name="online-offline" id="siteofflineOnline" class="btn btn-warning btn-lg site-online-offline"> Site Offline</button>
 <?php } ?>
 
  </div>
  <div class="col-md-3 col-sm-12 col-xs-12">
	<div class="form-inline">
	   <label>Collection</label>
	   <input type="text" name="" class="form-control collection-val" value="<?php echo $get_setting->collection;?>"/>
        </div>
        <a  style="padding: 5px;margin: 7px;"class="btn btn-primary updatesetting" >Update</a>
  </div>
    <div class="col-md-3 col-sm-12 col-xs-12">
  <div class="form-inline">
     <label>delivery</label>
     <input type="text" name="" class="form-control delivery-val" value="<?php echo $get_setting->delivery;?>"/>
        </div>
      
  </div>
</div>

