<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/ckeditor/ckeditor.js"></script>

<SCRIPT TYPE="text/javascript">

function add_data(postArray){

$.post('adminsite',postArray,function(){

});
}
$(document).ready(function(){
     
$('.addressedit').click(function(){
   
    $('.address1').hide();
    $('.address').show();


});

$('.address_add').click(function(){
    var address = $('.addresstext').val();
    var postArray ={
        address:address
    }
     add_data(postArray);
   $('.address1').show();
    $('.address').hide();
    $('.address1').text(address);
});

$('.contactedit').click(function(){
   
    $('.contact1').hide();
    $('.contact').show();


});

$('.contact_add').click(function(){
    var contact = $('.contacttext').val();
    var postArray ={
        contact:contact
    }
     add_data(postArray);
$('.contact1').show();
    $('.contact').hide();
     $('.contact1').text(contact);

});

$('.timingedit').click(function(){
   
    $('.timing1').hide();
    $('.timing').show();


});

$('.timing_add').click(function(){
    var timimgtext = $('.timimgtext').val();
    var postArray ={
        timimg:timimgtext
    }
     add_data(postArray);
$('.timing1').show();
    $('.timing').hide();
     $('.timing1').text(timimgtext);


});

});


</SCRIPT>

<div class="row">
    <div class="col-md-12">
        <h1 class="page-header">
           Add Site Detail
           <a href="<?php echo base_url('banner');?>" class="btn btn-primary pull-right"><i class="fa fa-hand-o-left"></i> Back</a>
        </h1>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-list"></i> Site Detail
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <?php $set = get_setting(); 
                        ?>

                       <div class="table-responsive list__category">
                <table class="table table-hover table-striped">
    <tbody><tr>
        <th>Title</th>
        <th>Detail</th>
        
        <th>Action</th>
    </tr>
                
<tr>
    <td>Address</td>
    <td><span class="address1"><?php echo $set->address;?></span>
        <span class="address" style="display:none;">
          <textarea style="" name="address" cols="40" rows="5" class="addresstext"  id="content"><?php echo $set->address;?></textarea>
           
        </span></td>    
    <td>
        <a class="btn btn-primary btn-sm addressedit" >
        <span class="glyphicon glyphicon-pencil"></span>
        </a>
        <a class="address_add"> add</a>
    </td>
</tr>
<tr>
    <td>Contact</td>
       
     <td><span class="contact1"><?php echo $set->contact;?></span>
        <span class="contact" style="display:none;">
            
            <textarea style="" name="contact" cols="40" rows="5" class="contacttext"  id="content"><?php echo $set->contact;?></textarea>
           
        </span></td>    
   <td>
        <a class="btn btn-primary btn-sm contactedit" >
        <span class="glyphicon glyphicon-pencil"></span>
        </a>
        <a class="contact_add"> add</a>
    </td>
</tr>
<tr>
    <td>Timing</td>
   
    <td><span class="timing1"><?php echo $set->timing;?></span>
        <span class="timing" style="display:none;">
           
             <textarea style="" name="timing" cols="40" rows="5" class="timimgtext"  id="content"><?php echo $set->timing;?></textarea>
        </span></td>    
   
    <td>
        <a class="btn btn-primary btn-sm timingedit" >
        <span class="glyphicon glyphicon-pencil"></span>
        </a>
        <a class="timing_add"> add</a>
    </td>
</tr>
        
</tbody></table>
</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>