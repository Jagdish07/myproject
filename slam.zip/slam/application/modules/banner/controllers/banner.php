<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of banner
 *
 * @author wiesoftware26
 */
error_reporting(E_ALL);

class Banner extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper('banner');
        $this->load->model('banner_model');
    }

    public function index() {
        $this->data['view'] = 'main';
        $this->data['module_assets'] = 'banner/module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }

    public function create() {
        $this->data['view'] = 'create';
        $this->load->view('theme/admin/layout', $this->data);
    }

    public function edit($id = false) {
        if (!$id) {
            redirect('banner');
        } else {
            $this->data['record'] = $this->get_model_data($id);
            $this->data['view'] = 'edit';
            $this->load->view('theme/admin/layout', $this->data);
        }
    }

    public function delete($id = false) {
        if ($id) {
            $this->banner_model->setId($id);
            $deleted = $this->banner_model->delete_data();
            if ($deleted) {
                $this->session->set_flashdata('success_message', 'Data deleted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        }
        redirect('banner');
    }

    public function process() {
        if ($this->input->post()) {
            $this->form_validation->set_error_delimiters('<span class="error">', '</span>');
            $this->form_validation->set_rules('title', 'title', 'required|trim|xss_clean');
            $this->form_validation->set_rules('subtitle', 'subtitle', 'trim|xss_clean');
            $this->form_validation->set_rules('sequence', 'sequence', 'integer|trim|xss_clean');
            if ($this->form_validation->run() == TRUE) {
                if ($_FILES['file']['error'] == 4 && $this->input->post('id') != 'new') {
                    $this->data_operation();
                    redirect('banner');
                } else {
                    $get_data = $this->image_upload();

                    if (isset($get_data->upload_data)) {
                        $this->data_operation($get_data->upload_data);
                        redirect('banner');
                    }
                }
            }
            $this->load_view();
        }
    }

    public function data_operation($data = false) {
        if ($this->input->post('id') == 'new') {

            $this->set_model_data($data['orig_name']);

            $inserted = $this->banner_model->insert_data();

            if ($inserted) {
                $this->session->set_flashdata('success_message', 'Data inserted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        } else {
            if ($data) {
                $this->set_model_data($data['orig_name']);
            } else {
                $this->set_model_data();
            }

            $updated = $this->banner_model->update_data();
            if ($updated) {
                $this->session->set_flashdata('success_message', 'Data updated successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        }
        redirect('banner');
    }

    public function load_view() {
        if ($this->input->post('id') != 'new') {
            $this->edit($this->input->post('id'));
        } else {
            $this->create();
        }
    }

    public function image_upload() {
        $config['upload_path'] = banner_path();
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['file_name'] = time() . date('Ymd');

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('file')) {
            $error = (object) array('error' => $this->upload->display_errors('<span class="error">', '</span>'));
            $this->data['error'] = $error->error;
            return $this;
        } else {
            $data = (object) array('upload_data' => $this->upload->data());

            $configImageResize = array(
                'source_image' => $config['upload_path'] . $data->upload_data['file_name'],
                'new_image' => banner_path('thumb'),
                'maintain_ratio' => true,
                'width' => 350,
                'height' => 250
            );
            $this->load->library('image_lib');
            $this->image_lib->initialize($configImageResize);
            $this->image_lib->resize();


         $configImageusedResize = array(
                    'source_image' => $config['upload_path'].$data->upload_data['file_name'],
                    'new_image' => banner_path('used'),
                    //'maintain_ratio' => true,
                    'width' => 900,
                    'height' => 495
                );
                $this->image_lib->initialize($configImageusedResize);
                $this->image_lib->resize();
                $this->image_lib->clear();

        }
        return $data;
    }

    public function set_model_data($file_name = false) {
        $bannerObj = $this->banner_model;

        if ($this->input->post('id') != 'new') {
            $id = $this->input->post('id');
            $bannerObj->setId($id);
        }
        $title = $this->input->post('title');
        $bannerObj->setTitle($title);

        $subtitle = $this->input->post('subtitle');
        $bannerObj->setSubtitle($subtitle);

        if ($file_name) {
            $bannerObj->setImage($file_name);
        }
        $bannerObj->setStatus(1);

        $sequence = $this->input->post('sequence');
        $bannerObj->setSequence($sequence);

        $bannerObj->setCreatedOn();

        return true;
    }

    public function update_status() {
        $id = $this->input->get('id');
        if (!$id) {
            redirect('banner');
        } else {
            $this->banner_model->setId($id);

            $status = $this->input->get('status');
            $this->banner_model->setStatus($status);
            $this->banner_model->update_status();
            die;
        }
    }

    public function get_model_data($id) {
        $bannerObj = $this->banner_model;

        $bannerObj->setId($id);
        $bannerObj->get_row();

        $response = new stdClass();
        $response->id = $bannerObj->getId();
        $response->title = $bannerObj->getTitle();
        $response->subtitle = $bannerObj->getSubtitle();
        $response->image = $bannerObj->getImage();
        $response->sequence = $bannerObj->getSequence();

        return $response;
    }

}
