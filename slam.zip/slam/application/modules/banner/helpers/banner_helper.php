<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(!function_exists('banner_path')) {
    function banner_path($type=false){
        $properties = get_properties();
        
        if($type=='thumb') {
          //print"<pre>";print_R($type); die;
            return $properties->banner_thumb;
        } else if($type== 'used') {

        	 return $properties->banner_used;

        }else{
            return $properties->banner_path;
        }
    }
}
