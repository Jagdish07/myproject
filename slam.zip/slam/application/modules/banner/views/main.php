<div class="row">
    <div class="col-md-12">
        <h1 class="page-header">
           Banner Management
           <a href="<?php echo base_url('banner/create');?>" class="btn btn-primary pull-right"><i class="fa fa-plus"></i> Add banner</a>
        </h1>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <?php if($this->session->flashdata('success_message')!='') { ?>
                <div class="alert alert-success">
	<strong>Well done!</strong> <?php echo $this->session->flashdata('success_message');?>
                        <i class="fa fa-times pull-right alert-dismiss" data-dismiss="alert"></i>
                </div>
        <?php } ?>
        
        <?php if($this->session->flashdata('error_message')!='') { ?>
                <div class="alert alert-warning">
	<strong>Well done!</strong> <?php echo $this->session->flashdata('error_message');?>
                        <i class="fa fa-times pull-right alert-dismiss" data-dismiss="alert"></i>
                </div>
        <?php } ?>
        
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-list"></i> Banner list
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-xs-12 col-md-12">
                                <div class="form-group input-group">
                                    <input class="form-control" type="text" name="nameSearch__banner" id="nameSearch__banner" />
                                    <span class="input-group-addon"><i class="fa fa-search"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive list__banner">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
