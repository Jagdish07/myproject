<?php
error_reporting(E_ALL);
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of category
 *
 * @author wiesoftware26
 */
class Category extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->helper('category');
        $this->load->model('category_model');
    }
    
    public function index() {
        $this->data['view'] = 'main';
        $this->data['module_assets'] = 'category/module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }
     public function create() {
        $this->data['options'] = $this->category_model->get_category();
        $this->data['view'] = 'create';
        $this->load->view('theme/admin/layout', $this->data);
    }
    
     public function edit($id = false) {
        if (!$id) {
            redirect('category');
        } else {
            $this->data['options'] = $this->category_model->get_category();
            $this->data['record'] = $this->get_model_data($id);
            $this->data['view'] = 'edit';
            $this->load->view('theme/admin/layout', $this->data);
        }
    }
    
    public function delete($id = false) {
        if ($id) {
            $this->category_model->setId($id);
            $deleted = $this->category_model->delete_data();
            if ($deleted) {
                $this->session->set_flashdata('success_message', 'Data deleted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        }
        redirect('category');
    }
    
    public function process() {
        if ($this->input->post()) {
            $this->form_validation->set_error_delimiters('<span class="error">', '</span>');
            $this->form_validation->set_rules('title', 'title', 'required|trim|xss_clean');
            
            $this->form_validation->set_rules('description', 'description', 'required|trim|xss_clean');
            $this->form_validation->set_rules('parent', 'parent', 'required|xss_clean');
            $this->form_validation->set_rules('sequence', 'sequence', 'integer|trim|xss_clean');

            if ($this->form_validation->run() == TRUE) {
           // print_R($_FILES); die;
                if ($_FILES['file']['error'] == 4) {
                    $this->data_operation();
                    redirect('category');
                } else {
                    $get_data = $this->image_upload();
                 
                    if (isset($get_data->upload_data)) {
                        $this->data_operation($get_data->upload_data);
                        redirect('category');
                    }
                }
            }
            $this->load_view();
        }
    }
    
    public function data_operation($data = false) {
        if ($this->input->post('id') == 'new') {

            $this->set_model_data($data['orig_name']);
          //print"<pre>"; print_r($_POST); die;
            $inserted = $this->category_model->insert_data();

            if ($inserted) {
                $this->session->set_flashdata('success_message', 'Data inserted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        } else {
            if ($data) {
                $this->set_model_data($data['orig_name']);
            } else {
                $this->set_model_data();
            }
 //print"<pre>"; print_r($_POST); die;
            $updated = $this->category_model->update_data();
            if ($updated) {
                $this->session->set_flashdata('success_message', 'Data updated successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        }
        redirect('category');
    }
    
    public function load_view() {
        if ($this->input->post('id') != 'new') {
            $this->edit($this->input->post('id'));
        } else {
            $this->create();
        }
    }
    
    public function sequenceEdit(){
        $id =$this->input->post('id');
        $text =$this->input->post('value');
        $updatesequence =$this->category_model->update_sequence();
        echo $text;
        die;
    
    }
    public function image_upload() {
        $config['upload_path'] = category_path();
        $config['allowed_types'] = 'png|gif|jpg|png|jpeg';
        $config['file_name'] = time() . date('Ymd');

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('file')) {
            $error = (object) array('error' => $this->upload->display_errors('<span class="error">', '</span>'));
            $this->data['error'] = $error->error;
            return $this;
        } else {
            $data = (object) array('upload_data' => $this->upload->data());

            $configImageResize = array(
                'source_image' => $config['upload_path'] . $data->upload_data['file_name'],
                'new_image' => category_path('thumb'),
                'maintain_ratio' => true,
                'width' => 350,
                'height' => 250
            );
            $this->load->library('image_lib');
            $this->image_lib->initialize($configImageResize);
            $this->image_lib->resize();
        }
        return $data;
    }
    
     public function set_model_data($file_name = false) {
        $categoryObj = $this->category_model;

        if ($this->input->post('id') != 'new') {
            $id = $this->input->post('id');
            $categoryObj->setId($id);
        }
        $title = $this->input->post('title');
        $categoryObj->setTitle($title);
        
        $alias = $this->input->post('alias');
        $categoryObj->setAlias($alias);
        
        $description = $this->input->post('description');
        $categoryObj->setDescription($description);
        
        $parent = $this->input->post('parent');
        $categoryObj->setParent($parent);
        
        $page_title = $this->input->post('page_title');
        $categoryObj->setPageTitle($page_title);
        
         $meta_keyword = $this->input->post('meta_keyword');
         $categoryObj->setMetaKeyword($meta_keyword);
         
         $meta_description = $this->input->post('meta_description');
         $categoryObj->setMetaDescription($meta_description);  
         
         $image_alt = $this->input->post('image_alt');
         $categoryObj->setImageAlt($image_alt);
        
        if ($file_name) {
            $categoryObj->setImage($file_name);
        }
        $categoryObj->setStatus(1);

        $sequence = $this->input->post('sequence');
        $categoryObj->setSequence($sequence);

        $categoryObj->setCreatedOn();

        return true;
    }
    
    public function update_status() {
        $id = $this->input->get('id');
        if (!$id) {
            redirect('category');
        } else {
            $this->category_model->setId($id);

            $status = $this->input->get('status');
            $this->category_model->setStatus($status);
            $this->category_model->update_status();
            die;
        }
    }
    
    public function get_model_data($id) {
        $categoryObj = $this->category_model;

        $categoryObj->setId($id);
        $categoryObj->get_row();

        $response = new stdClass();
        $response->id = $categoryObj->getId();
        $response->title = $categoryObj->getTitle();
        $response->alias = $categoryObj->getAlias();
        $response->description = $categoryObj->getDescription();
        $response->parent = $categoryObj->getParent();
        $response->page_title = $categoryObj->getPageTitle();
        $response->meta_keyword = $categoryObj->getMetaKeyword();
        $response->meta_description = $categoryObj->getMetaDescription();
        $response->image_alt = $categoryObj->getImageAlt();
        $response->image = $categoryObj->getImage();
        $response->special = $categoryObj->getSpecial();

        $response->sequence = $categoryObj->getSequence();

        return $response;
    }
    
    
}