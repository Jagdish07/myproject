<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(!function_exists('category_path')) {
    function category_path($type=false){
        $properties = get_properties();
        if($type) {
            return $properties->category_thumb;
        } else {
            return $properties->category_path;
        }
    }
}

