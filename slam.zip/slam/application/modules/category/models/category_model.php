<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of category_model
 *
 * @author wiesoftware26
 */


//og2mr_virtuemart_product_categories  - product categroy relation

//og2mr_virtuemart_medias -  category imges

//og2mr_virtuemart_category_medias - category and media relation

//og2mr_virtuemart_category_categories -  category parent child relation

// og2mr_virtuemart_categories_en_gb - category detail 

class Category_model extends CI_Model {
    
    private $id;
    
    private $title;
    
    private $alias;
     
    private $description;

    private $parent;
    
    private $page_title; 
    
    private $meta_keyword;
    
    private $meta_description;

    private $image;
    
    private $image_alt;
    
    private $sequence;
    
    private $status;

    private $created_on;
    
    private $updated_on; 

    private $queryString;
    
    private $whereOrAnd;
    
    private $where;
    
    private $tbl_name = 'tbl_category';
    
    function __construct() {
        parent::__construct();
    }
    
    public function getId(){
        return $this->id;
    }
    
    public function setId($id) {
        $this->id = $id;
    }

    public function setTitle($title){
        $this->title = $title;
    }
    
    public function getTitle(){
        return $this->title;
    }
    
    public function setAlias($alias){
        $this->alias = $alias;
    }
    
    public function getAlias(){
        return $this->alias;
    }
    
    public function setParent($parent){
        $this->parent = $parent;
    }
    
    public function getParent(){
        return $this->parent;
    }
    
    public function setDescription($description){
        $this->description = $description;
    }
    
    public function getDescription(){
        return $this->description;
    }
    
   public function setPageTitle($page_title){
        $this->page_title = $page_title;
    }
    
    public function getPageTitle(){
        return $this->page_title;
    }

    public function setSpecial($special){
        $this->special = $special;
    }
    
    public function getSpecial(){
        return $this->special;
    }
    
    public function getMetaKeyword(){
        return $this->meta_keyword;
    }
    
    public function setMetaKeyword($meta_keyword) {
        $this->meta_keyword = $meta_keyword;
    }
    
    public function getMetaDescription(){
        return $this->meta_description;
    }
    
    public function setMetaDescription($meta_description) {
        $this->meta_description = $meta_description;
    }
    
    public function setImage($image) {
        $this->image = $image;
    }
    
    public function getImage() {
        return $this->image;
    }
    
    public function setImageAlt($image_alt) {
        $this->image_alt = $image_alt;
    }
    
    public function getImageAlt() {
        return $this->image_alt;
    }
    
    public function setStatus($status) {
        $this->status = $status;
    }
    
    public function getStatus() {
        return $this->status;
    }
    
    public function setSequence($sequence) {
        $this->sequence = $sequence;
    }
    
    public function getSequence() {
        return $this->sequence;
    }
    
    public function setUpdatedOn() {
        $this->updated_on = date('Y-m-d H:i:s');
    }
    
    public function getUpdatedOn() {
        return $this->updated_on;
    }
    
    public function setCreatedOn() {
        $this->created_on = date('Y-m-d H:i:s');
    }
    
    public function getCreatedOn() {
        return $this->created_on;
    }
    
    public function get_category() {
        $this->db->select('id,title');
        $this->db->where('status','1');
        $this->db->order_by('title','ASC');
        $result = $this->db->get($this->tbl_name)->result();
        $categoriesArray = array();
        $categoriesArray[0] = 'Top Level Category';
        foreach($result as $category){
                $categoriesArray[$category->id] = $category->title;
        }
        return $categoriesArray;
    }
    
    public function insert_data() {
        $post_data = $this->get_post_values();
        $post_data->slug = url_title($this->getTitle());
        
       
        $post_data->created_on = $this->getCreatedOn();
        return $this->db->insert($this->tbl_name, $post_data);
    }
    public function update_sequence(){
        $data=array(
        'sequence'=> $this->input->post('value')
        );
        $this->db->where('id',$this->input->post('id'));
        return $this->db->update($this->tbl_name,$data);
    
    }
    public function get_post_values() {
        $post_data = new stdClass();
        $post_data ->title = $this->getTitle();
        $post_data->alias = $this->getAlias();
        $post_data->description = $this->getDescription();
        $post_data->parent = $this->getParent();
        $post_data->page_title = $this->getPageTitle();
        $post_data->meta_keyword = $this->getMetaKeyword();
        $post_data->meta_description = $this->getMetaDescription();
        $post_data->image_alt = $this->getImageAlt();
        if($this->getImage() != '') {
            $post_data->image = $this->getImage();
        }
         if($this->input->post('Special')){
             $post_data->special = 1;
        }else{
            $post_data->special = 0;
        }
        $post_data->sequence = $this->getSequence();
        $post_data->status = $this->getStatus();
      // print_R($post_data); die;
        return $post_data;
    }
    
    public function update_data() {
        $post_data = $this->get_post_values();
         $post_data->slug = url_title($this->getTitle());
        $id = $this->getId();
        $post_data->updated_on = $this->getUpdatedOn();
        $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    
    public function get_row() {
        $id = $this->getId();
        $this->db->where('id', $id);
        $row = $this->db->get($this->tbl_name)->row();
        if($row) {
            $this->setId($row->id);
            $this->setTitle($row->title);
            $this->setAlias($row->alias);
            $this->setDescription($row->description);
             $this->setSpecial($row->special);
            $this->setParent($row->parent);
            $this->setPageTitle($row->page_title);
            $this->setMetaKeyword($row->meta_keyword);
            $this->setMetaDescription($row->meta_description);    
            $this->setImage($row->image);
            $this->setImageAlt($row->image_alt);
            $this->setSequence($row->sequence);
            return $this;
        } else {
            return false;
        }
    }
    
    public function delete_data() {
        $id = $this->getId();
        $this->db->where('id', $id);
        $deleted = $this->db->delete($this->tbl_name);
        if($deleted) {
             $row = $this->get_row();
            @unlink(category_path().$this->getImage());
            @unlink(category_path('thumb').$this->getImage());
            alter_auto_increment($this->tbl_name, 'id');
            return true;
        } else {
            return false;
        }
    }
    
    public function update_status() {
        $id = $this->getId();
        $post_data = new stdClass();
        $post_data->status = $this->getStatus();
        $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    
     public function set_where_name($name=false) {
        if ($name) {
            $this->whereOrAnd = " WHERE ";
            $this->where = " title LIKE '%" . $name . "%' ";
        }
        $this->queryString = $this->whereOrAnd . $this->where;

        $response = new stdClass();
        $response->query_string = $this->queryString;
        $response->title = $name;

        return $response;
    }
    public function get_post_data() {
        $postData = new stdClass();
        $postData->sort = $this->input->post('sort');
        $postData->order = $this->input->post('order');
        $postData->page = $this->input->post('page');
        $postData->limit = $this->input->post('limit');
        $postData->name = $this->input->post('name');
        $postData->field = $this->input->post('type');
        $postData->section = $this->input->post('section');
        return $postData;
    }
    
    public function get_list() {
        $postData = $this->get_post_data();
        /*
         * Count All results
         */
        $this->set_where_name($postData->name);
        $queryCount = "SELECT count(*) as num_records FROM " . $this->tbl_name;
        $queryCountRun = $this->db->query($queryCount . $this->whereOrAnd . $this->where);
        $queryCountResult = $queryCountRun->row();

        /*
         * Get All records
         */
       $query = "SELECT * FROM " . $this->tbl_name;
        $orderObj = set_order($postData->sort, $postData->order);
        $limitObj = set_limit($postData->page, $postData->limit);
        $queryString = $query . $this->whereOrAnd . $this->where . $orderObj->query_string . $limitObj->query_string;
        $queryRun = $this->db->query($queryString);
        $queryResult = $queryRun->result();

        $params = request_params($queryCountResult->num_records, $orderObj->sort, $orderObj->order, $limitObj->limit, $limitObj->page, $limitObj->start, $postData->field);

        $response = new stdClass();
        $response->params = $params;
        $response->result = $queryResult;
        return $response;
    }
}
