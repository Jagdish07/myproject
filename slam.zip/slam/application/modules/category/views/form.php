<?php
$input_div_open = '<div class="form-group">';
$input_div_close = '</div>';
$required = ' <abbr class="required"><i class="fa fa-asterisk"></i></abbr>';
$action = 'category/process';
?>
<ul class="nav nav-tabs">
    <li class="active">
        <a href="#general" data-toggle="tab">General</a>
    </li>
    <li class="">
        <a href="#seo" data-toggle="tab">SEO</a>
    </li>
    <li class="">
        <a href="#image_div" data-toggle="tab">Image</a>
    </li>
</ul><?php 



    echo form_open_multipart($action);
    echo (isset($record->id)) ? form_hidden('id', $record->id) : form_hidden('id', 'new');
?>
<div class="tab-content">
    <div class="tab-pane fade active in" id="general">
        <h4>General information</h4>
        <hr class="whiter"/>
        <div class="row">
            <div class="col-md-8">
                        <?php 
                           echo $input_div_open;
                                   echo form_label('Title' . $required, 'title');
                                   $title = array(
                                       'name' => 'title',
                                       'class' => 'form-control',
                                       'id' => 'title',
                                       'value' => (isset($record->title)) ? $record->title : set_value('title')
                                   );
                                echo form_input($title);
                                echo form_error('title');
                        echo $input_div_close;

                       
                        
                         echo $input_div_open;
                                echo form_label('Parent category ' . $required, 'parent');
                                $attr = 'class="form-control" style="width:250px"';
                                $selected = (isset($record->parent)) ? $record->parent : '';
                                echo form_dropdown('parent', $options, $selected, $attr);
                                echo form_error('parent');
                        echo $input_div_close;
                        
                        echo $input_div_open;
                            echo form_label('Description'.$required, 'description');
                            $description = array(
                                'name' => 'description',
                                'class' => 'form-control',
                                'id' => 'description',
                                'value' =>  (isset($record->description)) ? $record->description : set_value('description')
                            );
                            echo form_textarea($description);
                            echo form_error('description');
                        echo $input_div_close;

                        echo $input_div_open;
                                   echo form_label('Sequence', 'sequence');
                                   $sequence = array(
                                       'name' => 'sequence',
                                       'class' => 'form-control',
                                       'id' => 'sequence',
                                       'style' => 'width:250px',
                                       'value' => (isset($record->sequence)) ? $record->sequence : set_value('sequence')
                                   );
                                echo form_input($sequence);
                                echo form_error('sequence');
                        echo $input_div_close;
                        ?>
           </div>
        </div>
    </div>  
    <div class="tab-pane fade" id="seo">
        <h4>Meta information</h4>
        <hr class="whiter"/>
        <?php
            echo $input_div_open;
            echo form_label('Page title', 'title');
            $page_title = array(
                'name' => 'page_title',
                'class' => 'form-control',
                'id' => 'title',
                'value' => (isset($record->page_title)) ? $record->page_title : set_value('page_title')
            );
            echo form_input($page_title);
            echo form_error('page_title');
        echo $input_div_close;
        
            echo $input_div_open;
            echo form_label('Meta keyword', 'meta_keyword');
            $meta_keyword = array(
                'name' => 'meta_keyword',
                'class' => 'form-control',
                'id' => 'meta_keyword',
                'value' =>  (isset($record->meta_keyword)) ? $record->meta_keyword : set_value('meta_keyword')
            );
            echo form_textarea($meta_keyword);
            echo form_error('meta_keyword');
        echo $input_div_close;
        
        echo $input_div_open;
            echo form_label('Meta description', 'meta_description');
            $meta_description = array(
                'name' => 'meta_description',
                'class' => 'form-control',
                'id' => 'meta_keyword',
                'value' =>  (isset($record->meta_description)) ? $record->meta_description : set_value('meta_description')
            );
            echo form_textarea($meta_description);
            echo form_error('meta_description');
        echo $input_div_close;
        ?>
    </div>
    <div class="tab-pane fade" id="image_div">
        <h4>Category image</h4>
        <hr class="whiter"/>
       <?php
             echo form_label('Image'.$required, 'image');
            echo '<div class="form-group input-group" style="width: 300px;cursor:pointer;">';

                $file = array(
                    'name' => 'file',
                    'id' => 'image',
                    'style' => 'padding:0px;opacity: 0;'
                );
                echo '<span class="form-control">';
                echo '<span id="file_msg">No file selected.</span>';
                echo form_upload($file);
                echo '</span><span class="input-group-addon" id="select_file">Browse</span>';
            echo $input_div_close;

            echo (isset($error)) ? $error : '';
            
            if(isset($record->image)) {
            ?>
                <div class="col-md-6 col-sm-12 col-xs-12 pull-right" style="position: relative;top: -91px;">
                    <h4>Current image</h4>
                    <hr class="whiter" />
                    <img src="<?php echo base_url().category_path('thumb') . $record->image;?>" alt="<?php echo $record->title;?>" />
                </div>
            
            <?php
            }
            echo $input_div_open;
            echo form_label('Image alt', 'image_alt');
            $image_alt = array(
                'name' => 'image_alt',
                'class' => 'form-control',
                'id' => 'image_alt',
                'style' => 'width:250px',
                'value' => (isset($record->image_alt)) ? $record->image_alt : set_value('image_alt')
            );
            echo form_input($image_alt);
            echo form_error('image_alt');
        echo $input_div_close;

        echo $input_div_open;
        echo form_label('Special Meal', 'Special');
        $Special = array(
            'name' => 'Special',
            'id' => 'Special',
            'checked' => ($record->special == 1) ? true : false ,
            'value' => '1',
            'style' => 'margin-left: 5px;'
        );
        echo form_checkbox($Special);
        echo form_error('Special');
        echo $input_div_close;
        ?>
    </div> 
</div>

<?php 
    $submit = array(
            'name' => 'submit',
            'class' => 'btn btn-info',
            'id' =>'submit',
            'value' => 'Submit'
        );
        echo form_submit($submit);
        
    echo form_close();
?>
<script type="text/javascript" src="<?php echo base_url();?>assets/ckeditor/ckeditor.js"></script>
<script type="text/javascript">
        CKEDITOR.replace('description');
</script>