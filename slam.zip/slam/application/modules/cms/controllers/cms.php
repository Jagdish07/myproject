<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of cms
 *
 * @author wiesoftware26
 */
class Cms extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('cms_model');
    }

    public function index() {
        $this->data['view'] = 'main';
        $this->data['module_assets'] = 'cms/module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }

    public function create() {
        $this->data['view'] = 'create';
        $this->load->view('theme/admin/layout', $this->data);
    }

    public function edit($id = false) {
        if (!$id) {
            redirect('cms');
        } else {
            $this->data['record'] = $this->get_model_data($id);
            $this->data['view'] = 'edit';
            $this->load->view('theme/admin/layout', $this->data);
        }
    }

    public function process() {
        if ($this->input->post()) {
            $this->form_validation->set_error_delimiters('<span class="error">', '</span>');
            $this->form_validation->set_rules('page_title', 'page title', 'required|trim|xss_clean');
            $this->form_validation->set_rules('short_content', 'short content', 'trim|xss_clean');
            $this->form_validation->set_rules('content', 'content', 'required|trim|xss_clean');
            $this->form_validation->set_rules('meta_keyword', 'meta keyword', 'trim|xss_clean');
            $this->form_validation->set_rules('meta_description', 'meta description', 'trim|xss_clean');
            if ($this->form_validation->run() == TRUE) {
                $this->set_model_data();
                if ($this->input->post('id') == 'new') {
                    $inseretd = $this->cms_model->insert_data();
                    if($inseretd) {
                         $this->session->set_flashdata('success_message', 'Data inserted successfully.');
                    } else {
                        $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
                    }
                } else {
                    $updated = $this->cms_model->update_data();
                     if($updated) {
                         $this->session->set_flashdata('success_message', 'Data updated successfully.');
                    } else {
                        $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
                    }
                }
                redirect('cms');
            } else {
                if ($this->input->post('id') == 'new') {
                    $this->create();
                } else {
                    $this->edit($this->input->post('id'));
                }
            }
        }
    }

    public function delete($id = false) {
        if (!$id) {
            redirect('cms');
        } else {
            $this->cms_model->setId($id);
            $deleted = $this->cms_model->delete_data();
            if ($deleted) {
                $this->session->set_flashdata('success_message', 'Data deleted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
            redirect('cms');
        }
    }

    public function set_model_data() {
        $cmsObj = $this->cms_model;

        if ($this->input->post('id') != 'new') {
            $id = $this->input->post('id');
            $cmsObj->setId($id);
        }
        $page_title = $this->input->post('page_title');
        $cmsObj->setPageTitle($page_title);

        $short_content = $this->input->post('short_content');
        $cmsObj->setShortContent($short_content);

        $content = $this->input->post('content');
        $cmsObj->setContent($content);

        $meta_keyword = $this->input->post('meta_keyword');
        $cmsObj->setMetaKeyword($meta_keyword);

        $meta_description = $this->input->post('meta_description');
        $cmsObj->setMetaDescription($meta_description);

        $cmsObj->setStatus(1);
        $cmsObj->setCreatedOn();

        return true;
    }

    public function get_model_data($id) {
        $cmsObj = $this->cms_model;

        $cmsObj->setId($id);
        $cmsObj->get_row();

        $response = new stdClass();
        $response->id = $cmsObj->getId();
        $response->page_title = $cmsObj->getPageTitle();
        $response->short_content = $cmsObj->getShortContent();
        $response->content = $cmsObj->getContent();
        $response->meta_keyword = $cmsObj->getMetaKeyword();
        $response->meta_description = $cmsObj->getMetaDescription();
        return $response;
    }
    
    public function update_status() {
        $id = $this->input->get('id');
        if (!$id) {
            redirect('cms');
        } else {
            $this->cms_model->setId($id);

            $status = $this->input->get('status');
            $this->cms_model->setStatus($status);
            $this->cms_model->update_status();
            die;
        }
    }

}
