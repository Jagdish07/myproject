
<?php
    
    $input_div_open = '<div class="form-group">';
    $input_div_close = '</div>';
    $required = ' <abbr class="required"><i class="fa fa-asterisk"></i></abbr>';
    $action = 'cms/process';
    echo form_open($action);
        
        echo (isset($record->id)) ? form_hidden('id', $record->id) : form_hidden('id', 'new');
    
        echo $input_div_open;
            echo form_label('Page title'.$required, 'title');
            $page_title = array(
                'name' => 'page_title',
                'class' => 'form-control',
                'id' => 'title',
                'value' => (isset($record->page_title)) ? $record->page_title : set_value('page_title')
            );
            echo form_input($page_title);
            echo form_error('page_title');
        echo $input_div_close;
        
        echo $input_div_open;
            echo form_label('Short Content', 'short_content');
            $short_content = array(
                'name' => 'short_content',
                'class' => 'form-control',
                'id' => 'short_content',
                'value' => (isset($record->short_content)) ? $record->short_content : set_value('short_content')
            );
            echo form_textarea($short_content);
        echo $input_div_close;

        echo $input_div_open;
            echo form_label('Content'.$required, 'content');
            $content = array(
                'name' => 'content',
                'class' => 'form-control',
                'id' => 'content',
                'value' =>  (isset($record->content)) ? $record->content : set_value('content')
            );
            echo form_textarea($content);
            echo form_error('content');
        echo $input_div_close;
        
        echo $input_div_open;
            echo form_label('Meta keyword', 'meta_keyword');
            $meta_keyword = array(
                'name' => 'meta_keyword',
                'class' => 'form-control',
                'id' => 'meta_keyword',
                'value' =>  (isset($record->meta_keyword)) ? $record->meta_keyword : set_value('meta_keyword')
            );
            echo form_textarea($meta_keyword);
            echo form_error('meta_keyword');
        echo $input_div_close;
        
        echo $input_div_open;
            echo form_label('Meta description', 'meta_description');
            $meta_description = array(
                'name' => 'meta_description',
                'class' => 'form-control',
                'id' => 'meta_keyword',
                'value' =>  (isset($record->meta_description)) ? $record->meta_description : set_value('meta_description')
            );
            echo form_textarea($meta_description);
            echo form_error('meta_description');
        echo $input_div_close;
        
        $submit = array(
            'name' => 'submit',
            'class' => 'btn btn-info',
            'id' =>'submit',
            'value' => 'Submit'
        );
        echo form_submit($submit);
   echo form_close();
?>
<script type="text/javascript" src="<?php echo base_url();?>assets/ckeditor/ckeditor.js"></script>
<script type="text/javascript">
        CKEDITOR.replace('content');
</script>