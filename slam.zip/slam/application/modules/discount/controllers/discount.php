<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of discount
 *
 * @author wiesoftware26
 */
class Discount extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('discount_model');
         Myfunction();
    }

    public function index() {
        $this->data['view'] = 'main';
        $this->data['module_assets'] = 'discount/module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }

    public function create() {
        $this->data['view'] = 'create';
        $this->load->view('theme/admin/layout', $this->data);
    }

    public function edit($id = false) {
        if (!$id) {
            redirect('discount');
        } else {
            $this->data['record'] = $this->get_model_data($id);
            $this->data['view'] = 'edit';
            $this->load->view('theme/admin/layout', $this->data);
        }
    }

    public function process() {
        if ($this->input->post()) {
            $this->form_validation->set_error_delimiters('<span class="error">', '</span>');
            $this->form_validation->set_rules('discount', 'Discount', 'required|trim|xss_clean');
            $this->form_validation->set_rules('code', 'Code', 'trim|xss_clean');
            $this->form_validation->set_rules('description', 'Description', 'required|trim|xss_clean');
            if ($this->form_validation->run() == TRUE) {
                $this->set_model_data();
                if ($this->input->post('id') == 'new') {
                    $inseretd = $this->discount_model->insert_data();
                    if($inseretd) {
                         $this->session->set_flashdata('success_message', 'Data inserted successfully.');
                    } else {
                        $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
                    }
                } else {
                    $updated = $this->discount_model->update_data();
                     if($updated) {
                         $this->session->set_flashdata('success_message', 'Data updated successfully.');
                    } else {
                        $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
                    }
                }
                redirect('discount');
            } else {
                if ($this->input->post('id') == 'new') {
                    $this->create();
                } else {
                    $this->edit($this->input->post('id'));
                }
            }
        }
    }

    public function delete($id = false) {
        if (!$id) {
            redirect('discount');
        } else {
            $this->discount_model->setId($id);
            $deleted = $this->discount_model->delete_data();
            if ($deleted) {
                $this->session->set_flashdata('success_message', 'Data deleted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
            redirect('discount');
        }
    }

    public function set_model_data() {
        $discountObj = $this->discount_model;

        if ($this->input->post('id') != 'new') {
            $id = $this->input->post('id');
            $discountObj->setId($id);
        }
        $discount = $this->input->post('discount');
        $discountObj->setDiscount($discount);

        $code = $this->input->post('code');
        $discountObj->setCode($code);

        $description = $this->input->post('description');
        $discountObj->setDescription($description);

      /*   $discountObj->setStatus(1);
        $discountObj->setCreatedOn(); */

        return true;
    }

    public function get_model_data($id) {
        $discountObj = $this->discount_model;

        $discountObj->setId($id);
        $discountObj->get_row();

        $response = new stdClass();
        $response->id = $discountObj->getId();
        $response->discount = $discountObj->getDiscount();
        $response->code = $discountObj->getCode();
        $response->description = $discountObj->getDescription();
        return $response;
    }
    
    public function update_status() {
        $id = $this->input->get('id');
        if (!$id) {
            redirect('discount');
        } else {
            $this->discount_model->setId($id);

            $status = $this->input->get('status');
            $this->discount_model->setStatus($status);
            $this->discount_model->update_status();
            die;
        }
    }

}
