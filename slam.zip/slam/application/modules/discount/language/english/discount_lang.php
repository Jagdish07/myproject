<?php

/* Cms lang */

$lang['page_title'] = "Page title";
$lang['short_content'] = "Short Content";
$lang['content'] = "Content";
$lang['meta_keyword'] = "Meta keyword";
$lang['meta_description'] = "Meta description";
$lang['add_page'] = "Add page";
$lang['page_form'] = "Page form";
$lang['page_list'] = "Pages list";
$lang['cms_placeholder'] = "Search page by name";
$lang['edit_page'] = "Edit page";



