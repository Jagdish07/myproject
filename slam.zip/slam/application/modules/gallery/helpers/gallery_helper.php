<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(!function_exists('gallery_path')) {
    function gallery_path($type=false){
        $properties = get_properties();
        if($type) {
            return $properties->gallery_thumb;
        } else {
            return $properties->gallery_path;
        }
    }
}
