<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of gallery_model
 *
 * @author wiesoftware26
 */
class Gallery_model extends CI_Model {
    
    private $id;
    
    private $title;
    
    private $image;
    
    private $created_on;
    
    private $updated_on; 
    
    private $status;
    
    private $sequence;
    
    private $queryString;
    
    private $whereOrAnd;
    
    private $where;


    private $tbl_name = 'tbl_gallery';
    function __construct() {
        parent::__construct();
    }
    
    public function getId(){
        return $this->id;
    }
    
    public function setId($param) {
        $this->id = $param;
    }

    public function setTitle($title){
        $this->title = $title;
    }
    
    public function getTitle(){
        return $this->title;
    }
    
     public function setImage($param) {
        $this->image = $param;
    }
    
    public function getImage() {
        return $this->image;
    }
    
    public function setStatus($param) {
        $this->status = $param;
    }
    
    public function getStatus() {
        return $this->status;
    }
    
    public function setSequence($param) {
        $this->sequence = $param;
    }
    
    public function getSequence() {
        return $this->sequence;
    }
    
    public function setUpdatedOn() {
        $this->updated_on = date('Y-m-d H:i:s');
    }
    
    public function getUpdatedOn() {
        return $this->updated_on;
    }
    
    public function setCreatedOn() {
        $this->created_on = date('Y-m-d H:i:s');
    }
    
    public function getCreatedOn() {
        return $this->created_on;
    }
    
     public function insert_data() {
        $post_data = $this->get_post_values();
        $post_data->created_on = $this->getCreatedOn();
        return $this->db->insert($this->tbl_name, $post_data);
    }
    
    public function get_post_values() {
        $post_data = new stdClass();
        $post_data ->title = $this->getTitle();
        if($this->getImage() != '') {
            $post_data->image = $this->getImage();
        }
        $post_data->sequence = $this->getSequence();
        $post_data->status = $this->getStatus();
        return $post_data;
    }
    
    public function get_row() {
        $id = $this->getId();
        $this->db->where('id', $id);
        $row = $this->db->get($this->tbl_name)->row();
        if($row) {
            $this->setId($row->id);
            $this->setImage($row->image);
            $this->setTitle($row->title);
            $this->setSequence($row->sequence);
            return $this;
        } else {
            return false;
        }
    }
    
    public function update_data() {
        $post_data = $this->get_post_values();
        $id = $this->getId();
        $post_data->updated_on = $this->getUpdatedOn();
        
        
        $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    
   public function delete_data() {
        $id = $this->getId();
        $this->db->where('id', $id);
        $deleted = $this->db->delete($this->tbl_name);
        if($deleted) {
             $row = $this->get_row();
            @unlink(gallery_path().$this->getImage());
            @unlink(gallery_path('thumb').$this->getImage());
            alter_auto_increment($this->tbl_name, 'id');
            return true;
        } else {
            return false;
        }
    }
    
    public function update_status() {
        $id = $this->getId();
        $post_data = new stdClass();
        $post_data->status = $this->getStatus();
        $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    
    public function update_sequence() {
        $id = $this->getId();
        $post_data = new stdClass();
        $post_data->sequence = $this->getSequence();
        $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    
    public function set_where_name($name=false) {
        if ($name) {
            $this->whereOrAnd = " WHERE ";
            $this->where = " title LIKE '%" . $name . "%' ";
        }
        $this->queryString = $this->whereOrAnd . $this->where;

        $response = new stdClass();
        $response->query_string = $this->queryString;
        $response->title = $name;

        return $response;
    }
    
     public function get_post_data() {
        $postData = new stdClass();
        $postData->sort = $this->input->post('sort');
        $postData->order = $this->input->post('order');
        $postData->page = $this->input->post('page');
        $postData->limit = $this->input->post('limit');
        $postData->name = $this->input->post('name');
        $postData->field = $this->input->post('type');
        $postData->section = $this->input->post('section');
        return $postData;
    }
    
    public function get_all(){
        $this->db->select('id, title, image');
        $this->db->where('status', 1);
        $this->db->order_by('sequence ASC');
        return $this->db->get($this->tbl_name)->result();
    }
    
    public function get_list() {
        $postData = $this->get_post_data();
        /*
         * Count All results
         */
        $this->set_where_name($postData->name);
        $queryCount = "SELECT count(*) as num_records FROM " . $this->tbl_name;
        $queryCountRun = $this->db->query($queryCount . $this->whereOrAnd . $this->where);
        $queryCountResult = $queryCountRun->row();

        /*
         * Get All records
         */
        $query = "SELECT * FROM " . $this->tbl_name;
        $orderObj = set_order($postData->sort, $postData->order);
        $limitObj = set_limit($postData->page, $postData->limit);
        $queryString = $query . $this->whereOrAnd . $this->where . $orderObj->query_string . $limitObj->query_string;
        $queryRun = $this->db->query($queryString);
        $queryResult = $queryRun->result();

        $params = request_params($queryCountResult->num_records, $orderObj->sort, $orderObj->order, $limitObj->limit, $limitObj->page, $limitObj->start, $postData->field);

        $response = new stdClass();
        $response->params = $params;
        $response->result = $queryResult;
        return $response;
    }
}
