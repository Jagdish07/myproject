<?php
    
    $input_div_open = '<div class="form-group">';
    $input_div_close = '</div>';
    $required = ' <abbr class="required"><i class="fa fa-asterisk"></i></abbr>';
    $action = 'gallery/process';
    echo form_open_multipart($action);
        
        echo (isset($record->id)) ? form_hidden('id', $record->id) : form_hidden('id', 'new');
    
        echo $input_div_open;
            echo form_label('Title'.$required, 'title');
            $title = array(
                'name' => 'title',
                'class' => 'form-control',
                'id' => 'title',
                'value' => (isset($record->title)) ? $record->title : set_value('title')
            );
            echo form_input($title);
            echo form_error('title');
        echo $input_div_close;
        
        echo form_label('Image'.$required, 'image');
        echo '<div class="form-group input-group" style="width: 300px;cursor:pointer;">';
            
            $file = array(
                'name' => 'file',
                'id' => 'image',
                'style' => 'padding:0px;opacity: 0;'
            );
            echo '<span class="form-control">';
            echo '<span id="file_msg">No file selected.</span>';
            echo form_upload($file);
            echo '</span><span class="input-group-addon" id="select_file">Browse</span>';
        echo $input_div_close;
       
        echo (isset($error)) ? $error : '';
        
        echo $input_div_open;
            echo form_label('Sequence', 'sequence');
            $sequence = array(
                'name' => 'sequence',
                'class' => 'form-control',
                'id' => 'sequence',
                'value' =>  (isset($record->sequence)) ? $record->sequence : set_value('sequence')
            );
            echo form_input($sequence);
            echo form_error('sequence');
        echo $input_div_close;
        
        $submit = array(
            'name' => 'submit',
            'class' => 'btn btn-info',
            'id' =>'submit',
            'value' => 'Submit'
        );
        echo form_submit($submit);
   echo form_close();