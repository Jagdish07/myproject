<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(!function_exists('icons_path')) {
    function icons_path($type=false){
      //  echo "dgf"; die;
         
        $properties = get_properties();
         
        if($type=='thumb') {
       
            return $properties->icon_thumb;
        } else if($type== 'used') {

        	 return $properties->icon_used;

        }else{
             
            return $properties->icon_path;
        }
    }
}
