<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

echo link_admin_js(
            array(
                'jquery.typing-0.2.0.min.js',
                'dynamic_view_redraw.js'
            )
);

echo link_admin_module_js(
            array(
                'search.js'
            ),
          'icons'
);

?>
<script type="text/javascript">
    load_icons();
</script>