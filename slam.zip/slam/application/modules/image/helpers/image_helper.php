<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(!function_exists('image_path')) {
    function image_path($type=false){
        $properties = get_properties();
        if($type) {
            return $properties->image_thumb;
        } else {
            return $properties->image_path;
        }
    }
}
