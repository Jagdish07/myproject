<div class="row">
    <div class="col-md-12">
        <h1 class="page-header">
           Edit Welcome Image 
           <a href="<?php echo base_url('image');?>" class="btn btn-primary pull-right"><i class="fa fa-hand-o-left"></i> Back</a>
        </h1>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-list"></i> Welcome Image form
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-6">
                        <?php echo $this->load->view('form');?>
                    </div>
                    <div class="col-md-6">
                        <h4>Current image</h4>
                        <hr class="whiter" />
                        <img src="<?php echo base_url().image_path('thumb') . $record->image;?>" alt="<?php echo $record->title;?>" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>