<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    function __construct() {
        parent:: __construct();
        $this->load->model('auth_model');
        check_user_logged();
    }

    public function index() {
       $this->load->view('login/main');
    }

    public function process() {
        $this->form_validation->set_rules('username', 'username', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        if ($this->form_validation->run() == FALSE) {
           _render_page('login/main');
        } else {
            $user_name = $this->input->post('username');
            $password = $this->input->post('password');
            $this->auth_model->setUsername($user_name);
            $this->auth_model->setPassword($password);
            $validate = $this->auth_model->validate_user();
//print_R($validate); die;
            if(!empty($validate)) {
                $userdata = array();
                $userdata['slamuser_id'] = $validate->id;
                $userdata['slamusername'] = $validate->username;
                $userdata['slamfirst_name'] = $validate->first_name;
                $userdata['slamlast_name'] = $validate->last_name;
                $userdata['slamroles'] = $validate->roles;
                $userdata['slamemail'] = $validate->email;
                $userdata['slamadminis_logged_user'] = TRUE;
                $this->session->set_userdata($userdata);
                redirect('admin');
            } else {
                $this->session->set_flashdata('message', 'Username or password is incorrect. Please try again.');
                redirect('login/auth');
            }
        }
    }
    public function forget_password() {
           if($this->input->post()) {
               $this->form_validation->set_rules('email', 'email', 'required');
               if($this->form_validation->run() == TRUE) {
                        $email = $this->input->post('email');
                        $this->auth_model->setEmail($email);
                        $validate = $this->auth_model->checkUserEmail();
                        if(!empty($validate)) {
                            // need send email
                            $this->session->set_flashdata('success_message', 'Password reset request send to your email.');
                               redirect('login/auth/forget_password');
                            } else {
                            $this->session->set_flashdata('error_message', 'This email is not associated with any account.');
                            redirect('login/auth/forget_password');    
                    }
               }
           }
         $this->load->view('login/forget_password');
    }
}

