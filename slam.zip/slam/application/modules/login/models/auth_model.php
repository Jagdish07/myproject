<?php

if (!defined('BASEPATH')) {
    exit('No Direct Script access allowed');
}

class Auth_model extends CI_Model {

    private $tbl_name = 'tbl_login';
    private $tbl_setting = 'tbl_setting';
    
    private $user_name;
    
    private $password;
    
    private $email;
    
    function __construct() {
        parent::__construct();
    }
    
    public function setUsername($username) {
        $this->user_name =    $username; 
    }
    public function setEmail($email) {
        $this->email = $email;
    }
    public function getEmail() {
        return $this->email;
    }
    public function getUsername() {
        return $this->user_name;
    }
    public function setPassword($password){
        $this->password = $password;
    }
    public function getPassword(){
        return $this->password;
    }
    public function validate_user() {
        $username = $this->getUsername();
        $password = $this->getPassword();
        $this->db->select('*');
        $this->db->where('username', $username);
        $this->db->where('password', md5($password));
        return $this->db->get($this->tbl_name)->row();
    }
    public function checkUserEmail(){
        $email = $this->getEmail();
        $this->db->select('*');
        $this->db->where('email', $email);
        return $this->db->get($this->tbl_name)->row();
    }
    public function change_site_status(){
        $this->db->select('*');
        $result= $this->db->get($this->tbl_setting)->row();
        if($this->input->post('value')){
        $data['collection']=$this->input->post('value');
         $data['delivery']=$this->input->post('deliveryvalue');
        $this->db->where('id',$result->id);
        return $this->db->update($this->tbl_setting,$data);

        }else{
           // print_R($_POST); die;
        $data['status']=$this->input->post('status');
        $this->db->where('id',$result->id);
        return $this->db->update($this->tbl_setting,$data);
       }

    }
    public function password_validate(){
        $password = $this->getPassword();
        $this->db->select('*');
        $this->db->where('id', $this->session->userdata('user_id'));
        $this->db->where('password', md5($password));
        return $this->db->get($this->tbl_name)->row();
    }
    public function update_password() {
        $password = $this->getPassword();
        $this->db->where('id', $this->session->userdata('user_id'));
        return $this->db->update($this->tbl_name, array('password' => md5($password)));
    }
}

