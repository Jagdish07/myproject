<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo site_name(); ?> | Admin</title>

        <?php
        echo link_admin_module_css(
                array(
            'style.css'
                ), 'login'
        );
        ?> 
        <?php
        echo link_admin_module_js(
                array(
            'prefixfree.min.js'
                ), 'login'
        );
        ?>    

    </head>

    <body>

        <div class="body" style="background-image: url(<?php echo link_front_image('70411e23db4416644e8d4b321af9ba9a.jpg'); ?>);"></div>
        <div class="header">
            <div><img src="<?php echo link_front_image('logo.png'); ?>" alt=""/></div>
        </div>
        <br>
        <div class="login">
            <?php if($this->session->flashdata('error_message') != '') { ?>
                 <div class="alert alert-danger"><?php echo $this->session->flashdata('error_message');?></div>
            <?php } elseif ($this->session->flashdata('success_message') != '') { ?>
                   <div class="alert alert-success"><?php echo $this->session->flashdata('success_message');?></div>
           <?php  } ?>
            <?php echo form_open('login/auth/forget_password'); ?>
            <input type="text" placeholder="Email" name="email"><br>
            <?php echo form_error('username'); ?>
            <input type="submit" value="Submit" /><br>
            <a href="<?php echo base_url('login');?>">Login</a>	
            <?php echo form_close(); ?>			
        </div>
    </body>
</html>



