<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo site_name(); ?> | Admin</title>

        <?php
        echo link_admin_module_css(
                array(
            'style.css'
                ), 'login'
        );
        ?> 
        <?php
        echo link_admin_module_js(
                array(
            'prefixfree.min.js'
                ), 'login'
        );
        ?>    

    </head>

    <body>

        
        
        <div class="col-md-12">
       
       
        <div class="login">
             <div class="header">
            <div><img src="<?php echo link_front_image('logo.png'); ?>" alt=""/></div>
        </div>
            <?php echo form_open('login/auth/process'); ?>
            <input type="text" placeholder="username" name="username"><br>
            <?php echo form_error('username'); ?>
            <input type="password" placeholder="password" name="password"><br>
            <?php echo form_error('password'); ?>
            <input type="submit" value="Login" /><br>
            <a href="<?php echo base_url('login/auth/forget_password');?>">Forget your password?</a>	
            <?php echo form_close(); ?>			
        </div>
    </div>
    </body>
</html>
