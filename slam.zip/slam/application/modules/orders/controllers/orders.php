<?php
error_reporting(0);
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of products
 *
 * @author wiesoftware26
 */
class Orders extends CI_Controller {
    
    function __construct() {
        parent::__construct();
         Myfunction();
        $this->load->model('orders_model');
    }
    
     public function index() {
        $this->data['view'] = 'main';
        $this->data['module_assets'] = 'orders/module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }
     public function view_data($id, $print_all='') {

        if($id){
       $orderdetail=$this->orders_model->get_order_detail($id);
       
      }
      
      if($orderdetail->user_id == '0' && $orderdetail->guest_id!='0'){
         $shipdetail = get_guest_userdetail($orderdetail->guest_id);

         if($shipdetail->guest_id!='0'){
            $userdetail =get_guest_userdetail($shipdetail->guest_id);
         }else{
          $userdetail = $shipdetail;
         }
      }
      if($orderdetail->user_id != '0' && $orderdetail->guest_id != '0'){
          $userdetail =get_customer_billing_detail($orderdetail->user_id);
          $shipdetail = get_guest_userdetail($orderdetail->guest_id);
       }
       if($orderdetail->user_id != '0' && $orderdetail->guest_id == '0'){
          $userdetail =get_customer_billing_detail($orderdetail->user_id);
          $shipdetail=$userdetail;
       }
      
      

      $orderproductdetail=$this->orders_model->get_product_detail($id);
      
        $this->data['orderproductdetail'] = $orderproductdetail;
         $this->data['userdetail'] = $userdetail;
          $this->data['shipdetail'] = $shipdetail;
          $this->data['orderdetail'] = $orderdetail;
		  if($print_all){
			   return $this->data;
		  }
		
        $this->data['view'] = 'view';
        $this->data['module_assets'] = 'orders/module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }
	public function update_status() {
      
        $id = $this->input->get('id');
        if (!$id) {
            redirect('orders');
        } else {

            $this->orders_model->setId($id);

            $status = $this->input->get('status');
            $this->orders_model->setOrderStatus($status);
            $this->orders_model->update_status();
            die;
        }
    }
     public function delete($id = false) {
        if ($id) {
            $this->orders_model->setId($id);
            $deleted = $this->orders_model->delete_data();
            if ($deleted) {
                $this->session->set_flashdata('success_message', 'Data deleted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        }
        redirect('orders');
    }
    public function submit()
  {
    $data = array(
        'max_item' => $this->input->post('name')
        );
     //print_r($data); die;
    $result = $this->orders_model->add_item($data);
    redirect('orders');
    
  }

  	public function print_all_order(){
		
		$order_ids = $this->input->post('order_data_view');
		//print '<pre>'; print_r($order_ids); die;
		$all_order_data= array();
		foreach($order_ids as $order_id){
			$all_order_data[] = $this->view_data($order_id, 'print_all');
		}
		//print '<pre>'; print_r($all_order_data); die;
		$this->data['order_details'] = $all_order_data;
		$this->data['view'] = 'print_all_order';
		$this->data['module_assets'] = 'orders/module_assets';
		$this->load->view('theme/admin/layout', $this->data);
	}
}
