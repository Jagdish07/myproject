<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of products_model
 *
 * @author wiesoftware26
 */
class Orders_model extends CI_Model{
    
    private $id;
    
    private $no_of_person;
    
    private $res_date;
    
    private $res_time;
    
    private $note;
    
    
    private $is_reserved;
    
    private $is_active;

    private $created_on;
    
    private $updated_on;
    
    private $queryString;
    
    private $whereOrAnd;
    
    private $where;
    
    private $tbl_name = 'tbl_order';
            
    function __construct() {
        parent::__construct();
    }
    
    public function getId(){
        return $this->id;
    }
    
    public function setId($id) {
        $this->id = $id;
    }
    public function getOrderStatus(){
        return $this->order_status;
    }
    
    public function setOrderStatus($status) {
        $this->order_status = $status;
    }
    public function get_order_detail($id){
        $this->db->select('*');
        $this->db->from('tbl_order');
        $this->db->where('tbl_order.id',$id);
        $this->db->join('tbl_payment_method','tbl_order.id=tbl_payment_method.order_id');
        return  $this->db->get()->row();
     
    }
  public function get_product_detail($id){
         $this->db->select('*');
         $this->db->where('order_id',$id);
       return  $this->db->get('tbl_buy_product')->result();
     
    }
   
   public function add_item($data)
    {
        $this->db->where('id','1');
        return $this->db->update('tbl_setting', $data);
        
    }
    
    
  
    public function get_post_values() {
        $post_data = new stdClass();
        $post_data ->no_of_person = $this->getTitle();
        $post_data->res_date = $this->getSlug();
        $post_data->res_time = $this->getPrice();
        $post_data->note = $this->getCategoryId();
        return $post_data;
    }
    
     public function update_data() {
        $post_data = $this->get_post_values();
        $id = $this->getId();
        $string = $this->input->post('string');
         $this->setString($string, $id);
        $post_data->updated_on = $this->getUpdatedOn();
        $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    
  
    
    public function delete_data() {
        $id = $this->getId();
        $this->db->where('id', $id);
        $deleted = $this->db->delete($this->tbl_name);
        $deleted = $this->db->delete('tbl_buy_product',array('order_id'=>$id));
        
          $deleted = $this->db->delete('tbl_payment_method',array('order_id'=>$id));
        if($deleted) {
            alter_auto_increment($this->tbl_name, 'id');
            return true;
        } else {
            return false;
        }
    }
    
    public function update_status() {
        $id = $this->getId();
        $post_data = new stdClass();
        $post_data->order_status = $this->getOrderStatus();
	    $this->db->where('id', $id);
         return $this->db->update($this->tbl_name, $post_data);
        
       
    }
    
     public function set_where_name($name=false) {
        if ($name) {
            $this->whereOrAnd = " AND ";
            $this->where = " ord.id LIKE '%" . $name . "%'  OR user.name LIKE '%" . $name . "%'";
        }
        $this->queryString = $this->whereOrAnd . $this->where;

        $response = new stdClass();
        $response->query_string = $this->queryString;
        $response->res_datetime = $name;

        return $response;
    }
    
    public function get_post_data() {
        $postData = new stdClass();
        $postData->sort = $this->input->post('sort');
        $postData->order = $this->input->post('order');
        $postData->page = $this->input->post('page');
        $postData->limit = $this->input->post('limit');
        $postData->name = $this->input->post('name');
        $postData->field = $this->input->post('type');
        $postData->section = $this->input->post('section');
        return $postData;
    }
    
    public function get_list() {
        $postData = $this->get_post_data();
        /*
         * Count All results
         */
        $this->set_where_name($postData->name);
$queryCount ="SELECT count(*) as num_records, ord.`id`,  ord.`order_date` , ord.`order_status` , ord.`payment_method` , ord.`delivery_date` ,  ord.`order_total` ,  pay.`amt` , pay.`charge_id` as payment_id
FROM `tbl_order` AS ord, `tbl_payment_method` AS pay
WHERE  ord.`id` = pay.`order_id` ";
        //$queryCount = "SELECT count(*) as num_records FROM " . $this->tbl_name;
        $queryCountRun = $this->db->query($queryCount . $this->whereOrAnd . $this->where);
        $queryCountResult = $queryCountRun->row();

        /*
         * Get All records
         */
       //$query = "SELECT * FROM " . $this->tbl_name;
 $query ="SELECT ord.`id` ,  ord.`order_date` ,ord.`preferece`, ord.`order_status` , ord.`payment_method` , ord.`delivery_date` , ord.`order_total` ,pay.`amt` , pay.`charge_id` as payment_id
FROM `tbl_order` AS ord,  `tbl_payment_method` AS pay
WHERE  ord.`id` = pay.`order_id` ";       

$orderObj = set_order($postData->sort, $postData->order);
        $limitObj = set_limit($postData->page, $postData->limit);
        $queryString = $query . $this->whereOrAnd . $this->where . $orderObj->query_string . $limitObj->query_string;
        $queryRun = $this->db->query($queryString);
        $queryResult = $queryRun->result();

        $params = request_params($queryCountResult->num_records, $orderObj->sort, $orderObj->order, $limitObj->limit, $limitObj->page, $limitObj->start, $postData->field);

        $response = new stdClass();
        $response->params = $params;
        $response->result = $queryResult;
        return $response;
    }
}
