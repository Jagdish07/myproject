<div class="row">
    <div class="col-md-12">
        <h1 class="page-header">
           Add product
           <a href="<?php echo base_url('products');?>" class="btn btn-primary pull-right"><i class="fa fa-hand-o-left"></i> Back</a>
        </h1>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-list"></i> Product form
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        
                        <?php echo $this->load->view('form');?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>