<?php
$input_div_open = '<div class="form-group">';
$input_div_close = '</div>';
$required = ' <abbr class="required"><i class="fa fa-asterisk"></i></abbr>';
$action = 'products/process';
?>
<ul class="nav nav-tabs">
    <li class="active">
        <a href="#general" data-toggle="tab">General</a>
    </li>
    <li class="">
        <a href="#seo" data-toggle="tab">SEO</a>
    </li>
    <li class="">
        <a href="#inventory" data-toggle="tab">Inventory</a>
    </li>
    <li class="">
        <a href="#custom" data-toggle="tab">Custom fields</a>
    </li>
</ul>
<?php
echo form_open_multipart($action);
echo (isset($record->id)) ? form_hidden('id', $record->id) : form_hidden('id', 'new');
?>
<div class="tab-content">
    <div class="tab-pane fade active in" id="general">
        <h4>General information</h4>
        <hr class="whiter"/>
        <div class="row">
            <div class="col-md-8">
                <?php
                echo $input_div_open;
                echo form_label('Title' . $required, 'title');
                $title = array(
                    'name' => 'title',
                    'class' => 'form-control',
                    'id' => 'title',
                    'value' => (isset($record->title)) ? $record->title : set_value('title')
                );
                echo form_input($title);
                echo form_error('title');
                echo $input_div_close;
                
                echo $input_div_open;
                echo form_label('Price' . $required, 'price');
                $price = array(
                    'name' => 'price',
                    'class' => 'form-control',
                    'id' => 'price',
                    'value' => (isset($record->price)) ? $record->price : set_value('price')
                );
                echo form_input($price);
                echo form_error('price');
                echo $input_div_close;

                echo $input_div_open;
                echo form_label('Sku', 'sku');
                $sku = array(
                    'name' => 'sku',
                    'class' => 'form-control',
                    'id' => 'sku',
                    'value' => (isset($record->sku)) ? $record->sku : set_value('sku')
                );
                echo form_input($sku);
                echo form_error('sku');
                echo $input_div_close;

                echo $input_div_open;
                echo form_label('Alias' . $required, 'slug');
                $slug = array(
                    'name' => 'slug',
                    'class' => 'form-control',
                    'id' => 'slug',
                    'value' => (isset($record->slug)) ? $record->slug : set_value('slug')
                );
                echo form_input($slug);
                echo form_error('slug');
                echo $input_div_close;

                echo $input_div_open;
                echo form_label('Category ' . $required, 'category');
                $attr = 'class="form-control" style="width:250px"';
                $selected = (isset($record->category_id)) ? $record->category_id : '';
                echo form_dropdown('category', $category, $selected, $attr);
                echo form_error('category');
                echo $input_div_close;

                echo $input_div_open;
                echo form_label('Description', 'description');
                $description = array(
                    'name' => 'description',
                    'class' => 'form-control',
                    'id' => 'description',
                    'value' => (isset($record->description)) ? $record->description : set_value('description')
                );
                echo form_textarea($description);
                echo form_error('description');
                echo $input_div_close;

                echo $input_div_open;
                echo form_label('Short description', 'short_description');
                $short_description = array(
                    'name' => 'short_description',
                    'class' => 'form-control',
                    'id' => 'short_description',
                    'rows' => '4',
                    'value' => (isset($record->short_description)) ? $record->short_description : set_value('short_description')
                );
                echo form_textarea($short_description);
                echo form_error('short_description');
                echo $input_div_close;

                echo $input_div_open;
                echo form_label('Internal notes', 'notes');
                $notes = array(
                    'name' => 'notes',
                    'class' => 'form-control',
                    'id' => 'notes',
                    'rows' => '4',
                    'value' => (isset($record->notes)) ? $record->notes : set_value('notes')
                );
                echo form_textarea($notes);
                echo form_error('notes');
                echo $input_div_close;

                echo $input_div_open;
                echo form_label('Sequence', 'sequence');
                $sequence = array(
                    'name' => 'sequence',
                    'class' => 'form-control',
                    'id' => 'sequence',
                    'style' => 'width:250px',
                    'value' => (isset($record->sequence)) ? $record->sequence : set_value('sequence')
                );
                echo form_input($sequence);
                echo form_error('sequence');
                echo $input_div_close;
                ?>
            </div>
        </div>
    </div>  
    <div class="tab-pane fade" id="seo">
        <h4>Meta information</h4>
        <hr class="whiter"/>
        <?php
        echo $input_div_open;
        echo form_label('Page title', 'title');
        $page_title = array(
            'name' => 'page_title',
            'class' => 'form-control',
            'id' => 'title',
            'value' => (isset($record->page_title)) ? $record->page_title : set_value('page_title')
        );
        echo form_input($page_title);
        echo form_error('page_title');
        echo $input_div_close;

        echo $input_div_open;
        echo form_label('Meta keyword', 'meta_keyword');
        $meta_keyword = array(
            'name' => 'meta_keyword',
            'class' => 'form-control',
            'id' => 'meta_keyword',
            'value' => (isset($record->meta_keyword)) ? $record->meta_keyword : set_value('meta_keyword')
        );
        echo form_textarea($meta_keyword);
        echo form_error('meta_keyword');
        echo $input_div_close;

        echo $input_div_open;
        echo form_label('Meta description', 'meta_description');
        $meta_description = array(
            'name' => 'meta_description',
            'class' => 'form-control',
            'id' => 'meta_keyword',
            'value' => (isset($record->meta_description)) ? $record->meta_description : set_value('meta_description')
        );
        echo form_textarea($meta_description);
        echo form_error('meta_description');
        echo $input_div_close;
        ?>
    </div>
    <div class="tab-pane fade" id="inventory">
        <h4>Inventory</h4>
        <hr class="whiter"/>
        <?php
        echo $input_div_open;
        echo form_label('Availability', 'in_stock');
        $options = array(
            '1' => 'In stock',
            '0' => 'Out of stock'
        );
        $attr = 'class="form-control" style="width:250px"';
        $in_stock = (isset($record->in_stock)) ? $record->in_stock : '';
        echo form_dropdown('in_stock', $options, $in_stock, $attr);
        echo form_error('in_stock');
        echo $input_div_close;

        echo $input_div_open;
        echo form_label('Featured', 'featured');
        $featured = array(
            'name' => 'featured',
            'id' => 'featured',
            'checked' => (isset($record->featured) == 1) ? true : false ,
            'value' => '1',
            'style' => 'margin-left: 5px;'
        );
        echo form_checkbox($featured);
        echo form_error('featured');
        echo $input_div_close;
        ?>
    </div> 
    <div class="tab-pane fade" id="custom">
        <h4>Custom type fields</h4>
        <hr class="whiter"/>
        <?php  
            echo $input_div_open;
            echo form_label('Checkbox string', 'string');
            $string = array(
                'name' => 'string',
                'class' => 'form-control',
                'id' => 'string',
                'rows' => '4',
                'value' => (isset($record->string)) ? $record->string : set_value('string')
            );
            echo form_textarea($string);
            echo form_error('string');
            echo $input_div_close;
        ?>
    </div> 
</div>

<?php
$submit = array(
    'name' => 'submit',
    'class' => 'btn btn-info',
    'id' => 'submit',
    'value' => 'Submit'
);
echo form_submit($submit);

echo form_close();
?>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/ckeditor/ckeditor.js"></script>
<script type="text/javascript">
    CKEDITOR.replace('description');
</script>