
<style>

.righ-address span{ display:block; font-size:18px;}
.righ-address a{ color:#000; font-size:18px; text-transform:uppercase; display:block; margin-top:18px;}
.send-address span{ display:block; font-size:18px;}
.content-table th,.content-table td{ border:1px solid black;}
.content-table strong{background:#cdcdcd; display:block;}
.table-data table td{ min-width:100px !important;}

.table-data { width:90% !important; margin:0 auto;}
.sub-total-table { text-align:right; margin-bottom:70px;}

.sub-total-table tr:first-child td:nth-child(2){  width:141px !important;}
.sub-total-table td {height:25px !important; }
.sub-total-table span{ min-width:52px; display:block; }
.sub-total-table { float:right;}
.table-comment{ clear:both; border-top:1px solid black; padding-top:30px; margin-bottom:40px;}
.table-comment p{ font-size:20px;text-align:center; }
.table-bordered {
    border: 1px solid #FEFCFC;
}

</style>

<div class="row">
   
    <div class="col-md-12">
        <h1 class="page-header">
          View Order

           <a href="<?php echo base_url('orders');?>" class="btn btn-primary pull-right"><i class="fa fa-hand-o-left"></i> Back</a>
        </h1>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default" id="panel">
            <div class="panel-heading">
                <i class="fa fa-list"></i> 
                <a href="javascript:void(0);" onclick="Popup();"><strong><i class="fa fa-print"></i> Print receipt</strong></a>
            </div>
			<?php
//print '<pre>'; print_r($order_details);
			foreach($order_details as $key=>$order_id){
				//print '<pre>'; print_r($order_id['orderdetail']); 
				$orderdetail = $order_id['orderdetail'];
				$shipdetail = $order_id['shipdetail'];
				$userdetail = $order_id['userdetail'];
				$orderproductdetail = $order_id['orderproductdetail'];
			?>
            <div class="panel-body" id="panel-body">
                <div class="row">
                    <div class="col-md-12">
                       <div class="row">
                    <div class="col-sm-8 col-md-8 col-lg-8">
                        <a href="#"><img src="<?php echo base_url();?>assets/admin/img/logo.png" alt="logo"></a>
                    </div>
                    <div class="col-sm-4 col-md-4 col-lg-4 righ-address">
                        <address>
                            <span>From:</span>   
              <span><strong>slam</strong></span>                          
                            <span> Viale della Moschea</span>
                             <span> 85 , 00197 Roma</span>
                            <span>Italy</span>
                            <a href="#"></a>
                        </address>
                    
                    </div>
                </div>
                
               <div class="row">
		<div class="col-sm-6 col-md-6 col-lg-6 send-address">
		<address>
		<span>Send to:</span>
		<span><strong><?php echo $order_id['userdetail']->title.' '.$order_id['userdetail']->first_name.' '.$order_id['userdetail']->last_name?></strong></span>
		<span><?php echo $order_id['shipdetail']->address1;?></span>
		<span><?php echo $order_id['shipdetail']->city;?></span>
		<span><?php echo $order_id['shipdetail']->post_code;?></span>
		<span><?php echo $order_id['shipdetail']->phone_no;?>,<?php echo $order_id['shipdetail']->phone2;?></span>
		<span>United Kingdom</span>
		</address>
		</div>
		<div class="col-sm-6 col-md-6 col-lg-6 send-address">
		<address>
		<span>Transaction Details:</span>
		<span>Transaction Id :<strong><?php echo $order_id['orderdetail']->charge_id;?></strong></span>
		<span>Payment Date: <?php echo $order_id['orderdetail']->Payment_Date;?></span>
		<span>Pay Ammount :£ <?php echo $order_id['orderdetail']->amt;?></span>
		<span>Email : <?php echo $order_id['orderdetail']->email;?></span>
		
		</address>
		</div>
		</div>
                
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 table-data">
                       <table class="table table-bordered">
                            
                           
                          
                            <tr>
                                <th><strong>Quantity</strong></th>
                               
                               
                                <th><strong>Item name</strong></th>
                                <th><strong>Price</strong></th>
                                <th><strong>Subtotal</strong></th>
                                
                            </tr>
                            <?php foreach($orderproductdetail as $product){
                                if($product->product_id!='0'){
                                       $productdetail= get_product_detail($product->product_id);
                                     }
                                if($product->meal_id!='0'){
                                   $productdetail= get_meal($product->meal_id);
                                }
                             ?>
                            <tr>
                                <td><span><?php echo $product->qty;?></span></span></td>
                                
                               <td><label><?php echo $product->name;?></label>
                           <span><?php $data= unserialize($product->attribute);
                              echo '</br>'.$data['name'].'</br>';
                                

                                 
                              ?>


                              </span>


                          </td>
                                <td><span>&pound;<?php echo $product->price;?></span></span></td>
                                <td><span>&pound;<?php echo $product->product_subtotal_price;?></span></span></td>   
                            </tr>
                            <?php } ?>
                        </table>
                        
                        <table class="sub-total-table">
                            <tr>
                                
                                <td><span>Subtotal</span></td>
                                <td><span>&pound;<?php echo $orderdetail->pay;?></span></td>
                            </tr>
                            <?php if(!empty($orderdetail->disct)) { ?>
                            <tr>
                                <td><span>Discount:</span></td>
                                <td><span>&pound;-<?php echo $orderdetail->order_total-$orderdetail->pay;?></span></td>
                            </tr>
                            <?php  }
                           ?>
                            <tr>
                                <td><strong>Total</strong></td>
                                <td><strong>&pound;<?php echo $orderdetail->order_total;?></strong></td>
                            </tr>
                            
                        
                            
                        </table>
                        
                        <div class="table-comment">
                            <p>Thanks for your order, We hope you are satisfied with your purchase. if you wish to return your item either for
                            <a href="#"></a> thanks for your custom</p>
                            
                        </div>
                        
                        
                    
                    </div>
                </div>
            </div>
                      
                    </div>
                </div>
				
				<?php } ?>
            </div>
        </div>
    </div>
</div>
<SCRIPT TYPE="text/javascript">function PrintElem(elem)
    {
        Popup($('<div/>').append($(elem).clone()).html());
    }

    function Popup(data) 
    {
       var mywindow;       
        mywindow = window.open('', 'panel','height=1000,width=600,scrollbars=yes','');            
        mywindow.document.write('<html><head><title>ExcelPrint</title>');
        mywindow.document.write('<link href="http://localhost/resturant/assets/admin/css/bootstrap.css" rel="stylesheet" type="text/css" />');          
        mywindow.document.write('<style>.righ-address span{ display:block; font-size:18px;}.righ-address a{ color:#000; font-size:18px; text-transform:uppercase; display:block; margin-top:18px;}.send-address span{ display:block; font-size:18px;}.content-table th,.content-table td{ border:1px solid black;}.content-table strong{background:#cdcdcd; display:block;}.table-data table td{ min-width:100px !important;}.table-data { width:90% !important; margin:0 auto;}.sub-total-table { text-align:right; margin-bottom:70px;}.sub-total-table tr:first-child td:nth-child(2){  width:141px !important;}.sub-total-table td {height:25px !important; }.sub-total-table span{ min-width:52px; display:block; }.sub-total-table { float:right;}.table-comment{ clear:both; border-top:1px solid black; padding-top:30px; margin-bottom:40px;}.table-comment p{ font-size:20px;text-align:center; }.table-bordered {border: 1px solid #FEFCFC;}</style>');                     
        mywindow.document.write('</head><body>');
        mywindow.document.write(mywindow.opener.document.getElementById('panel').innerHTML);                                
        mywindow.document.write('</body></html>');        
        mywindow.document.close();      
        mywindow.print();             
        return true;
    }

</SCRIPT>
