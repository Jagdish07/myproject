if (window.location.origin == "http://localhost") {
    var base_url = window.location.origin + "/slam/products/";
    var local_path = window.location.origin + "/slam/";
} else {
    var base_url = window.location.origin + "/products/";
    var local_path = window.location.origin + "/";
}
 function deletedata(id){
 	$('.'+id).remove();
 }

function removeattr(id){
 var postArray = {
        id:id,
     
    };
    $.post( base_url+'delete_product_atr', postArray, function(data){
    	alert('delete data successfully');
    	$('#'+id).remove();
           
     });
	
}

function attr(countname){

		var count=$('#countvar').val();
		
		var html='<tr class="'+count+'"> <input type="hidden" name="attribute['+countname+'][attr]['+count+'][attr_id]" value=""/><td><input type="text" name="attribute['+countname+'][attr]['+count+'][attr_name]" value=""/></td><td><input type="text" name="attribute['+countname+'][attr]['+count+'][attr_price]" value=""/></td><td><a class="btn btn-danger btn-sm" onclick="deletedata('+count+')"><span class="glyphicon glyphicon-trash"></span></a></td></tr>';
		var countval = ++count;
	
		$('#countvar').val(countval);
		
		$('.dynamic_attr').append(html);
		e.preventDefault();
	}

$(document).ready(function(){
	$('.addattrname').click(function(){
		var countname=$('#countname').val();
		
		var html='<tr><td><input type="hidden" name="attribute['+countname+'][nameid]" value=""/><span>Attribute Name</span><input type="text" name="attribute['+countname+'][name]" /></td><td><span class="btn btn-danger pull-right" onclick="attr('+countname+')">Add </span></td></tr><tr><th>Name</th><th>Price</th></tr>';
		var countval = ++countname;
		var count = 0;
		$('#countname').val(countval);
		$('#countvar').val(count);
		$('.dynamic_attr').append(html);
		
	});
	
});
