<?php
error_reporting(0);
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of products
 *
 * @author wiesoftware26
 */
class Products extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->load->model('products_model');
          $this->load->helper('products');
    }
    
     public function index() {
        $this->data['view'] = 'main';
        $this->data['module_assets'] = 'products/module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }
     public function create() {
        $this->data['category'] = $this->products_model->get_category();
         $this->data['image'] = $this->products_model->get_iamge();
         $this->data['module_assets'] = 'products/module_assets';
        $this->data['view'] = 'create';
        $this->load->view('theme/admin/layout', $this->data);
    }
    
     public function edit($id = false) {
		 
        if (!$id) {
            redirect('products');
        } else {
            $this->data['image'] = $this->products_model->get_iamge();
            $this->data['category'] = $this->products_model->get_category();
            $this->data['attribute'] = $this->products_model->get_attribute($id);
             $this->data['iconimage'] = $this->products_model->get_producticon($id);
              $this->data['module_assets'] = 'products/module_assets';
            $this->data['record'] = $this->get_model_data($id);
            $this->data['view'] = 'edit';
            $this->load->view('theme/admin/layout', $this->data);
        }
    }
    
    public function delete($id = false) {
        if ($id) {
            $this->products_model->setId($id);
            $deleted = $this->products_model->delete_data();
            if ($deleted) {
                $this->session->set_flashdata('success_message', 'Data deleted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        }
        redirect('products');
    }
    
    public function process() {
        if ($this->input->post()) {
            $this->form_validation->set_error_delimiters('<span class="error">', '</span>');
            $this->form_validation->set_rules('title', 'title', 'required|trim|xss_clean');
            
            //$this->form_validation->set_rules('description', 'description', 'required|trim|xss_clean');
            $this->form_validation->set_rules('category', 'category', 'required|xss_clean');
            $this->form_validation->set_rules('price', 'price', 'required|xss_clean');
            //$this->form_validation->set_rules('sku', 'sku', 'required|xss_clean');
            $this->form_validation->set_rules('sequence', 'sequence', 'integer|trim|xss_clean');

            if ($this->form_validation->run() == TRUE) {
                 if ($_FILES['file']['error'] == 4) {
                     $this->data_operation();
                    redirect('products');
                } else {
                    $get_data = $this->image_upload();

                    if (isset($get_data->upload_data)) {
                        $this->data_operation($get_data->upload_data);
                        redirect('products');
                    }
                }
                    
                
                }
            }
            $this->load_view();
    }
    public function image_upload() {

        $config['upload_path'] = product_path();
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['file_name'] = time() . date('Ymd');

        $this->load->library('upload', $config);
  
        if (!$this->upload->do_upload('file')) {
            $error = (object) array('error' => $this->upload->display_errors('<span class="error">', '</span>'));
            $this->data['error'] = $error->error;

            return $this;
        } else {
            $data = (object) array('upload_data' => $this->upload->data());

            $configImageResize = array(
                'source_image' => $config['upload_path'] . $data->upload_data['file_name'],
                'new_image' => product_path('thumb'),
                'maintain_ratio' => true,
                'width' => 350,
                'height' => 250
            );
            $this->load->library('image_lib');
            $this->image_lib->initialize($configImageResize);
            $this->image_lib->resize();
        }

        return $data;
    }
    
    public function data_operation($data = false) {
    
        if ($this->input->post('id') == 'new') {

            $this->set_model_data($data['orig_name']);
          //  print"<pre>"; print_R($_POST); die;
            $inserted = $this->products_model->insert_data();

            if ($inserted) {
                $this->session->set_flashdata('success_message', 'Data inserted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        } else {
            if ($data) {
                $this->set_model_data($data['orig_name']);
            } else {
                $this->set_model_data();
            }
 //print"<pre>"; print_R($_POST); die;
            $updated = $this->products_model->update_data();
            if ($updated) {
                $this->session->set_flashdata('success_message', 'Data updated successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        }
        redirect('products');
    }
    
    public function load_view() {
        if ($this->input->post('id') != 'new') {
            $this->edit($this->input->post('id'));
        } else {
            $this->create();
        }
    }
    public function  delete_product_atr(){
        $this->products_model->delete_attr();

    }
    public function set_model_data($file_name = false) {
            $productsObj = $this->products_model;

            if ($this->input->post('id') != 'new') {
                $id = $this->input->post('id');
                $productsObj->setId($id);
            }
            
            if($this->input->post('attribute')){

               $productAttrbute= $this->input->post('attribute');
               $productsObj->setProductAttr($productAttrbute);
            }
            $title = $this->input->post('title');
            $productsObj->setTitle($title);
        
            $slug = $this->input->post('slug');
            $productsObj->setSlug($slug);
        
            $description = $this->input->post('description');
            $productsObj->setDescription($description);
            
            $short_description = $this->input->post('short_description');
            $productsObj->setShortDescription($short_description);
            
            $featured = $this->input->post('featured');
            $productsObj->setFeatured($featured);
            
            $price = $this->input->post('price');
            $productsObj->setPrice($price);
            
            $category = $this->input->post('category');
            $productsObj->setCategoryId($category);
            
            $in_stock = $this->input->post('in_stock');
            $productsObj->setInStock($in_stock);
            
            $manufacture = $this->input->post('manufacture');
            $productsObj->setManufacture($manufacture);
            
            $sku = $this->input->post('sku');
            $productsObj->setSku($sku);
            
            $notes = $this->input->post('notes');
            $productsObj->setNotes($notes);
            
           if ($file_name) {
            $productsObj->setImage($file_name);
            }
            $page_title = $this->input->post('page_title');
            $productsObj->setPageTitle($page_title);
        
            $meta_keyword = $this->input->post('meta_keyword');
            $productsObj->setMetaKeyword($meta_keyword);
         
            $meta_description = $this->input->post('meta_description');
            $productsObj->setMetaDescription($meta_description);  

            $productsObj->setStatus(1);

            $sequence = $this->input->post('sequence');
            $productsObj->setSequence($sequence);

            $productsObj->setCreatedOn();
           
            return true;
    }
    
    public function update_status() {
        $id = $this->input->get('id');
        if (!$id) {
            redirect('products');
        } else {
            $this->products_model->setId($id);

            $status = $this->input->get('status');
            $this->products_model->setStatus($status);
            $this->products_model->update_status();
            die;
        }
    }
    
    public function get_model_data($id) {
        $productsObj = $this->products_model;

        $productsObj->setId($id);
        $productsObj->get_row();

        $response = new stdClass();
        $response->id = $productsObj->getId();
        $response->title = $productsObj->getTitle();
        $response->slug = $productsObj->getSlug();

        $response->category_id = $productsObj->getCategoryId();
        $response->description = $productsObj->getDescription();
        $response->short_description = $productsObj->getShortDescription();
        $response->page_title = $productsObj->getPageTitle();
        $response->price = $productsObj->getPrice();
       $response->image = $productsObj->getImage();
        $response->meta_keyword = $productsObj->getMetaKeyword();
        $response->meta_description = $productsObj->getMetaDescription();
        $response->featured = $productsObj->getFeatured();
        $response->manufacture = $productsObj->getManufacture();
        $response->sku = $productsObj->getSku();
        $response->notes = $productsObj->getNotes();
        $response->in_stock = $productsObj->getInStock();
        $response->sequence = $productsObj->getSequence();
     $response->string =  rtrim($productsObj->getString($response->id),',');
 $response->option =  rtrim($productsObj->getOption($response->id),',');
        return $response;
    }
 
}
