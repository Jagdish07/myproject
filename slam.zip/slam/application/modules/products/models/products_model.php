<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of products_model
 *
 * @author wiesoftware26
 */
class Products_model extends CI_Model{
    
    private $id;
    
    private $title;
    
    private $sku;
    
    private $featured;
    
    private $slug;
    
    private $price;
    
    private $manufacture;
    
    private $notes;
    
    private $short_description;
    
    private $description;
    
    private $page_title;
    
    private $meta_keyword;
    
    private $meta_description;
    
    private $category_id;
    
    private $in_stock;
    
    private $status;

    private $image;
    
    private $sequence;

    private $created_on;
    
    private $updated_on;
    
    private $queryString;
    
    private $whereOrAnd;
    
    private $where;
    
    private $tbl_name = 'tbl_products';
            
    function __construct() {
        parent::__construct();
    }
    
    public function getId(){
        return $this->id;
    }
    
    public function setId($id) {
        $this->id = $id;
    }
    
    public function getSku(){
        return $this->sku;
    }
    
    public function setImage($image) {
        $this->image = $image;
    }
    
    public function getImage() {
        return $this->image;
    }
    

    public function setSku($sku) {
        $this->sku = $sku;
    }
    
    public function getFeatured(){
        return $this->featured;
    }
    
    public function setFeatured($featured) {
        $this->featured = $featured;
    }
    
    public function getManufacture(){
        return $this->manufacture;
    }
    
    public function setManufacture($manufacture) {
        $this->manufacture = $manufacture;
    }
    
    public function setNotes($notes){
        $this->notes = $notes;
    }
    
    public function getNotes(){
        return $this->notes;
    }
    
    public function setPrice($price){
        $this->price = $price;
    }
    
    public function getPrice(){
        return $this->price;
    }

    public function setProductAttr($productatrr){
        $this->productatrr = $productatrr;
    }
    
    public function getProductAttr(){
        return $this->productatrr;
    }
    
    public function setShortDescription($short_description){
        $this->short_description = $short_description;
    }
    
    public function getShortDescription(){
        return $this->short_description;
    }

    public function setTitle($title){
        $this->title = $title;
    }
    
    public function getTitle(){
        return $this->title;
    }
    
    public function setSlug($slug){
        $this->slug = $slug;
    }
    
    public function getSlug(){
        return $this->slug;
    }
    
    public function setDescription($description){
        $this->description = $description;
    }
    
    public function getDescription(){
        return $this->description;
    }
    
   public function setPageTitle($page_title){
        $this->page_title = $page_title;
    }
    
    public function getPageTitle(){
        return $this->page_title;
    }
    
    public function getMetaKeyword(){
        return $this->meta_keyword;
    }
    
    public function setMetaKeyword($meta_keyword) {
        $this->meta_keyword = $meta_keyword;
    }
    
    public function getMetaDescription(){
        return $this->meta_description;
    }
    
    public function setMetaDescription($meta_description) {
        $this->meta_description = $meta_description;
    }
    
    public function setStatus($status) {
        $this->status = $status;
    }
    
    public function getStatus() {
        return $this->status;
    }
    
    public function setInStock($in_stock) {
        $this->in_stock = $in_stock;
    }
    
    public function getInStock() {
        return $this->in_stock;
    }
    
    public function setSequence($sequence) {
        $this->sequence = $sequence;
    }
    
    public function getSequence() {
        return $this->sequence;
    }
    
    public function setUpdatedOn() {
        $this->updated_on = date('Y-m-d H:i:s');
    }
    
    public function getUpdatedOn() {
        return $this->updated_on;
    }
    
    public function setCreatedOn() {
        $this->created_on = date('Y-m-d H:i:s');
    }
    
    public function getCreatedOn() {
        return $this->created_on;
    }
    
    public function setCategoryId($category_id) {
        $this->category_id = $category_id;
    }
    
    public function getCategoryId() {
        return $this->category_id;
    }
       
 
    public function setString($string, $product_id) {
        $final_Array = array();
        $i = 0;
        if($string!='') {
            $explode = explode(",", trim($string));
            if(!empty($explode)) {
                foreach($explode as $key => $value) {
                    $final_Array[$i]['product_id'] = $product_id;
                    
                    if ($pos = strpos($value, '#') !== false) {
                        
                       $price = substr($value, strpos($value, "#") + 1);
                       
                        if(strpos($price, '+') !== false) {
                            $final_Array[$i]['operation'] = 1;
                        } else if(strpos($price, '-') !== false) {
                            $final_Array[$i]['operation'] = 0;
                        }
                       $final_Array[$i]['price'] = substr($value, strpos($value, "#") + 2);
                       
                       $final_Array[$i]['title'] = substr($value, 0, strpos($value, "#"));
                       
                    } else {
                        $final_Array[$i]['price'] = 0.00;
                       $final_Array[$i]['title'] = $value;
                    }
                    ++$i;
                }

                $this->db->delete('tbl_product_preference', array('product_id' => $product_id));
                
                alter_auto_increment('tbl_product_preference', 'id');
                
                foreach($final_Array as $arry) {
                    $this->db->insert('tbl_product_preference', $arry);
                }
                return true;
            }
        }
    }
    
    public function getString($product_id) {
        $this->db->where('product_id', $product_id);
        $result = $this->db->get('tbl_product_preference')->result();
        $string = '';
        if(!empty($result)) { 
            foreach($result as $row) {
                if($row->operation != '') {
                    if($row->operation == 1) {
                        $string .= $row->title.'#+'.$row->price.',';
                    } else if($row->operation == 0) {
                        $string .= $row->title.'#-'.$row->price.',';
                    }
                } else {
                    $string .= $row->title.',';
                }
            }
             
        }
        return $string;
       
    }
    
       public function setOption($option, $product_id) {
        $final_Array = array();
        $i = 0;
        if($option!='') {
            $explode = explode(",", trim($option));
            if(!empty($explode)) {
                foreach($explode as $key => $value) {
                    $final_Array[$i]['product_id'] = $product_id;
                    
                    if ($pos = strpos($value, '#') !== false) {
                        
                       $price = substr($value, strpos($value, "#") + 1);
                       
                        if(strpos($price, '+') !== false) {
                            $final_Array[$i]['operation'] = 1;
                        } else if(strpos($price, '-') !== false) {
                            $final_Array[$i]['operation'] = 0;
                        }
                       $final_Array[$i]['price'] = substr($value, strpos($value, "#") + 2);
                       
                       $final_Array[$i]['title'] = substr($value, 0, strpos($value, "#"));
                       
                    } else {
                        $final_Array[$i]['price'] = 0.00;
                       $final_Array[$i]['title'] = $value;
                    }
                    ++$i;
                }

                $this->db->delete('tbl_product_option', array('product_id' => $product_id));
                
                alter_auto_increment('tbl_product_option', 'id');
                
                foreach($final_Array as $arry) {
                    $this->db->insert('tbl_product_option', $arry);
                }
                return true;
            }
        }
    }
    
    public function getOption($product_id) {
        $this->db->where('product_id', $product_id);
        $result = $this->db->get('tbl_product_option')->result();
        $string = '';
        if(!empty($result)) {
            
            foreach($result as $row) {
                if($row->operation != '') {
                    if($row->operation == 1) {
                        $string .= $row->title.'#+'.$row->price.',';
                    } else if($row->operation == 0) {
                        $string .= $row->title.'#-'.$row->price.',';
                    }
                } else {
                    $string .= $row->title.',';
                }
            }
             
        }
        return $string;
       
    }
     public function get_category() {
        $this->db->select('id,title, parent');
        $this->db->where('status','1');
        $this->db->order_by('title ASC');
        $result = $this->db->get('tbl_category')->result();
        $categoriesArray = array();
        //$categoriesArray[0] = 'Top Level Category';
        foreach($result as $category){
               
                $categoriesArray[$category->id] = $category->title;
        }
        return $categoriesArray;
    }

    public function get_iamge(){
        $this->db->select('*');
        $this->db->where('status','1');
        $this->db->order_by('sequence','ASC');
        return $this->db->get('tbl_icons')->result();
    }
    
    public function insert_data() {
        $productAttr=$this->getProductAttr();
        $post_data = $this->get_post_values();
        $post_data->created_on = $this->getCreatedOn();
        if(!empty($productAttr)){
           $post_data->attr_status='1'; 
        }else{
            $post_data->attr_status='0';  
        }
        $this->db->insert($this->tbl_name, $post_data);
        $product_id = $this->db->insert_id();
         if($this->input->post('icons')){
            foreach($this->input->post('icons') as $icon){
                $data['icon_id']=$icon;
                $data['product_id']= $product_id;
                   $this->db->insert('tbl_product_icon',$data); 
            }

         }
    
       foreach($productAttr as $attrkey){
          $postattrname['name']=$attrkey['name'];
            $postattrname['product_id']= $product_id;
            if($attrkey['nameid']==''){
             $this->db->insert('tbl_attrname',$postattrname); 
             $attr_name = $this->db->insert_id();
            }else{
                 $this->db->where('id',$attrkey['nameid']);
                $this->db->update('tbl_attrname',$postattrname); 
                $attr_name = $attrkey['nameid'];
            }
 
            foreach($attrkey['attr'] as $key ){

                $postattr['price']=$key['attr_price'];
                 $postattr['title']=$key['attr_name'];
                $postattr['attr_name_id']=$attr_name;
            if($attrkey['attr_id']==''){
                 $this->db->insert('tbl_products_attr',$postattr);    
            }else{
                $this->db->where('id',$attrkey['attr_id']);
                 $this->db->update('tbl_products_attr',$postattr);    
            }

            }
            
        
        }
        $string = $this->input->post('string');
        $this->setString($string, $product_id);

    $option = $this->input->post('option');
         $this->setOption($option, $product_id);
        
 
         return true;
    }
    
    public function get_post_values() {
        $post_data = new stdClass();
        $post_data ->title = $this->getTitle();
        $post_data->slug = $this->getSlug();
        $post_data->price = $this->getPrice();
        $post_data->category_id = $this->getCategoryId();
        $post_data->description = $this->getDescription();
        $post_data->short_description = $this->getShortDescription();
        $post_data->page_title = $this->getPageTitle();
        $post_data->meta_keyword = $this->getMetaKeyword();
        $post_data->meta_description = $this->getMetaDescription();
        $post_data->sequence = $this->getSequence();
        $post_data->status = $this->getStatus();
        $post_data->in_stock = $this->getInStock();
        if($this->getImage() != '') {
            $post_data->image = $this->getImage();
        }
        
        $post_data->notes = $this->getNotes();
        $post_data->manufacture = $this->getManufacture();
        $post_data->featured = $this->getFeatured();
        $post_data->sku = $this->getSku();
       
        return $post_data;
    }
    public function get_productimage($id){

    }
    
	public function update_data() {
        $productAttr=$this->getProductAttr();
        $post_data = $this->get_post_values();
        $id = $this->getId();
		$string = $this->input->post('string');
		$this->setString($string, $id);
		$option = $this->input->post('option');
		$this->setOption($option, $id);
		if(!empty($productAttr)){
           $post_data->attr_status='1'; 
        }else{
            $post_data->attr_status='0';  
		}
    // print"<pre>";print_R($_POST); die;
		$this->db->where('product_id',$id);
		$this->db->delete('tbl_product_icon');
		if($this->input->post('icons')){
            
            //echo $this->db->last_query(); die;
            foreach($this->input->post('icons') as $icon){
                $data['icon_id']=$icon;
                $data['product_id']= $id;
					$this->db->insert('tbl_product_icon',$data); 
            }

		}
       foreach($productAttr as $attrkey){
       
            $postattrname['name']=$attrkey['name'];
            $postattrname['product_id']= $id;
            if($attrkey['nameid']==''){
             $this->db->insert('tbl_attrname',$postattrname); 
             $attr_name = $this->db->insert_id();
            }else{
                 $this->db->where('id',$attrkey['nameid']);
                $this->db->update('tbl_attrname',$postattrname); 
                $attr_name = $attrkey['nameid'];
            }
            
              //print"<pre>"; print_r($productAttr); die;
            foreach($attrkey['attr'] as $key){
            // print"<pre>"; print_r($key); die;
                $postattr['price']=$key['attr_price'];
                 $postattr['title']=$key['attr_name'];
                $postattr['attr_name_id']=$attr_name;
            if($key['attr_id']==''){
                 $this->db->insert('tbl_products_attr',$postattr);    
            }else{
                $this->db->where('id',$key['attr_id']);
                 $this->db->update('tbl_products_attr',$postattr);    
            }

            }
            
        
        }

        $post_data->updated_on = $this->getUpdatedOn();
        $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    public function delete_attr(){
        $this->db->where('id',$this->input->post('id'));
        $this->db->delete('tbl_products_attr');
        return true;
    }
    
    public function get_row() {
        $id = $this->getId();
        $this->db->where('id', $id);
        $row = $this->db->get($this->tbl_name)->row();
        if($row) {
            $this->setId($row->id);
            $this->setTitle($row->title);
            $this->setSlug($row->slug);
            $this->setFeatured($row->featured);
            $this->setInStock($row->in_stock);
            $this->setManufacture($row->manufacture);
            $this->setDescription($row->description);
            $this->setSku($row->sku);
            $this->setImage($row->image);
            $this->setPrice($row->price);
            $this->setNotes($row->notes);
            $this->setCategoryId($row->category_id);
            $this->setShortDescription($row->short_description);
            $this->setPageTitle($row->page_title);
            $this->setMetaKeyword($row->meta_keyword);
            $this->setMetaDescription($row->meta_description);    
            $this->setSequence($row->sequence);
            return $this;
        } else {
            return false;
        }
    }
    
   public function get_producticon($id){
        $this->db->where('product_id', $id);
         $iconsdata = $this->db->get('tbl_product_icon')->result();
          $iconarray=array();
          foreach($iconsdata as $icon){
            $iconarray[]= $icon->icon_id;
           
          }
          return $iconarray;

    }

    public function get_attribute($id){
        $this->db->where('product_id', $id);
        $attrname = $this->db->get('tbl_attrname')->result();
        if(!empty($attrname)){
        $attrdata = array();
        $i=0;
       

        foreach($attrname as $data){
          $attrdata[$i]['name'] = $data->name;
          $attrdata[$i]['nameid'] = $data->id;
            $this->db->where('attr_name_id',$data->id);
           
          $attrdata[$i]['attr']= $this->db->get('tbl_products_attr')->result();
          
           ++$i;
        }
        return $attrdata;
     }else{
        return true;
     }
    }
    public function delete_data() {
        $id = $this->getId();
        $this->db->where('id', $id);
        $deleted = $this->db->delete($this->tbl_name);

         $this->db->where('id', $id);
        $deleted = $this->db->delete('tbl_product_icon');
       
        if($deleted) {
            alter_auto_increment($this->tbl_name, 'id');
            return true;
        } else {
            return false;
        }
    }
    
    public function update_status() {
        $id = $this->getId();
        $post_data = new stdClass();
        $post_data->status = $this->getStatus();
        $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    
     public function set_where_name($name=false) {
        if ($name) {
            $this->whereOrAnd = " WHERE ";
            $this->where = " title LIKE '%" . $name . "%' ";
        }
        $this->queryString = $this->whereOrAnd . $this->where;

        $response = new stdClass();
        $response->query_string = $this->queryString;
        $response->title = $name;

        return $response;
    }
    
    public function get_post_data() {
        $postData = new stdClass();
        $postData->sort = $this->input->post('sort');
        $postData->order = $this->input->post('order');
        $postData->page = $this->input->post('page');
        $postData->limit = $this->input->post('limit');
        $postData->name = $this->input->post('name');
        $postData->field = $this->input->post('type');
        $postData->section = $this->input->post('section');
        return $postData;
    }
    
    public function get_list() {
        $postData = $this->get_post_data();
        /*
         * Count All results
         */
        $this->set_where_name($postData->name);
        $queryCount = "SELECT count(*) as num_records FROM " . $this->tbl_name;
        $queryCountRun = $this->db->query($queryCount . $this->whereOrAnd . $this->where);
        $queryCountResult = $queryCountRun->row();

        /*
         * Get All records
         */
       $query = "SELECT * FROM " . $this->tbl_name;
        $orderObj = set_order($postData->sort, $postData->order);
        $limitObj = set_limit($postData->page, $postData->limit);
        $queryString = $query . $this->whereOrAnd . $this->where . $orderObj->query_string . $limitObj->query_string;
        $queryRun = $this->db->query($queryString);
        $queryResult = $queryRun->result();

        $params = request_params($queryCountResult->num_records, $orderObj->sort, $orderObj->order, $limitObj->limit, $limitObj->page, $limitObj->start, $postData->field);

        $response = new stdClass();
        $response->params = $params;
        $response->result = $queryResult;
        return $response;
    }
}