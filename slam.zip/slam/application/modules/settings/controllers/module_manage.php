<?php
error_reporting(E_ALL);
defined('BASEPATH') OR exit('No direct script access allowed');

class Module_manage extends CI_Controller {

    function __construct() {
        parent:: __construct();
      Myfunction();
		$this->load->model('module_manage_model');
		
    }

    public function index() {
        $this->data['view'] = 'module_manage/main';
		//$this->data['show'] = $this->module_manage_model->authenticate_user();
		$this->data['module_assets'] = 'settings/module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }
	
    public function update_status() {
        $id = $this->input->get('id');
        if (!$id) {
            redirect('settings/module-manage');
        } else {
            $this->module_manage_model->setId($id);

            $status = $this->input->get('status');
            $this->module_manage_model->setStatus($status);
            $this->module_manage_model->update_status();
            die;
        }
    }
}
