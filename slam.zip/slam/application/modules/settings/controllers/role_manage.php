<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class role_manage extends CI_Controller {

    function __construct() {
        parent:: __construct();
        check_logged_user();
         Myfunction();
		$this->load->model('role_manage_model');
	
    }

    public function index() {
        $this->data['view'] = 'role_manage/main';
		$this->data['module_assets'] = 'module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }
	
    public function create() {
        $this->data['view'] = 'role_manage/create';
		$this->data['modules'] = $this->role_manage_model->get_all_modules();
		$this->data['roles'] = $this->role_manage_model->get_all_roles();
        $this->load->view('theme/admin/layout', $this->data);
    }

    public function edit($id = false) {
        if (!$id) {
            redirect('settings/role-manage');
        } else {
			
            $this->data['record'] = $this->get_model_data($id);
			//print_r($this->data['record']);die;
			$this->data['modules'] = $this->role_manage_model->get_all_modules();
			$this->data['roles'] = $this->role_manage_model->get_all_roles();
			//print '<pre>';print_r($this->data['roles']);die;
            $this->data['view'] = 'role_manage/edit';
            $this->load->view('theme/admin/layout', $this->data);
        }
    }

    public function process() {
	//print"<pre>";	print_r($_POST); die;
        if ($this->input->post()) {
            $this->form_validation->set_error_delimiters('<span class="error">', '</span>');
            $this->form_validation->set_rules('role_name', 'role name', 'required|trim|xss_clean');
            if ($this->form_validation->run() == TRUE) {
                $this->set_model_data();
                if ($this->input->post('role_id') == 'new') {
                    $inseretd = $this->role_manage_model->insert_data();
                    if($inseretd) {
                         $this->session->set_flashdata('success_message', 'Data inserted successfully.');
                    } else {
                        $this->session->set_flashdata('error_message', 'Something going wrong. Please try again.');
                    }
                } else {
                    $updated = $this->role_manage_model->update_data();
                     if($updated) {
                         $this->session->set_flashdata('success_message', 'Data updated successfully.');
                    } else {
                        $this->session->set_flashdata('error_message', 'Something going wrong. Please try again.');
                    }
                }
                redirect('settings/role_manage');
            } else {
                if ($this->input->post('role_id') == 'new') {
                    $this->create();
                } else {
                    $this->edit($this->input->post('role_id'));
                }
            }
        }
    }

    public function delete($id = false) {
        if (!$id) {
            redirect('settings/role_manage');
        } else {
            $this->role_manage_model->setId($id);
            $deleted = $this->role_manage_model->delete_data();
            if ($deleted) {
                $this->session->set_flashdata('success_message', 'Data deleted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Something going wrong. Please try again.');
            }
            redirect('settings/role_manage');
        }
    }

    private function set_model_data() {
        $roleObj = $this->role_manage_model;

        if ($this->input->post('role_id') != 'new') {
            $id = $this->input->post('role_id');
            $roleObj->setId($id);
        }
        $role_name = $this->input->post('role_name');
        $roleObj->setRoleName($role_name);
		
		 $user_auth = $this->input->post('roles');
		// print_r($user_auth);die;
        $roleObj->setUserAuth($user_auth);

        $roleObj->setStatus(1);

        return true;
    }

    private function get_model_data($id) {
        $roleObj = $this->role_manage_model;

        $roleObj->setId($id);
        $roleObj->get_row();

        $response = new stdClass();
        $response->role_id = $roleObj->getId();
        $response->role_name = $roleObj->getRoleName();
		$response->selected_modules = $roleObj->getModules(); 
	   $response->selected_roles = $roleObj->getAuthRoles();
        return $response ;
    }	
	

	

    public function update_status() {
        $id = $this->input->get('id');
        if (!$id) {
            redirect('settings/role_manage');
        } else {
            $this->role_manage_model->setId($id);

            $status = $this->input->get('status');
            $this->role_manage_model->setStatus($status);
            $this->role_manage_model->update_status();
            die;
        }
    }

}
