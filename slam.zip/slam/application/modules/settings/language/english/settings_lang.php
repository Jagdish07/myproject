<?php


/* Settings module language */

$lang['add_access'] = "Add Access";
$lang['role_access_list'] = "Role Access list";

