<?php
class role_manage_model extends CI_Model {
	
    private $role_id;
    
	 private $role_name;
	
    private $tbl_name = 'tbl_roles';
	
    private $queryString;
    
    private $whereOrAnd;
    
    private $where;

    private $modules = array();
	
	private $user_auth = array();
	
	private $role_auth = array();
	
	 

    private $status;

    function __construct() {
		parent::__construct();
    }

    public function getId(){
	return $this->role_id;
    }

    public function setId($role_id) {
	$this->role_id = $role_id;
	return $this;
    }

    public function setModules($modules) {
	$this->modules = $modules;
	return $this;
    }

    public function getModules() {
	return $this->modules;
    }
	
    public function setRoleName($role_name){
        $this->role_name = $role_name;
	return $this;
    }
    
    public function getRoleName(){
        return $this->role_name;
    }	
	
	
	 public function getAuthRoles(){
        return $this->role_auth;
    }
	
	
	public function setAuthRoles($role_auth) {
	$this->role_auth = $role_auth;
	//print_r($this->role_auth);die;
	return $this;	
    }
	
	
    public function setStatus($param) {
	$this->status = $param;
	return $this;	
    }
	
	public function getUserAuth(){
        return $this->user_auth;
    }	
	
    public function setUserAuth($user_auth) {
	$this->user_auth = $user_auth;
	return $this;	
    }
	    
    public function getStatus() {
	return $this->status;
    }

    public function insert_data() {
		$post_data = $this->get_post_values();
		$post_data->user_auth = implode(',', $post_data->user_auth);
		$this->db->insert($this->tbl_name, $post_data);
		$role_id = $this->db->insert_id();
		if($this->input->post('modules')) {
		  $this->manage_access_modules($role_id);
		}
		return $role_id;
    }
    
    private function manage_access_modules($role_id) {
		$this->db->delete('tbl_modules_roles', array('role_id' => $role_id));	
		$modules = $this->input->post('modules');
		$insert_data = array();
		$i = 0;
		foreach($modules as $module_id) {
		   $insert_data[$i]['role_id'] = $role_id;
		   $insert_data[$i]['module_id'] = $module_id;
		   ++$i;
		}
		
		if(!empty($insert_data)) {
		   $this->db->insert_batch('tbl_modules_roles', $insert_data);
		}
		return true;
    }
	
    private function get_post_values() {
        $post_data = new stdClass();
        $post_data->role_name = $this->getRoleName();
        $post_data->status = $this->getStatus();
		$post_data->user_auth = $this->getUserAuth();
        return $post_data;
    }
    
     public function update_data() {
        $post_data = $this->get_post_values();
		$post_data->user_auth = implode(',', $post_data->user_auth);
        $role_id = $this->getId();
        $this->db->where('id', $role_id);
        $this->db->update($this->tbl_name, $post_data);
	if($this->input->post('modules')) {
	  $this->manage_access_modules($role_id);
	}
	return true; 
    }
    
    public function delete_data() {
        $id = $this->getId();
        $this->db->where('id', $id);
        return $this->db->delete($this->tbl_name);
    }
    
    public function get_row() {
        $id = $this->getId();
	$this->db->select('r.id, r.role_name, r.status,r.user_auth ,mr.module_id');
	$this->db->from('tbl_roles as r');
	$this->db->join('tbl_modules_roles as mr', 'mr.role_id = r.id');
        $this->db->where('r.id', $id);
        $result = $this->db->get()->result();
		
	
	$role = array();
	$i = 0;
	if(!empty($result)) {
	 foreach($result as $row) {
	   $role['role_id'] = $row->id;
	   $role['role_name'] = $row->role_name;
	   $role['user_auth'] = $row->user_auth;
	   $role['modules_id'][$i] = $row->module_id; 
	   ++$i;
	 }
	 $string=$role['user_auth'];
	 $select_roles = explode(",",$string);
	 $this->setId($role['role_id']);
	 $this->setRoleName($role['role_name']);
	 $this->setModules($role['modules_id']);
	 $this->setAuthRoles($select_roles);
	 return $this;
	 }else{
            return false;
        }
     }	
	
    public function update_status() {
        $id = $this->getId();
        $post_data = new stdClass();
        $post_data->status = $this->getStatus();
        $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
	
    public function set_where_name($name=false) {
        if ($name) {
            $this->whereOrAnd = " WHERE ";
            $this->where = " role_name LIKE '%" . $name . "%' ";
        }
        $this->queryString = $this->whereOrAnd . $this->where;

        $response = new stdClass();
        $response->query_string = $this->queryString;
        $response->title = $name;

        return $response;
    }	
	
    public function get_post_data() {
        $postData = new stdClass();
        $postData->sort = $this->input->post('sort');
        $postData->order = $this->input->post('order');
        $postData->page = $this->input->post('page');
        $postData->limit = $this->input->post('limit');
        $postData->name = $this->input->post('name');
        $postData->field = $this->input->post('type');
        $postData->section = $this->input->post('section');
        return $postData;
    }

    public function get_list() {
        $postData = $this->get_post_data();
        /*
         * Count All results
         */
        $this->set_where_name($postData->name);
        $queryCount = "SELECT count(*) as num_records FROM " . $this->tbl_name;
        $queryCountRun = $this->db->query($queryCount . $this->whereOrAnd . $this->where);
        $queryCountResult = $queryCountRun->row();

        /*
         * Get All records
         */
		//$session = $this->session->all_userdata();
		//print"<pre>"; print_r($session); die;
        $query = "SELECT * FROM " . $this->tbl_name;
        $orderObj = set_order($postData->sort, $postData->order, $postData->field);
        $limitObj = set_limit($postData->page, $postData->limit);
        $queryString = $query . $this->whereOrAnd . $this->where . $orderObj->query_string . $limitObj->query_string;
        $queryRun = $this->db->query($queryString);
        $queryResult = $queryRun->result();

        $params = request_params($queryCountResult->num_records, $orderObj->sort, $orderObj->order, $limitObj->limit, $limitObj->page, $limitObj->start, $postData->field);

        $response = new stdClass();
        $response->params = $params;
        $response->result = $queryResult;
        return $response;
    }

    public function get_all_modules() {
		$this->db->select('id, module_name');
		$this->db->where('status', 1);
		$result = $this->db->get('tbl_modules')->result();
		return $result;
    }
	
	/* Select Role From tbl_role */
	public function get_all_roles() {
		$this->db->select('role_name, id');
		$this->db->where('status', 1);
		$result = $this->db->get('tbl_roles')->result();
		
		return $result;
    }
	/* Select Role From tbl_role Close*/
	
	
	
    public function authenticate_user() {
		$session = $this->session->all_userdata();
		$this->db->select('*');
		$this->db->where('role_id', $session['select_role']);		
		return $this->db->get('tbl_modules_roles')->result();
	}
	
}
?>
