<?php
    
    $input_div_open = '<div class="form-group">';
    $input_div_close = '</div>';
    $required = ' <abbr class="required"><i class="fa fa-asterisk"></i></abbr>';
    $action = 'settings/role_manage/process';
    echo form_open($action, array('class' => 'form'));
        
        echo (isset($record->role_id)) ? form_hidden('role_id', $record->role_id) : form_hidden('role_id', 'new');
		//print_r($record); die;
        echo $input_div_open;
            echo form_label('Role Name'.$required, 'name');
            $role_name = array(
                'name' => 'role_name',
                'class' => 'form-control',
                'id' => 'name',
                'value' => (isset($record->role_name)) ? $record->role_name : set_value('role_name')
            );
            echo form_input($role_name);
            echo form_error('role_name');
        echo $input_div_close;
	
	echo "<h3>Select this role access modules</h3>";
	echo "<hr class='whiter'>";
	
	$checked = FALSE;
	foreach($modules as $module) {
		if(isset($record->selected_modules)) {
			
			$checked = (in_array($module->id, $record->selected_modules)) ? TRUE : FALSE;
		}
		echo form_checkbox('modules[]', $module->id, $checked);
		echo '&nbsp;&nbsp;&nbsp;&nbsp;';
		echo form_label($module->module_name, 'module', array('class' => 'checkbox-label'));
		echo '&nbsp;&nbsp;&nbsp;&nbsp;';
        }

	echo "<div class='clearfix'></div>";

	
	
	
	
        $submit = array(
            'name' => 'submit',
            'class' => 'btn btn-primary',
            'id' =>'submit',
            'value' => 'Submit'
        );
        echo form_submit($submit);
   echo form_close();
?>
