<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of products
 *
 * @author wiesoftware26
 */
class Shoppers extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('shoppers_model');
           $this->load->module('Orders');
    }

     public function index() {

        $this->data['view'] = 'main';
        $this->data['module_assets'] = 'shoppers/module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }
	public function update_status() {
        $id = $this->input->get('id');
        if (!$id) {
            redirect('reservations');
        } else {
            $this->shoppers_model->setId($id);

            $status = $this->input->get('status');
            $this->shoppers_model->setIsReserved($status);
            $this->shoppers_model->update_status();
            die;
        }
    }
     public function delete($id = false) {
        if ($id) {
            $this->shoppers_model->setId($id);
            $deleted = $this->shoppers_model->delete_data();
            if ($deleted) {
                $this->session->set_flashdata('success_message', 'Data deleted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        }
        redirect('reservations');
    }

}
