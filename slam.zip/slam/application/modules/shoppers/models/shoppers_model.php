<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of products_model
 *
 * @author wiesoftware26
 */
class Shoppers_model extends CI_Model{
    
    private $id;
    
    private $no_of_person;
    
    private $res_date;
    
    private $res_time;
    
    private $note;
    
    
    private $is_reserved;
    
    private $is_active;

    private $created_on;
    
    private $updated_on;
    
    private $queryString;
    
    private $whereOrAnd;
    
    private $where;
    
    private $tbl_name = 'tbl_users';
            
    function __construct() {
        parent::__construct();
    }
    
    public function getId(){
        return $this->id;
    }
    
    public function setId($id) {
        $this->id = $id;
    }
    public function getIsReserved(){
        return $this->is_reserved;
    }
    
    public function setIsReserved($status) {
        $this->is_reserved = $status;
    }
    
    public function getNoOfPerson(){
        return $this->no_of_person;
    }
    
    public function setNoOfPerson($sku) {
        $this->sku = $no_of_person;
    }
    
    public function getDate(){
        return $this->res_date;
    }
    
    public function setDate($featured) {
        $this->featured = $res_date;
    }
    
    public function getManufacture(){
        return $this->res_time;
    }
    
    public function setManufacture($manufacture) {
        $this->manufacture = $res_time;
    }
    
    public function setNote($notes){
        $this->note = $note;
    }
    
    public function getNote(){
        return $this->note;
    }
    
   
    public function setUpdatedOn() {
        $this->updated_on = date('Y-m-d H:i:s');
    }
    
    public function getUpdatedOn() {
        return $this->updated_on;
    }
    
    public function setCreatedOn() {
        $this->created_on = date('Y-m-d H:i:s');
    }
    
    public function getCreatedOn() {
        return $this->created_on;
    }
    

  
 
    public function get_post_values() {
        $post_data = new stdClass();
        $post_data ->no_of_person = $this->getTitle();
        $post_data->res_date = $this->getSlug();
        $post_data->res_time = $this->getPrice();
        $post_data->note = $this->getCategoryId();
        return $post_data;
    }
    
     public function update_data() {
        $post_data = $this->get_post_values();
        $id = $this->getId();
        $string = $this->input->post('string');
         $this->setString($string, $id);
        $post_data->updated_on = $this->getUpdatedOn();
        $this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    
  
    
    public function delete_data() {
        $id = $this->getId();
        $this->db->where('id', $id);
        $deleted = $this->db->delete($this->tbl_name);
        if($deleted) {
            alter_auto_increment($this->tbl_name, 'id');
            return true;
        } else {
            return false;
        }
    }
    
    public function update_status() {
        $id = $this->getId();
        $post_data = new stdClass();
        $post_data->is_reserved = $this->getIsReserved();
	$this->db->where('id', $id);
        return $this->db->update($this->tbl_name, $post_data);
    }
    
     public function set_where_name($name=false) {
        if ($name) {
            $this->whereOrAnd = " WHERE ";
            $this->where = " name LIKE '%" . $name . "%' ";
        }
        $this->queryString = $this->whereOrAnd . $this->where;

        $response = new stdClass();
        $response->query_string = $this->queryString;
        $response->res_datetime = $name;

        return $response;
    }
    
    public function get_post_data() {
        $postData = new stdClass();
        $postData->sort = $this->input->post('sort');
        $postData->order = $this->input->post('order');
        $postData->page = $this->input->post('page');
        $postData->limit = $this->input->post('limit');
        $postData->name = $this->input->post('name');
        $postData->field = $this->input->post('type');
        $postData->section = $this->input->post('section');
        return $postData;
    }
    
    public function get_list() {
        $postData = $this->get_post_data();
        /*
         * Count All results
         */
        $this->set_where_name($postData->name);

        $queryCount = "SELECT count(*) as num_records FROM " . $this->tbl_name;
        $queryCountRun = $this->db->query($queryCount . $this->whereOrAnd . $this->where);
        $queryCountResult = $queryCountRun->row();

        /*
         * Get All records
         */
       $query = "SELECT * FROM " . $this->tbl_name;
      

$orderObj = set_order($postData->sort, $postData->order);
        $limitObj = set_limit($postData->page, $postData->limit);
        $queryString = $query . $this->whereOrAnd . $this->where . $orderObj->query_string . $limitObj->query_string;
        $queryRun = $this->db->query($queryString);
        $queryResult = $queryRun->result();

        $params = request_params($queryCountResult->num_records, $orderObj->sort, $orderObj->order, $limitObj->limit, $limitObj->page, $limitObj->start, $postData->field);

        $response = new stdClass();
        $response->params = $params;
        $response->result = $queryResult;
        return $response;
    }
}
