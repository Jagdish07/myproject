<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of social
 *
 * @author wiesoftware26
 */
class Social extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('social_model');
    }

    public function index() {
        $this->data['view'] = 'main';
        $this->data['module_assets'] = 'social/module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }

    public function create() {
        $this->data['view'] = 'create';
        $this->load->view('theme/admin/layout', $this->data);
    }

    public function edit($id = false) {
        if (!$id) {
            redirect('social');
        } else {
            $this->data['record'] = $this->get_model_data($id);
            $this->data['view'] = 'edit';
            $this->load->view('theme/admin/layout', $this->data);
        }
    }

    public function process() {
        if ($this->input->post()) {
            $this->form_validation->set_error_delimiters('<span class="error">', '</span>');
            $this->form_validation->set_rules('name', 'Name', 'required|trim|xss_clean');
            $this->form_validation->set_rules('url', 'Url', 'required|trim|xss_clean');
            if ($this->form_validation->run() == TRUE) {
                $this->set_model_data();
                if ($this->input->post('id') == 'new') {
                    $inseretd = $this->social_model->insert_data();
                    if($inseretd) {
                         $this->session->set_flashdata('success_message', 'Data inserted successfully.');
                    } else {
                        $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
                    }
                } else {
                    $updated = $this->social_model->update_data();
                     if($updated) {
                         $this->session->set_flashdata('success_message', 'Data updated successfully.');
                    } else {
                        $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
                    }
                }
                redirect('social');
            } else {
                if ($this->input->post('id') == 'new') {
                    $this->create();
                } else {
                    $this->edit($this->input->post('id'));
                }
            }
        }
    }

    public function delete($id = false) {
        if (!$id) {
            redirect('social');
        } else {
            $this->social_model->setId($id);
            $deleted = $this->social_model->delete_data();
            if ($deleted) {
                $this->session->set_flashdata('success_message', 'Data deleted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
            redirect('social');
        }
    }

    public function set_model_data() {
        $socialObj = $this->social_model;

        if ($this->input->post('id') != 'new') {
            $id = $this->input->post('id');
            $socialObj->setId($id);
        }
        $name = $this->input->post('name');
        $socialObj->setName($name);

        $url = $this->input->post('url');
        $socialObj->setUrl($url);
		
        $socialObj->setStatus(1);
        $socialObj->setCreatedOn();

        return true;
    }

    public function get_model_data($id) {
        $socialObj = $this->social_model;

        $socialObj->setId($id);
        $socialObj->get_row();

        $response = new stdClass();
        $response->id = $socialObj->getId();
        $response->name = $socialObj->getName();
        $response->url = $socialObj->getUrl();
        return $response;
    }
    
    public function update_status() {
        $id = $this->input->get('id');
        if (!$id) {
            redirect('social');
        } else {
            $this->social_model->setId($id);

            $status = $this->input->get('status');
            $this->social_model->setStatus($status);
            $this->social_model->update_status();
            die;
        }
    }

}
