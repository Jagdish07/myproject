
<?php
    
    $input_div_open = '<div class="form-group">';
    $input_div_close = '</div>';
    $required = ' <abbr class="required"><i class="fa fa-asterisk"></i></abbr>';
    $action = 'social/process';
    echo form_open($action);
        
        echo (isset($record->id)) ? form_hidden('id', $record->id) : form_hidden('id', 'new');
    
        echo $input_div_open;
            echo form_label('Name'.$required, 'name');
            $name = array(
                'name' => 'name',
                'class' => 'form-control',
                'id' => 'name',
                'value' => (isset($record->name)) ? $record->name : set_value('name')
            );
            echo form_input($name);
            echo form_error('name');
        echo $input_div_close;
        
         echo $input_div_open;
            echo form_label('Url'.$required, 'url');
            $url = array(
                'name' => 'url',
                'class' => 'form-control',
                'id' => 'url',
                'value' => (isset($record->url)) ? $record->url : set_value('url')
            );
            echo form_input($url);
            echo form_error('url');
        echo $input_div_close;
        
        $submit = array(
            'name' => 'submit',
            'class' => 'btn btn-info',
            'id' =>'submit',
            'value' => 'Submit'
        );
        echo form_submit($submit);
   echo form_close();
?>
<script type="text/javascript" src="<?php echo base_url();?>assets/ckeditor/ckeditor.js"></script>
<script type="text/javascript">
        CKEDITOR.replace('content');
</script>