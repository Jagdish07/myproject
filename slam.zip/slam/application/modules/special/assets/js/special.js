function add_new_special(id, type){
 postArray={
                'id':id,'type':type,
              }
  $.post('add_special', postArray, function(data){
  	 var json_data = $.parseJSON(data);
  	  if(json_data.status === 'success') {
  	  	$('.dynamic_data table').append(json_data.html);

  	  }

  });

}

function remove_special(id, type){

	$('#remove_special_'+id+'_'+type).remove();

}
