<?php
error_reporting(0);
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of special
 *
 * @author wiesoftware26
 */
class Special extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->load->model('special_model');
    }
    
     public function index() {
        $this->data['view'] = 'main';
        $this->data['module_assets'] = 'special/module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }
     public function create() {

     
         $this->data['module_assets'] = 'special/module_assets';
        $this->data['view'] = 'create';
        $this->load->view('theme/admin/layout', $this->data);
    }
    
     public function edit($id = false) {
        if (!$id) {
            redirect('special');
        } else {
          
            $this->data['record'] = $this->get_model_data($id);
          $this->data['module_assets'] = 'special/module_assets';
            $this->data['view'] = 'edit';
            $this->load->view('theme/admin/layout', $this->data);
        }
    }
    
    public function add_special(){
        $response = new stdClass();
        if($this->input->post('type')=='product'){
            $this->data['detail'] = get_product_detail($this->input->post('id'));

        }
        if($this->input->post('type')=='category'){

            $this->data['detail'] = get_category_detail($this->input->post('id'));
        }
        

        $this->data['type'] = $this->input->post('type');
        $html = $this->load->view('spec_html',$this->data,TRUE);
        $response->html = trim($html);
        $response->status = 'success';
        echo json_encode($response);
        die;
   }
    public function delete($id = false) {
        if ($id) {
            $this->special_model->setId($id);
            $deleted = $this->special_model->delete_data();
            if ($deleted) {
                $this->session->set_flashdata('success_message', 'Data deleted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        }
        redirect('special');
    }
    
    public function process() {

        //print"<pre>";   print_R($_POST); die;
        if ($this->input->post()) {
            $this->form_validation->set_error_delimiters('<span class="error">', '</span>');
            $this->form_validation->set_rules('title', 'title', 'required|trim|xss_clean');
          
            //$this->form_validation->set_rules('description', 'description', 'required|trim|xss_clean');

            $this->form_validation->set_rules('price', 'price', 'required|xss_clean');
            //$this->form_validation->set_rules('sku', 'sku', 'required|xss_clean');
            $this->form_validation->set_rules('sequence', 'sequence', 'integer|trim|xss_clean');

            if ($this->form_validation->run() == TRUE) {
              
                    $this->data_operation();
                    redirect('special');
                
                }
            }
            $this->load_view();
        }
    
    public function data_operation() {

        $this->set_model_data();
        if ($this->input->post('id') == 'new') {
            $inserted = $this->special_model->insert_data();

            if ($inserted) {
                $this->session->set_flashdata('success_message', 'Data inserted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        } else {

            $updated = $this->special_model->update_data();
            if ($updated) {
                $this->session->set_flashdata('success_message', 'Data updated successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        }
        redirect('special');
    }
    
    public function load_view() {
        if ($this->input->post('id') != 'new') {
            $this->edit($this->input->post('id'));
        } else {
            $this->create();
        }
    }
    
    public function set_model_data() {

            $specialObj = $this->special_model;

            if ($this->input->post('id') != 'new') {
                $id = $this->input->post('id');
                $specialObj->setId($id);
            }
            
           
            $title = $this->input->post('title');
            $specialObj->setTitle($title);
       
        
            $description = $this->input->post('description');
            $specialObj->setDescription($description);
            
            $short_description = $this->input->post('short_description');
            $specialObj->setShortDescription($short_description);
           
            $price = $this->input->post('price');
            $specialObj->setPrice($price);
            
            $special = serialize($this->input->post('special'));
            $specialObj->setSpecial($special);

          
            $specialObj->setStatus(1);

            $sequence = $this->input->post('sequence');
            $specialObj->setSequence($sequence);

            $specialObj->setCreatedOn();
         

            return true;
    }
    
    public function update_status() {
        $id = $this->input->get('id');
        if (!$id) {
            redirect('special');
        } else {
            $this->special_model->setId($id);

            $status = $this->input->get('status');
            $this->special_model->setStatus($status);
            $this->special_model->update_status();
            die;
        }
    }
    
    public function get_model_data($id) {
        $specialObj = $this->special_model;

        $specialObj->setId($id);

        $specialObj->get_row();

        $response = new stdClass();
        $response->id = $specialObj->getId();
        $response->title = $specialObj->getTitle();
        $response->description = $specialObj->getDescription();
        $response->short_description = $specialObj->getShortDescription();
        $response->price = $specialObj->getPrice();
        $response->special = unserialize($specialObj->getSpecial());
        $response->sequence = $specialObj->getSequence();
        
        return $response;
    }
 
}
