<?php
$input_div_open = '<div class="form-group">';
$input_div_close = '</div>';
$required = ' <abbr class="required"><i class="fa fa-asterisk"></i></abbr>';
$action = 'special/process';
?>
<ul class="nav nav-tabs">
    <li class="active">
        <a href="#general" data-toggle="tab">General</a>
    </li>
   <li class="">
        <a href="#seo" data-toggle="tab">Food</a>
    </li>
    <!-- <li class="">
        <a href="#inventory" data-toggle="tab">Inventory</a>
    </li>
    <li class="">
        <a href="#custom" data-toggle="tab">Custom fields</a>
    </li>-->
</ul>
<?php

echo form_open_multipart($action);
echo (isset($record->id)) ? form_hidden('id', $record->id) : form_hidden('id', 'new');
?>
<div class="tab-content">
    <div class="tab-pane fade active in" id="general">
        <h4>General information</h4>
        <hr class="whiter"/>
        <div class="row">
            <div class="col-md-8">
                <?php
                echo $input_div_open;
                echo form_label('Title' . $required, 'title');
                $title = array(
                    'name' => 'title',
                    'class' => 'form-control',
                    'id' => 'title',
                    'value' => (isset($record->title)) ? $record->title : set_value('title')
                );
                echo form_input($title);
                echo form_error('title');
                echo $input_div_close;
                
                echo $input_div_open;
                echo form_label('Price' . $required, 'price');
                $price = array(
                    'name' => 'price',
                    'class' => 'form-control',
                    'id' => 'price',
                    'value' => (isset($record->price)) ? $record->price : set_value('price')
                );
                echo form_input($price);
                echo form_error('price');
                echo $input_div_close;

                
             

               
                echo $input_div_open;
                echo form_label('Description', 'description');
                $description = array(
                    'name' => 'description',
                    'class' => 'form-control',
                    'id' => 'description',
                    'value' => (isset($record->description)) ? $record->description : set_value('description')
                );
                echo form_textarea($description);
                echo form_error('description');
                echo $input_div_close;

                echo $input_div_open;
                echo form_label('Short description', 'short_description');
                $short_description = array(
                    'name' => 'short_description',
                    'class' => 'form-control',
                    'id' => 'short_description',
                    'rows' => '4',
                    'value' => (isset($record->short_description)) ? $record->short_description : set_value('short_description')
                );
                echo form_textarea($short_description);
                echo form_error('short_description');
                echo $input_div_close;

               

                echo $input_div_open;
                echo form_label('Sequence', 'sequence');
                $sequence = array(
                    'name' => 'sequence',
                    'class' => 'form-control',
                    'id' => 'sequence',
                    'style' => 'width:250px',
                    'value' => (isset($record->sequence)) ? $record->sequence : set_value('sequence')
                );
                echo form_input($sequence);
                echo form_error('sequence');
                echo $input_div_close;
                ?>
            </div>
        </div>
    </div>  
    <div class="tab-pane fade" id="seo">
        <h4>information</h4>
        <div class="dynamic_data"> 
            <table class="table table-striped">
                <tr>
                    <th>Name </th>
                    <th>Price Sequence</th>
                    <th>Price </th>
                    <th>Qty</th>
                     <th></th>
                </tr>
        <?php if(isset($record->special)){
       foreach($record->special as $special){
    //print"<pre>";  print_R($special);
       if($special['type']=='category'){
           $detail = get_category_detail($special['id']);
       }
       if($special['type']=='product'){
            $detail = get_product_detail($special['id']);
        }
       ?>
    <tr id="remove_special_<?php echo $special['id'];?>_<?php echo $special['type'];?>">
        <td><?php echo $detail->title; ?></td>
         <td><select name="special[<?php echo $special['id']; ?>][status]">
                <option value="">Select</option>
                <option value="less" <?php if($special['status']=='less'){ echo 'selected="selected"';}else{ echo ''; }?>>less</option>
                <option value="geater" <? if ($special['status'] =='geater'){ echo " selected"; } ?>>geater</option>
                <option value="Equal" <?php if($special['status']=='Equal'){ echo 'selected="selected"';}else{ echo ''; }?>>Equal</option>
            </select></td>
            <input type="hidden" name="special[<?php echo $special['id']; ?>][id]" value="<?php echo $special['id']; ?>" />
            <input type="hidden" name="special[<?php echo $special['id']; ?>][type]" value="<?php echo $special['type']; ?>" />

          <td><input type="text" value="<?php echo $special['price']; ?>" name="special[<?php echo $special['id']; ?>][price]"/></td>
           <td><input type="text" value="<?php echo $special['qty']; ?>" name="special[<?php echo $special['id']; ?>][qty]"/></td>
            <td>
                <a class="btn btn-danger btn-sm" onclick="remove_special(<?php echo $special['id'];?>, '<?php echo $special['type'];?>')">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
            </td>
       </tr>
     <?php } } ?>

              </table>
                

        </div>
        <hr class="whiter"/>
        <div class="food-data">
         <label class="checkbox-inline" onClick="load_categories('special');">Category</label>
         <label class="checkbox-inline" onClick="load_products('special');">Product</label>
           </div>

        <div class="col-md-12">
            <div class="col-md-6">
            <h2 style="margin: 19px 0px;">Categories</h2>
            <div class="row">
                <div class="col-md-6 col-lg-6 col-xs-12 col-md-12">
                    <div class="form-group input-group">
                        <input class="form-control" type="text" name="nameSearch__category" id="nameSearch__category" />
                        <span class="input-group-addon"><i class="fa fa-search"></i></span>
                    </div>
                </div>
            </div>
            <div class="list__category">

            </div>
        </div>
         <div class="col-md-6">
            <h2 style="margin: 19px 0px;">Products</h2>
            <div class="row">
                            <div class="col-md-6 col-lg-6 col-xs-12 col-md-12">
                                <div class="form-group input-group">
                                    <input class="form-control" type="text" name="nameSearch__products" id="nameSearch__products" />
                                    <span class="input-group-addon"><i class="fa fa-search"></i></span>
                                </div>
                            </div>
                        </div>
            <div class="list__products">

            </div>
        </div>
    </div>
    </div>
    

</div>

<?php
$submit = array(
    'name' => 'submit',
    'class' => 'btn btn-info',
    'id' => 'submit',
    'value' => 'Submit'
);
echo form_submit($submit);

echo form_close();
?>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/ckeditor/ckeditor.js"></script>
<script type="text/javascript">
    CKEDITOR.replace('description');
</script>