	<tr id="remove_special_<?php echo $detail->id;?>_<?php echo $type;?>">
		<td><?php echo $detail->title;?> </td>
		<td>
			<select name="special[<?php echo $detail->id;?>][status]">
				<option value="">Select</option>
				<option value="less">less</option>
				<option value="geater" >geater</option>
				<option value="Equal">Equal</option>
			</select>
			<input type="hidden" name="special[<?php echo $detail->id;?>][id]" value="<?php echo $detail->id;?>" />
			<input type="hidden" name="special[<?php echo $detail->id;?>][type]" value="<?php echo $type;?>" />
		</td>
		<td><input type="text" value="" name="special[<?php echo $detail->id;?>][price]"/> </td>
		<td><input type="text" value="" name="special[<?php echo $detail->id;?>][qty]"/></td>
	</tr>