<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of testmonial
 *
 * @author wiesoftware26
 */
error_reporting(E_ALL);

class Testmonial extends CI_Controller {

    function __construct() {
        parent::__construct();
       $this->load->helper('testmonial');
        $this->load->model('testmonial_model');
    }

    public function index() {
        $this->data['view'] = 'main';
        $this->data['module_assets'] = 'testmonial/module_assets';
        $this->load->view('theme/admin/layout', $this->data);
    }

    public function create() {
        $this->data['view'] = 'create';
        $this->load->view('theme/admin/layout', $this->data);
    }

    public function edit($id = false) {
        if (!$id) {
            redirect('testmonial');
        } else {
            $this->data['record'] = $this->get_model_data($id);
            $this->data['view'] = 'edit';
            $this->load->view('theme/admin/layout', $this->data);
        }
    }

    public function delete($id = false) {
        if ($id) {
            $this->testmonial_model->setId($id);
            $deleted = $this->testmonial_model->delete_data();
            if ($deleted) {
                $this->session->set_flashdata('success_message', 'Data deleted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        }
        redirect('testmonial');
    }

    public function process() {

        if ($this->input->post()) {
            $this->form_validation->set_error_delimiters('<span class="error">', '</span>');
            $this->form_validation->set_rules('title', 'Name', 'required|trim|xss_clean');
            $this->form_validation->set_rules('subtitle', 'subtitle', 'trim|xss_clean');
            $this->form_validation->set_rules('sequence', 'sequence', 'integer|trim|xss_clean');
            if ($this->form_validation->run() == TRUE) {
                if ($_FILES['file']['error'] == 4 && $this->input->post('id') != 'new') {
                    $this->data_operation();
                    redirect('testmonial');
                } else {

                    $get_data = $this->image_upload();

                    if (isset($get_data->upload_data)) {
                        $this->data_operation($get_data->upload_data);
                        redirect('testmonial');
                    }
                }
            }
            $this->load_view();
        }
    }

    public function data_operation($data = false) {

          
        if ($this->input->post('id') == 'new') {

            $this->set_model_data($data['orig_name']);
         
            $inserted = $this->testmonial_model->insert_data();

            if ($inserted) {
                $this->session->set_flashdata('success_message', 'Data inserted successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        } else {
            if ($data) {
                $this->set_model_data($data['orig_name']);
            } else {
                $this->set_model_data();
            }

            $updated = $this->testmonial_model->update_data();
            if ($updated) {
                $this->session->set_flashdata('success_message', 'Data updated successfully.');
            } else {
                $this->session->set_flashdata('error_message', 'Somthing going wrong. Please try again.');
            }
        }
        redirect('testmonial');
    }

    public function load_view() {
        if ($this->input->post('id') != 'new') {
            $this->edit($this->input->post('id'));
        } else {
            $this->create();
        }
    }

    public function image_upload() {
       // print_R(testmonial_path()); die;
        $config['upload_path'] = testmonial_path();
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['file_name'] = time() . date('Ymd');

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('file')) {
            $error = (object) array('error' => $this->upload->display_errors('<span class="error">', '</span>'));
            $this->data['error'] = $error->error;
            return $this;
        } else {
            $data = (object) array('upload_data' => $this->upload->data());

            $configImageResize = array(
                'source_image' => $config['upload_path'] . $data->upload_data['file_name'],
                'new_image' => testmonial_path('thumb'),
                'maintain_ratio' => true,
                'width' => 200,
                'height' => 150
            );
            $this->load->library('image_lib');
            $this->image_lib->initialize($configImageResize);
            $this->image_lib->resize();
            //for used
                $configImageusedResize = array(
                    'source_image' => $config['upload_path'].$data->upload_data['file_name'],
                    'new_image' => testmonial_path('used'),
                    //'maintain_ratio' => true,
                    'width' => 125,
                    'height' => 120
                );
                $this->image_lib->initialize($configImageusedResize);
                $this->image_lib->resize();
                $this->image_lib->clear();
        }
        return $data;
    }

    public function set_model_data($file_name = false) {
        $testmonialObj = $this->testmonial_model;

        if ($this->input->post('id') != 'new') {
            $id = $this->input->post('id');
            $testmonialObj->setId($id);
        }
        $title = $this->input->post('title');
        $testmonialObj->setTitle($title);

        $subtitle = $this->input->post('subtitle');
        $testmonialObj->setSubtitle($subtitle);

        $description = $this->input->post('description');
        $testmonialObj->setDescription($description);

        if ($file_name) {
            $testmonialObj->setImage($file_name);
        }
        $testmonialObj->setStatus(1);

        $sequence = $this->input->post('sequence');
        $testmonialObj->setSequence($sequence);

        $testmonialObj->setCreatedOn();

        return true;
    }

    public function update_status() {
        $id = $this->input->get('id');
        if (!$id) {
            redirect('testmonial');
        } else {
            $this->testmonial_model->setId($id);

            $status = $this->input->get('status');
            $this->testmonial_model->setStatus($status);
            $this->testmonial_model->update_status();
            die;
        }
    }

    public function get_model_data($id) {
        $testmonialObj = $this->testmonial_model;

        $testmonialObj->setId($id);
        $testmonialObj->get_row();

        $response = new stdClass();
        $response->id = $testmonialObj->getId();
        $response->description = $testmonialObj->getDescription();
        $response->title = $testmonialObj->getTitle();
        $response->subtitle = $testmonialObj->getSubtitle();
        $response->image = $testmonialObj->getImage();
        $response->sequence = $testmonialObj->getSequence();

        return $response;
    }

}
