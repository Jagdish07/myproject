 <?php
          echo link_front_js(
                array(
                    'cart.js',

                  )
        );

        ?>


<style>

.shopping-table{width: 97%;
margin: 0px 0px 0px 16px !important;
border: 2px solid #314192;
border-radius: 15px;}
.shopping-table td{border:1px solid #000;}
.shopping-table th{border:1px solid #000;padding: 10px 26px;}
.shoping-table img{float:left;margin: 30px 30px 0px 0px;}
.colomn p{margin:8px 10px!important;}
.input_type{width: 12%;height: 22px;background-color: #F6F6F6;border: 1px solid #666;text-align:center;}
.lefttt{margin:0px 0px; padding:25px 25px; width:30%;float:left;}
.righttt{margin:0px 0px; width:70%;float:left;}

.table_2{width:100%;}
.table_2 td{border-bottom: 1px solid;padding: 15px 0px;}
.checkout_btn{margin:10px 0px;padding:0px 0px;height:auto;width:100%;}
.checkout_btn button{float: right;padding: 10px 31px;background: rgb(225, 6, 6) none repeat scroll 0% 0%;color: rgb(255, 255, 255);border: 1px solid rgb(225, 6, 6);border-radius: 8px;}
.checkout_btn button:hover{background:#fff;color:rgb(225, 6, 6); text-decoration:none;}

</style>



<div class="container">
   <div class="row">

    <input type="hidden" value="<?php echo $this->cart->total();?>" name="cart_price" class="cart_price"/>
      <div class="col-sm-12 col-md-12 col-lg-12">
          <h2><strong class="totalitem">Shopping Cart(<?php echo $this->cart->total_items();?>)</strong></h2>
      </div>
<?php $setting = get_setting(); ?>
					<input type="hidden" value="<?php echo $setting->max_item;?>" name="order_price" id="order_Price"/>
      <div class="col-sm-12 col-md-12 col-lg-12">
         <table class="table shopping-table">
            <tbody>
               <tr>
                  <th>Name</th>
                  <th>Qty</th>
                   <th>Price</th>
                  <th>subtotal</th>
              </tr>
         <?php      foreach ($this->cart->contents() as $items) {
           //print"<pre>";print_R($items);
        ?>

          <tr class="<?php echo $items['rowid'];?>">
                  <td>

                     <div class="righttt">
                        <p><strong><?php echo $items['name'];?></strong></p>
					<?php if ($this->cart->has_options($items['rowid']) == TRUE): ?>

						<p>


						<?php $attrdetail =  $items['options']['attrdetail'];
            //print"<pre>";print_R($attrdetail);die;
            foreach($attrdetail as $attrdata) { ?>
            <b><?php echo $attrdata->name; ?>:</b>
            <?php $atribute = $attrdata->attr;
              echo $atribute->title.'<br/>';

            ?>

            <?php } ?>


						</p>

						<?php endif; ?>



                       <p><a  onclick="removedata('<?php echo $items['rowid'];?>')"><strong>Remove</strong></a></p>
                     </div>
                  </td>
                  <td class="colomn">


                        <p>Quantity:
                           <input type="text" class="input_type qty_<?php echo $items['rowid'];?>" value="<?php echo $items['qty'];?>" /></input>
                        </p>
                        <p><a onclick="updatedata('<?php echo $items['rowid'];?>')">Change</a></p>

                  </td>
                  <td class="colomn">

                     <p class="itemsprice_<?php echo $items['rowid'];?>">&pound;<?php echo number_format($items['price'],2);?></p>
                  </td>
                  <td class="colomn">

                     <p class="itemsubtotal_<?php echo $items['rowid'];?>">&pound;<?php echo number_format($items['subtotal'],2);?></p>
                  </td>
               </tr>
               <?php } ?>
            </tbody>
         </table>
      </div>
<form action="<?php echo base_url('checkout');?>" method="post">
      <div class="col-sm-12 col-md-12 col-lg-12" style="padding: 13px;">
        <div class="col-md-12" >
          <div>
           <label for="comment">Disclosure:</label>
           <span>Any variation to products may incur additional charges.</span>
          </div>
           <div class="form-group">
  <label for="comment">Additional Notes:</label>
  <textarea class="form-control" rows="5" name="comment" id="comment" style="border: 2px solid rgb(46, 68, 148);">
<?php if($this->session->userdata('comment')!=''){
  echo $this->session->userdata('comment');
} ?>
  </textarea>
</div>
        </div>
         <div class="col-sm-4 col-md-4 col-lg-4 col-md-offset-8">
            <table class="table_2">
               <tbody>
                  <tr>
                     <td>Subtotal Charges</td>
                     <td align="right" class="subtotal">&pound;<?php echo number_format($this->cart->total(),2);?></td>
                  </tr>

               </tbody>
            </table>
            <div class="checkout_btn" >
              <a class="btn btn-default-red" onclick="checkorder('1');" ><i class="fa fa-shopping-cart"></i>Checkout</a>
            </div>
         </div>
      </div>
    </form>
   </div>
</div>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"> Note </h4>
        </div>
        <div class="modal-body">
          <p class="model-content" ></p>
        </div>
        <div class="modal-footer">

        </div>
      </div>
    </div>
  </div>
