 <?php
          echo link_front_js(
                array(
                    'jquery.validate.min.js',
                    'cart.js',

                  )
        );

        ?>

<script>

$(function() {
    $("#login").validate({
      errorElement: "span",
        rules: {

         email:{
            required:true,
            email: true
         },
         password:{
            required:true
         }
        },
        messages: {

         email:{
            required: "The Email is required.",
             email: "Please enter a valid email address",
         },
         password:{
            required:"The  password field is required.",
         }

      },
        submitHandler: function(form) {
            form.submit();
        }
    });
});
$(function() {
    $("#userForm").validate({
        errorElement: "span",
        rules: {
            email :{
                required:true,
                 email: true,
            },

            fname:{
                required:true
            },
            ship_fname:{
                required:true
                },
            lname:{
                required:true
            },
            ship_lname:{
                required:true
                },
            add1:{
                 required:true
                },
            ship_add1:{
                required:true
                },
            city:{
                required:true
                },
            ship_city:{
                required:true
                },
            postcode:{
               remote: "<?php echo base_url('checkout/checkpostcode')?>",
                required:true
            },
            ship_postcode:{
                remote: "<?php echo base_url('checkout/checkpostcode')?>",
                required:true
            },

            mobile:{
                required:true

            },
            ship_mobile:{
                required:true
            }
           },
        messages: {
          fname:{
                required: "The First Name is required.",
           },
           ship_fname:{
                required: "The First Name is required.",
           },
           lname:{
                required: "The last Name is required.",
           },
            ship_lname:{
                required: "The last Name is required.",
           },
           email:{
                required: "The Email is required.",
                email: "Please enter a valid email address",

           },
           add1:{
                required:"The Address field is required."
            },
             ship_add1:{
                required: "The address is required.",
           },
            ship_city:{
                required: "The town/city is required.",
           },

            shipto_mobile:{
                required: "The mobile number is required.",
           },
            city:{
                required:"The town/city field is required."
            },
            postcode:{
                required:"The post code field is required.",
                remote: "Postcode doesnot exist in 3 miles area.",
            },
            ship_postcode:{
                required:"The post code field is required.",
                remote: "Postcode doesnot exist in 3 miles area.",
            },
            payment:{
               required:"Payment field is required."
            },

            mobile:{
                  required:"The mobile number field is required."
            },

        },
        submitHandler: function(form) {
            form.submit();
        }
    });
});
</script>
<style>
#footer{
   margin-top: 51px;
}
   .left_contents{width:100%;margin-top: 20px;}
   .input_type_2{width:100%;border:1px solid;}
   .left_contents td{padding: 5px!important;}
   .headng{margin:0px 0px;border-bottom: 1px solid;padding-bottom: 10px;}
   .radio{margin-top:20px!important;}
   .table-hover{width:100%;margin-top:20px;}
   .checkout_btn button{float: right;padding: 10px 31px;background: rgb(225, 6, 6) none repeat scroll 0% 0%;color: rgb(255, 255, 255);border: 1px solid rgb(225, 6, 6);border-radius: 8px;}
.checkout_btn button:hover{background:#fff;color:rgb(225, 6, 6); text-decoration:none;}


   </style>

<div class="container">
   <div class="row">
       <form name="" id="userForm" method="post" action="<?php echo base_url('checkout/guestuser'); ?>">
      <div class="col-sm-12 col-md-12 col-lg-12">
         <br/>
         <div class="col-md-12">
  <?php if($this->session->flashdata('messagecartlogin')!='') {
            echo $this->session->flashdata('messagecartlogin');
            }
             if($this->session->flashdata('successmessage')!='') {
            echo $this->session->flashdata('successmessage');
            }
    ?>
            </div>
            <br/>
         <p style="font-weight: bold !important;">Fill in the fields below to complete your purchase</p>

       <?php if($this->session->userdata('slamfrontlogged_in')==false) { ?>
    <p>Already Registered? <a class="login_here" href="#" data-toggle="modal" data-target="#myModal" style="font-weight: bold !important;color: #147FA2 !important;"> LOGIN HERE </a></p>
  <?php } ?>
      </div>

 <?php
              if($this->session->userdata('slamfrontuser_id')!='') {
                   $customerBillingDetail = get_customer_billing_detail($this->session->userdata('slamfrontuser_id'));
                     }?>
      <div class="col-sm-12 col-md-12 col-lg-12">
         <div class="col-sm-4 col-md-4 col-lg-4" style="margin-left: -17px !important;">
            <h3 class="headng">Name and Address</h3>

            <table class="left_contents">
               <tbody>

                  <tr>
                     <td>Email*</td>
                     <td><input type="text" class="input_type_2" name="email" value="<?php if(isset($customerBillingDetail->email)) echo $customerBillingDetail->email; ?>" /></input></td>
                  </tr>
                  <tr>
                     <td>First Name*</td>
                     <td><input type="text" class="input_type_2" name="fname"  value="<?php if(isset($customerBillingDetail->first_name)) echo $customerBillingDetail->first_name; ?>"/></input></td>
                  </tr>
                  <tr>
                     <td>Middle Name</td>
                     <td><input type="text" class="input_type_2" name="mname" value="<?php if(isset($customerBillingDetail->middle_name)) echo $customerBillingDetail->middle_name; ?>" /></input></td>
                  </tr>
                  <tr>
                     <td>Last Name*</td>
                     <td><input type="text" class="input_type_2" name="lname" value="<?php if(isset($customerBillingDetail->last_name)) echo $customerBillingDetail->last_name; ?>"/></input></td>
                  </tr>
                  <tr>
                     <td>Address 1*</td>
                     <td><input type="text" class="input_type_2" name="add1"  value="<?php if(isset($customerBillingDetail->address1)) echo $customerBillingDetail->address1; ?>"/></input></td>
                  </tr>
                  <tr>
                     <td>Address 2</td>
                     <td><input type="text" class="input_type_2" name="add2" value="<?php if(isset($customerBillingDetail->address2)) echo $customerBillingDetail->address2; ?>" /></input></td>
                  </tr>
                  <tr>
                     <td>City*</td>
                     <td><input type="text" class="input_type_2" name="city" value= "<?php if(isset($customerBillingDetail->address2)) echo $customerBillingDetail->address2; ?>"/></input></td>
                  </tr>
                  <tr>
                     <td>Post code*</td>
                     <td><input type="text" class="input_type_2" name="postcode" value="<?php if(isset($customerBillingDetail->post_code)) echo $customerBillingDetail->post_code; ?>"/></input></td>
                  </tr>
                  <tr>
                     <td>Mobile Phone*</td>
                     <td><input type="text" class="input_type_2" name="mobile" value="<?php if(isset($customerBillingDetail->phone_no)) echo $customerBillingDetail->phone_no; ?>"/></input></td>
                  </tr>
               </tbody>
            </table>
            <input type="checkbox" name="ship_address" value="1" class="ship_address" checked/><span style="position: relative;
padding: 7px;">Ship To this Address</span></p>
            <table class="left_contents ship_address_data" style="display:none;">
               <tbody>


                  <tr>
                     <td>First Name*</td>
                     <td><input type="text" class="input_type_2" name="ship_fname" /></input></td>
                  </tr>
                  <tr>
                     <td>Middle Name</td>
                     <td><input type="text" class="input_type_2" name="ship_mname" /></input></td>
                  </tr>
                  <tr>
                     <td>Last Name*</td>
                     <td><input type="text" class="input_type_2" name="ship_lname"/></input></td>
                  </tr>
                  <tr>
                     <td>Address 1*</td>
                     <td><input type="text" class="input_type_2" name="ship_add1"/></input></td>
                  </tr>
                  <tr>
                     <td>Address 2</td>
                     <td><input type="text" class="input_type_2" name="ship_add2"/></input></td>
                  </tr>
                  <tr>
                     <td>City*</td>
                     <td><input type="text" class="input_type_2" name="ship_city"/></input></td>
                  </tr>
                  <tr>
                     <td>Post code*</td>
                     <td><input type="text" class="input_type_2" name="ship_postcode"/></input></td>
                  </tr>
                  <tr>
                     <td>Mobile Phone*</td>
                     <td><input type="text" class="input_type_2" name="ship_mobile" /></input></td>
                  </tr>
               </tbody>
            </table>

         </div>
         <div class="col-sm-4 col-md-4 col-lg-4">
            <h3 class="headng">Discount Method</h3>

             <input type="hidden" class="form-control" name="discountvalue" id="discountvaluedata"  value="">
             <input type="hidden" class="form-control" name="disct" id="disct"  value="">
             <input type="hidden" class="form-control" name="disct_percent" id="disct_percent"  value="">
            <div class="form-group">

            <label for="inputPassword">Discount code</label>

            <input type="text" class="form-control" id="Discount" placeholder="Discount">

            </div>
            <button type="button" class="btn btn-primary discount">Apply</button>

            <div id="googleMap" style="width: 336px;
height: 290px;
border: 2px solid #F00;
padding: 5px;
position: relative;
background-color: #E5E3DF;
overflow: hidden;
margin: 11px 0px 0px 4px !important;"></div>

         </div>
         <div class="col-sm-4 col-md-4 col-lg-4">
             <h3 class="headng">Review Order</h3>
            <table class="table table-hover">
                      <thead>
					     <tr>
						    <th>Product Name </th>
							<th>Quantity </th>
							<th>SubTotal</th>
						 </tr>
					  </thead>
					  <tbody>

         <?php foreach ($this->cart->contents() as $items) { ?>
                  <tr>
                  <td><?php echo $items['name'];?><br>
                  <?php if ($this->cart->has_options($items['rowid']) == TRUE): ?>

                   <strong><?php echo $items['options']['name']; ?></strong>
                <?php endif; ?>

                  </td>
                  <td><?php echo $items['qty'];?></td>
                  <td><i> £ </i><?php echo $items['subtotal'];?></td>
                  </tr>

                  <?php } ?>
						 <tr>
							<td></td>
							<td>SubTotal</td>
							<td><i> £ </i><span class="sub-total"><?php echo $this->cart->total(); ?></span></td>
						 </tr>
						  <tr>
							<td></td>
							<td>Discount Coupon</td>
							<td>-<i> £ </i><span class="discount-total">0.00</span></td>
						 </tr>

						 <tr>
							<td style="width:200px;"></td>
							<td><b>Grand Total </b></td>
							<td><i> £ </i><span class="Grand-total"><?php echo $this->cart->total(); ?></span></td>
						 </tr>
					  </tbody>
                 </table>
              <div class="checkout_btn">
              <button type="submit" class="btn btn-default order_btn" name="checkorder">Place Order </button>

            </div>
         </div>
      </div>
   </div>
</form>
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times"></i></button>
            <h4 class="modal-title" id="myModalLabel">Login Detail</h4>
            </div>
            <div class="modal-body">
             <form id="login" autocomplete="off" name="cartlogin" method="post" action="<?php echo base_url('checkout/process')?>">
                     <div class="form-group">
                        <label>email</label>
                           <input type="email" class="form-control"  name="email" id="exampleInputEmail1" placeholder="Enter email" autocomplete="off">
                     </div>
                     <div class="form-group">
                        <label>Password</label>
                           <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Password" autocomplete="off">
                     </div>
                  <button type="submit" name="cartlogin" class="btn btn-primary" style="margin-left: 246px;">Login</button></span>
                   </form>
            </div>
            <div class="modal-footer">

                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i></button>

        </div>
    </div>
  </div>
</div>
<div class="modal fade" id="mydiscountModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times"></i></button>
            <h4 class="modal-title" id="myModalLabel">Discount Code</h4>
            </div>
            <div class="modal-body model-content">

            </div>
            <div class="modal-footer">

                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i></button>

        </div>
    </div>
  </div>
</div>
<script src="http://maps.googleapis.com/maps/api/js"></script>

<script type="text/javascript">

function input_onchange(obj){
  if($(obj).val().length == $(obj).attr('maxlength')) {
        $(obj).next("input").focus();
    }
}

var aroma=new google.maps.LatLng(52.50267,-1.90510);
function initialize()
{
var mapProp = {
  center:aroma,
  zoom:11,
  mapTypeId:google.maps.MapTypeId.ROADMAP
  };

var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
var marker=new google.maps.Marker({
  position:aroma,
  });

marker.setMap(map);

var myCity = new google.maps.Circle({
  center:aroma,
  radius:4828.02,
  strokeColor:"#0000FF",
  strokeOpacity:0.8,
  strokeWeight:2,
  fillColor:"#0000FF",
  fillOpacity:0.4
  });

myCity.setMap(map);
}

google.maps.event.addDomListener(window, 'load', initialize);
</script>
