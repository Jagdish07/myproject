<?php
          echo link_front_js(
                array(
                    'cart.js',
                   
                  )
        );
        
        ?>  


<ul class="list-unstyled">

	<?php foreach ($this->cart->contents() as $items): ?>
		<li class="<?php echo $items['rowid']; ?>">
		<p><input type="text" value="<?php echo $items['qty']; ?>" class="qty_<?php echo $items['rowid']; ?>" name="qty" style="width:30px"/>x <?php echo $items['name']; ?>
<?php if ($this->cart->has_options($items['rowid']) == TRUE): ?>
<?php $attrdetail =  unserialize($items['options']['attrdetail']); 
// print"<pre>";print_R($attrdetail); 
foreach($attrdetail as $attrdata) { ?>

<?php $atribute = $attrdata->attr; 
echo $atribute->title.',';

?>

<?php } ?>

<?php endif; ?>
		<span class="icon-link"><i class="fa fa-pencil updaterow" id="<?php echo $items['rowid']; ?>"></i>
		<i class="fa fa-times deleterow" id="<?php echo $items['rowid']; ?>"></i>
		</span>
		</p>										
		<p class="price">&pound; <?php echo $items['subtotal']; ?></p>
		</li>
	<?php endforeach; ?>	

<li>
												<!-- list for total price-->
												<p>Total</p>
												<p class="price-total">&pound;<?php echo $this->cart->total();?></p>
											</li>
								
</ul>
<div class="checkout">
	 <a class="btn btn-default-red" onclick="checkorder('0');" ><i class="fa fa-shopping-cart"></i>Checkout</a>
</div>