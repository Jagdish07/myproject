  <div class="page-content">
      <div class="heading">
        <h1>The Chef</h1>
      </div>
      <!-- end .heading -->
      <div class="chef-details">
        <div class="container">
          <div class="row">
            <div class="col-md-8">
              <div class="chef-img">
                <img src="<?php echo link_front_image('chef-img.jpg');?>" alt="">
              </div>
              <h4>Abu Antar - Master Chef</h4>
              <div class="share-this">
                <p>Share this on:</p>
                <ul class="list-inline">
                  <li><a href="#"><i class="fa fa-facebook-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-twitter-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-google-plus-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-pinterest-square"></i></a>
                  </li>
                </ul>
                <!-- end ul -->
              </div>
              <!-- end .share-this -->

              <div class="chef-description">
                <p>Few lines about me:</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed, lacinia in, mi. Cras vel lorem. Etiam pellentesque aliquet tellus. Phasellus pharetra nulla ac diam. Quisque semper justo at risus. Donec venenatis,turpis vel hendrerit interdum, dui ligula ultricies purus, sed posuere libero dui id orci. Nam congue, pede vitae dapibus aliquet, elit magna vulputate arcu, vel tempus metus leo non est.</p>

                <ul class="list-inline">
                  <li><a href="#">Tag 1</a>
                  </li>
                  <li><a href="#">Tag 2</a>
                  </li>
                  <li><a href="#">Tag 3</a>
                  </li>
                </ul>
              </div>
              <!-- end .chef-description -->

              <div class="comment-section">
                <h5>Comments (2)</h5>
                <div class="row pad-btm">
                  <div class="col-md-2 col-sm-2 col-xs-4">
                    <img src="<?php echo link_front_image('comment-img.jpg');?>" alt="">
                  </div>
                  <div class="col-md-10 col-sm-10 col-xs-8">
                    <p>
                      <span class="name"><a href="#">John Doe</a></span>
                      <span class="date-time">on July 6,2014 - 21.31 -</span>
                      <a href="#">Reply</a>
                    </p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed, lacinia in, mi.</p>
                  </div>
                </div>
                <!-- end nasted .row -->
                <div class="row pad-btm">
                  <div class="col-md-2 col-sm-2 col-xs-4">
                    <img src="<?php echo link_front_image('comment-img.jpg');?>" alt="">
                  </div>
                  <div class="col-md-10 col-sm-10 col-xs-8">
                    <p>
                      <span class="name"><a href="#">John Doe</a></span>
                      <span class="date-time">on July 6,2014 - 21.31 -</span>
                      <a href="#">Reply</a>
                    </p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed, lacinia in, mi.</p>
                  </div>
                </div>
                <!-- end nasted .row -->
              </div>
              <!-- end .comment-section -->

              <div class="leave-reply">
                <h5>Leave a Reply</h5>
                <form>
                  <div class="row">
                    <div class="col-md-4 col-sm-4">
                      <input type="text" placeholder="Name*">
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <input type="email" placeholder="Email*">
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <input type="text" placeholder="Website">
                    </div>
                  </div>
                  <!-- end nasted .row -->
                  <textarea placeholder="Your comments ..."></textarea>
                  <button><i class="fa fa-pencil-square-o"></i> Post Comment</button>
                </form>
              </div>
              <!-- end .leave-reply -->
            </div>
            <!-- end .col-md-8 grid -->

            <div class="col-md-4">
              <div class="general-info">
                <h4>General Information</h4>
                <ul class="list-unstyled">
                  <li>
                    <span class="value">Experience:</span>
                    <span class="result">20 years</span>
                  </li>
                  <li>
                    <span class="value">School:</span>
                    <span class="result">Paris Cuisine University</span>
                  </li>
                  <li>
                    <span class="value">Speciality:</span>
                    <span class="result">Modern French Cuisine</span>
                  </li>
                  <li>
                    <span class="value">Favourite Cuisine:</span>
                    <span class="result">Asian Traditional</span>
                  </li>
                  <li>
                    <span class="value">Cooks for us:</span>
                    <span class="result">7 years</span>
                  </li>
                  <li>
                    <span class="value">Staff Managed:</span>
                    <span class="result">15 Person</span>
                  </li>
                </ul>
              </div>
              <!-- end .general-info -->
            </div>
          </div>
          <!-- end .row -->
        </div>
        <!-- end .container -->
      </div>
      <!-- end .chef-details -->
    </div>