  <link href='http://fonts.googleapis.com/css?family=Roboto+Slab:400,700' rel='stylesheet' type='text/css'>
<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
  

<style type="text/css">
.page-content .contact-us .contact-details .address p {
    float: left;
    color: #A0999B;
    margin: 0px 0px -22px 2px !important;
    font-size: 14px;
}
.page-content .contact-us .contact-details .time-to-open p {
    float: left;
    color: #A0999B;
    margin: 0px;
    padding: 10px 0px 0px;
    font-size: 14px;
}
</style>



  <div class="page-content">
      <div class="map-section">
        <div id="map_canvas"></div>

      </div>
      <!-- end .map-section -->
      <div class="contact-us">
        <div class="container">
           <?php if($this->session->flashdata('message')!='') { ?>
                                                <div class="alert alert-success">
                                                    <strong>Well done!</strong> <?php echo $this->session->flashdata('message'); ?>
                                                    <i class="fa fa-times" data-dismiss="alert"></i>
                                                </div>
                                                
                                                 <?php } ?>
          <div class="row">
            <div class="col-md-6">
              <div class="contact-details">
                <h4>Contact Details</h4>

                <div class="row">
                  <div class="col-md-6 col-sm-6">
                    <h5> Slam Burgers</h5>
 <?php $sett = get_setting();?>
                    <div class="address clearfix">
                      <p><i class="fa fa-map-marker"></i>
                      </p>
                      <p><?php echo $contact_us_page->content;?></p>
                    </div>
                    <div class="time-to-open clearfix">
                      
					<p><?php //echo $sett->contact;?>
                      <br/>
                        <?php //echo $sett->timing;?></p>
                    </div>
                  </div>
                  <!-- end .grid-layout -->
                  <div class="col-md-6 col-sm-6">
                    
                  </div>
                  <!-- end .grid-layout -->
                </div>
                <!-- end nasted .row -->
              </div>
              <!-- end .contact-details -->
            </div>
            <!-- end .main-grid-layout -->
 
            <div class="col-md-6">

              <div class="send-message">
                <h4>Send Us A Message</h4>
                <form action="<?php echo base_url('menu/contact_us') ?>" method="post" name="contact">
                  <div class="row">
                    <div class="col-md-12">
                      <input type="text" name= "full_name" placeholder="Name*">
                        <?php echo form_error('full_name');?>
                    </div>
                    <div class="col-md-6 col-sm-6">
                      <input type="email" name= "email" placeholder="Email*">
                      <?php echo form_error('email');?>
                    </div>
                   
                  </div>
                  <!-- end nasted .row -->
                  <textarea placeholder="Your message" name= "message"></textarea>
                    <?php echo form_error('message');?>
                  <button><i class="fa fa-paper-plane-o"></i> Submit Message</button>
                </form>
              </div>
              <!-- end .send-message -->
            </div>
            <!-- end .main-grid-layout -->
          </div>
          <!-- end .row -->
        </div>
        <!-- end .container -->
      </div>
      <!-- end .contact-us -->
    </div>