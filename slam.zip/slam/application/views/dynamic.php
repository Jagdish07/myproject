<?php foreach($category as $productslidedata) { ?>
<div class="item-list">
										<div class="list-image">
											<img src="<?php echo product_path('thumb/').$productslidedata->image;?>" alt="">
										</div>
										<div class="all-details">
											<div class="visible-option">
												<div class="details">
													<h6><a href="#"><?php echo $productslidedata->title;?></a>
													</h6>
													
													<p class="m-with-details"><strong>Description:</strong><br><?php echo $productslidedata->description;?>.</p>

													<p class="m-with-details"><strong>Ingredients:</strong><br></p>

													
												</div>

												<div class="price-option fl">
													<h4 class="<?php echo $productslidedata->id;?>"><?php
														$attributeDetail = get_product_attribute_data($productslidedata->id);
													 if(!empty($attributeslideDetail)){ 
													 	 $i=0;
															
															$attrprice = array();
															foreach($attributeslideDetail as $variation){
																$attrprice[]=$variation['attr'][0]->price;
															++$i;
															}
															$attrprice = array_sum($attrprice);
														if($attrprice ==0.00) { ?>
														&pound; <?php echo $productslidedata->price;?> 
														<?php } else{ ?>
														&pound; <?php echo $attrprice;?> 
												<?php } 	}else{ ?>
													&pound; <?php echo $productslidedata->price;?> 
													<?php } ?> </h4>
													<button class="toggle">Option</button>
												</div>
												<!-- end .price-option-->
												<div class="qty-cart text-center clearfix">
													<h6>Qty</h6>
													<form class="">
														<input type="text" placeholder="1">
														<br>
														<button onclick="add_to_cart(<?php echo $productslidedata->id;?>,<?php echo $productslidedata->attr_status;?>,'c')"><i class="fa fa-shopping-cart"></i>
														</button>
													</form>
												</div> <!-- end .qty-cart -->
											</div> <!-- end .vsible-option -->
											<?php 
											if(!empty($attributeslideDetail)){ ?> 
											<div class="dropdown-option clearfix">
												<div class="dropdown-details">
													<form class="default-form">
														<h5>Please Select </h5>
														<?php 
													foreach($attributeslideDetail as $attrslidedetail) { ?>
														<h6><?php echo $attrslidedetail['name'];?></h6>
														
													<?php $j =0;
													 foreach($attrslidedetail['attr'] as $attrkey){  
													 
													 ?>
														<span class="radio-input">
															<?php  if($j ==0 ) { ?>
                                              			  <input type="radio" id="1<?php echo $attrkey->title;?>_<?php echo $attrkey->id;?>" name="data<?php echo $attrslidedetail['name'];?>_<?php echo $productslidedata->id;?>" class="choose1_<?php echo $productslidedata->id;?> attribut_data" value="<?php echo $productslidedata->id;?>_<?php echo $attrslidedetail['nameid'];?>_<?php echo $attrkey->id;?>" checked>
													<?php } else { ?> 
														<input type="radio" id="1<?php echo $attrkey->title;?>_<?php echo $attrkey->id;?>" name="data<?php echo $attrslidedetail['name'];?>_<?php echo $productslidedata->id;?>" class="choose1_<?php echo $productslidedata->id;?> attribut_data" value="<?php echo $productslidedata->id;?>_<?php echo $attrslidedetail['nameid'];?>_<?php echo $attrkey->id;?>">	
														<?php } ?>	
														<label for="1<?php echo $attrkey->title;?>_<?php echo $attrkey->id;?>"><?php echo $attrkey->title;?><i class="fa fa-plus price">&pound; <?php echo $attrkey->price;?></i>
															</label>
														</span>
														<?php ++$j; } } ?>
														
															
														<a class="btn btn-default-red" onclick="add_to_cart(<?php echo $productslidedata->id;?>,<?php echo $productslidedata->attr_status;?>,'c')">Confirm</a>
														<a class="btn btn-default-black">Cancel</a>
													</form>
												</div>
												<!--end .dropdown-details-->
											</div>
											<?php } ?>
											<!--end .dropdown-option-->
										</div>
										<!-- end .all-details -->
									</div>

<?php } ?>