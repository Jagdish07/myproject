<link rel="stylesheet" href="<?php echo base_url();?>assets/front/css/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />
    <script src="<?php echo base_url();?>assets/front/js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
<style type="text/css" media="screen">
.page-header{
  background: none repeat scroll 0% 0% rgb(165, 165, 165);
border-radius: 2px;
padding: 7px;
margin: 5px 2px 14px 0px;
}   
    </style>
<div class="page-content">
      <div class="heading">
        <h1>Our Gallery</h1>
      </div>
      <!-- end .heading -->
      <div class="our-team">
        <div class="container">
          <br><br/>
          <ul class="row gallery clearfix" style="list-style: none;">
  <?php  if(!empty($gallery)){

  foreach($gallery as $gall){ 
    ?>
            <li class="col-lg-3 col-md-4 col-xs-6 thumb" >
                <a class="thumbnail"  href="<?php echo base_url();?>assets/uploads/gallery/thumb/<?php echo $gall->image;?>" rel="prettyPhoto[gallery1]" title="<?php echo $gall->title;?>">
                    
                    <img class="img-responsive" src="<?php echo base_url();?>assets/uploads/gallery/thumb/<?php echo $gall->image;?>" style="width: 243px;
height: 169px;"  alt="<?php echo $gall->title;?>" />
                </a>
            </li>
            <?php }  }else{ ?>
          <li> No Gallery Found </li> 
           <?php } ?>
          </ul>
        </div>
        <!-- end .container -->
      </div>
      <!-- end .our-team -->
    </div>





     






      <script type="text/javascript" charset="utf-8">
      $(document).ready(function(){
        $("area[rel^='prettyPhoto']").prettyPhoto();
        
        $(".gallery:first a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal',theme:'light_square',slideshow:3000, autoplay_slideshow: true});
        $(".gallery:gt(0) a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'fast',slideshow:10000, hideflash: true});
    
        $("#custom_content a[rel^='prettyPhoto']:first").prettyPhoto({
          custom_markup: '<div id="map_canvas" style="width:260px; height:265px"></div>',
          changepicturecallback: function(){ initialize(); }
        });

        $("#custom_content a[rel^='prettyPhoto']:last").prettyPhoto({
          custom_markup: '<div id="bsap_1259344" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div><div id="bsap_1237859" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6" style="height:260px"></div><div id="bsap_1251710" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div>',
          changepicturecallback: function(){ _bsap.exec(); }
        });
      });
      </script>
  
      <!-- Google Maps Code -->
     
      <!-- END Google Maps Code -->
  
      <!-- BuySellAds.com Ad Code -->
      <style type="text/css" media="screen">
        .bsap a { float: left; }
      </style>
      <script type="text/javascript">
      (function(){
        var bsa = document.createElement('script');
           bsa.type = 'text/javascript';
           bsa.async = true;
           bsa.src = '//s3.buysellads.com/ac/bsa.js';
        (document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);
      })();
      </script>