 <?php
          echo link_front_js(
                array(
                    'jquery.validate.min.js',
                   
                  )
        );
        
        ?> 


<script>
$(function() {
    $("#login").validate({
      errorElement: "label",
        rules: {
         
         email:{
            required:true,
            email: true
         },
         password:{
            required:true
         }
        },
        messages: {
      
         email:{
            required: "The Email is required.",   
             email: "Please enter a valid email address",      
         },
         password:{
            required:"The  password field is required.",
         }
         
      },
        submitHandler: function(form) {
            form.submit();
        }
    });
});
$(function() {
   $("#for_password").validate({
        errorElement: "label",
    rules: {
      email:{
        required:true,
        email: true
      }
    },
     messages: {
    
       email:{
        required: "The Email is required.",   
         email: "Please enter a valid email address",   
       }
    },
     submitHandler: function(form) {
            form.submit();
        }
     });
});
</script>



<style>
  .new_customer{display: block;margin: 0px 10px;padding: 0px;height: 337px;width: auto;border: 2px solid #DDD !important;}
  .new_customer_1{display: block;margin: 0px;padding: 7px 20px;background-color: #DDD;text-transform: uppercase;font-weight: bold;font-size: 14pt;}
  .new_customer p{margin: 20px;text-transform: capitalize;color: #666;}
  .new_customer h5{margin: 0px 20px 10px;text-transform: capitalize;color: #666;}
  .customer_button{border-radius: 0px !important;margin: 0px 20px !important;width: 26% !important;padding: 10px 0px !important;background-color: #000 !important;color: #FFF !important;text-transform: uppercase !important;border: 0px none !important;}
  .checkout_btn{padding: 14px 19px;}
  .checkout_btn a{padding: 10px 31px;background: rgb(225, 6, 6) none repeat scroll 0% 0%;color: rgb(255, 255, 255);border: 1px solid rgb(225, 6, 6);border-radius: 8px;}
.checkout_btn a:hover{background:#fff;color:rgb(225, 6, 6); text-decoration:none;}
.returning_customer{display: block;margin: 0px 10px;padding: 0px;height: 337px;width: auto;border: 2px solid #DDD !important;}
.returning_customer_1{display: block;margin: 0px;padding: 7px 20px;background-color: #DDD;text-transform: uppercase;font-weight: bold;font-size: 14pt;}
.space_20{height:20px;}
.returning_customer p{margin: 20px;text-transform: capitalize;color: #666;}
.forgot{display: block;margin: 0px 20px;text-transform: capitalize;text-decoration: underline;color: #666;}
.forgot a{color: #666;}
.customer_button2{padding: 10px 31px!important;background: rgb(225, 6, 6) none repeat scroll 0% 0%!important;color: rgb(255, 255, 255)!important;border: 1px solid rgb(225, 6, 6)!important;border-radius: 8px!important;float:right;}
.customer_button2:hover{background:#fff!important;color:rgb(225, 6, 6)!important; text-decoration:none;}
.formm_group{padding: 0px 21px!important;}

</style>



<div class="container">
   <div class="row">
    <br/>
     <div class="col-md-12">
        <?php if($this->session->flashdata('mess')!='') { 
         echo $this->session->flashdata('mess');
         } ?>
      </div>
      <div class="col-sm-12 col-md-12 col-lg-12">
         <h2 style="margin-left: 24px;"><strong>Login</strong></h2>
         <div class="col-lg-6 col-md-6 col-sm-6 margen_padding">
            <div class="new_customer">
               <span class="new_customer_1">New Customer</span>
                 <p>welcome to slam-chicken.Set up your secure account  and checkout will be quicker when you place future orders.</p>
                 <h5>(you will be asked to create password later)</h5>
                <div class="checkout_btn">
                   <a href="<?php echo base_url('register/user');?>">Place Order</a>
                </div>
            </div>
         </div>
         <div class="col-sm-6 col-md-6 col-lg-6">
            <div class="returning_customer">
               <span class="returning_customer_1">Returning Customer </span>
			  
			  
                  <p>Login Detail</p>
                  <div class="col-md-12">
        <?php if($this->session->flashdata('messagelogin')!='') { 
         echo $this->session->flashdata('messagelogin');
         } ?>
         </div>
				   
                  <form novalidate="novalidate" id="login" name="login" method="post" action="<?php echo base_url('register/process');?>">
                     <div class="form-group formm_group">
                        <span class="exampleInputEmail1">E-mail address</span>
                           <input class="form-control form-control2" name="email" id="exampleInputEmail1" placeholder="Enter email" type="email">
                     </div>
                     <div class="form-group formm_group">
                        <span class="exampleInputPassword1">Password</span>
                           <input class="form-control form-control2" name="password" id="exampleInputPassword1" placeholder="Password" type="password">
                     </div>
                 
                  <span class="forgot"><a href="#" data-toggle="modal" data-target="#Modal">Forfet Password?</a>
                    <button type="submit" name="login" class="btn customer_button2">Login Securely</button>
                 </span>
                   </form>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times"></i></button>
            <h4 class="modal-title" id="myModalLabel">Forget Password</h4>
            </div>
            <div class="modal-body">
        <form id="for_password" class="for_password" action="<?php echo base_url('register/forgetpassword');?>" method="post">
            <div class="form-group">
                        <span class="exampleInputEmail1">Email</span>
                           <input type="email" class="form-control"  name="email" id="exampleInputEmail1" placeholder="Enter email">
                     </div>
           <button class="btn btn-info" type="submit" style="margin-left: 337px;">Submit</button>
            
        </form>
            </div>
            <div class="modal-footer">
       
                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i></button>
               
        </div>
    </div>
  </div>
</div>