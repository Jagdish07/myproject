<script src="http://maps.googleapis.com/maps/api/js"></script>
<script type="text/javascript">
var aroma=new google.maps.LatLng(52.455300, -1.877072);
function initialize()
{
var mapProp = {
  center:aroma,
  zoom:8,
  mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  
var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
var marker=new google.maps.Marker({
  position:aroma,
  });

marker.setMap(map);

var myCity = new google.maps.Circle({
  center:aroma,
  radius:4828.02,
  strokeColor:"#0000FF",
  strokeOpacity:0.8,
  strokeWeight:2,
  fillColor:"#0000FF",
  fillOpacity:0.4
  });

myCity.setMap(map);
}

google.maps.event.addDomListener(window, 'load', initialize);
</script>
<?php 
        echo link_front_css(
                array(
                    'thumb-slide.css',
                   
                  )
        );
          echo link_front_js(
                array(
                    'cart.js',
                   
                  )
        );
        
        ?>  
<SCRIPT TYPE="text/javascript">
$(document).ready(function(){
	var url =$(location).attr('hash');

	 activaTab(url);

});
function activaTab(tab){
        $('.nav-tabs a[href="' + tab + '"]').tab('show');
    };
$(document).ready(function(){
	$('.zip_code').on('blur', function(){
		//alert("sdsfdsf");die;
		$('#zipfieldError').hide();
		var zipcode = $('#zip_field').val();
		//alert(zipcode);
		
		if(zipcode){
			//alert(zipcode);die;

			 $.ajax({
                   'url' : '<?php echo base_url('checkout/checkpostcode')?>',
                    'type' : 'GET', 
                    'data' : {'postcode' : zipcode},
                    'success' : function(data){       				
                       if(data == 'false'){
                       	alert("Unfortunately we don't deliver to your area, please call us for more information ");
                        $('body #zipfieldError').show();
						return false;
						
                        }else{
							$('#zipfieldError').hide();
							alert("Our Current Delivery time is approximately 30 minutes")
								return true;
							}
						}
					});
			
			}
			
		
		
	})

	$('.region').on('blur', function(){
		var region = $('#region').val();
		if(region){
			$.ajax({
				'url' : '<?php echo base_url('checkout/checkregion')?>',
				'type' : 'GET',
				'data' : {'region': region},
				'success' : function(data){
					 if(data == 'false'){
                       	alert("Unfortunately we don't deliver to your area, please call us for more information ");
                       // $('body #zipfieldError').show();
						return false;
						
                        }else{
							$('#zipfieldError').hide();
							alert("Our Current Delivery time is approximately 30 minutes")
								return true;
							}

				}

			});

		}

		//alert(region);
	})
});
</SCRIPT>
<style>
#main-wrapper .mega-call-us {
    
    padding: 4px !important;
    
}
.nav-tabs > li > a {
   
    font-weight: bold;
    color: #0000;
}
a {
    color: #0000;
    
    text-transform: capitalize;
}
.checkout_grid{margin:0px 0px;padding: 0px 0px;float:left;width:24%;}
.checkout_text{margin:0px 0px;padding: 0px 0px;float:left;width:75%;line-height: 1em;height:auto;}
.icon-link{clear: both;

float: left;
display: block;}
.price_new{clear: both;
display: block;
text-align: right;
}
.delivery{
	background-color:red;
	color: white;
	width: 100%;
}
.btn-pick{
	color: black;
    background-color: rgb(217, 217, 217);
    width: 100%;
}
</style>
			
		<!-- end #header -->
		<!-- thumbnail slide section -->
		<div id="page-content">
			
			<!-- end .thumbnail-slide -->

			<!-- start #main-wrapper -->
			<div class="mega-call-us">
				<div class="container">
					<div class="call-mega-us">
 <?php $sett = get_setting();?>
						<i class="fa fa-phone-square"></i>
						<p>Call Us: :  <?php echo $sett->contact;?></p>
					</div>

					<div class="open-now text-right">
						<i class="fa fa-check-square"></i>
						<p>We are open now (9am-10pm)</p>
					</div>
				</div>
			</div>

			<div class="container">
				<div class="row">
					<?php $setting = get_setting(); ?>
					<input type="hidden" value="<?php echo $setting->max_item;?>" name="order_price" id="order_Price"/>
				
					<div class="col-md-9 col-sm-12 col-md-push-3">
						<ul class="nav nav-tabs" role="tablist">
							<li class="active"><a href="#tab-1" role="tab" data-toggle="tab">All</a>
							</li>
							<?php foreach(get_category_detail() as $catparent){ ?>
							<li><a href="#tab-<?php echo $catparent->id; ?><?php echo $catparent->slug; ?>" role="tab" data-toggle="tab"><?php echo $catparent->title;?></a>
							</li>
							<?php } ?>
							
						</ul>

						<div class="view-style dsn">
							<div class="list-grid-view">
								<button class="thumb-view"><i class="fa fa-list"></i></button>
								<button class="without-thumb"><i class="fa fa-align-justify"></i></button>
								<button class="grid-view"><i class="fa fa-th-list"></i></button>
							 
							</div>
							
							<!-- end .page-list -->
						</div>
						<!-- end view-style -->
						<div class="tab-content">
							<div class="tab-pane fade in active" id="tab-1">
								<?php  foreach(get_category_detail() as $cateparent) { ?>
								<div class="dynamicdaata">
								<div class="all-menu-details">
									<h5><?php echo $cateparent->title; ?></h5>
									<?php $productdetail = get_category_by_product_id($cateparent->id);
                                    if(!empty($productdetail)){ 
									foreach( $productdetail as $productdata) { 
										$attributeDetail = get_product_attribute_data($productdata->id);

										?>
									<div class="item-list">
										<div class="list-image">
											<img src="<?php echo product_path('thumb/').$productdata->image;?>" alt="">
										</div>
										<div class="all-details">
											<div class="visible-option">
												<div class="details">
													<h6><a href="#" style="color:red;"><?php echo $productdata->title;?></a>
													</h6>
<ul class="share-this list-inline text-right">
                            <li><a href="#">Share</a>
                              <ul class="list-inline">
                                <li><a href="#"><i class="fa fa-facebook-square"></i></a>
                                </li>
                                <li><a href="#"><i class="fa fa-twitter-square"></i></a>
                                </li>
                                <li><a href="#"><i class="fa fa-google-plus-square"></i></a>
                                </li>
                                <li><a href="#"><i class="fa fa-pinterest-square"></i></a>
                                </li>
                              </ul>
                            </li>
                          </ul>
													
													<p class="m-with-details"><strong>Description:</strong><br><?php echo trim($productdata->description);?>.</p>

													<p class="m-with-details"><strong>Ingredients:</strong><br></p>

													
												</div>

												<div class="price-option fl">
													<h4 class="<?php echo $productslidedata->id;?>"><?php
													 if(!empty($attributeDetail)){ 
													 	 $i=0;
															
															$attrprice = array();
															foreach($attributeDetail as $attrvariation){
																$attrprice[]=$attrvariation['attr'][0]->price;
															++$i;
															}
															$attrqprice = array_sum($attrprice);
														if($attrqprice ==0.00) { ?>
														&pound; <?php echo $productdata->price;?> 
														<?php } else{ ?>
														&pound; <?php echo $attrqprice;?> 
												<?php } 	}else{ ?>
													&pound; <?php echo $productdata->price;?> 
													<?php } ?> </h4>
													<?php	if($productdata->attr_status!='0'){ ?>
													<button class="toggle">Option</button>
													<?php } ?>
												</div>
												<!-- end .price-option-->
												<div class="qty-cart text-center clearfix">
													<h6>Qty</h6>
													<form class="">
														<input type="text" placeholder="1" class="qty_<?php echo $productdata->id;?>" name="qty" value="1">
														<br>
														<button onclick="add_to_cart(<?php echo $productdata->id;?>,<?php echo $productdata->attr_status;?>,'a')" ><i class="fa fa-shopping-cart"></i>
														</button>
													</form>
												</div> <!-- end .qty-cart -->
											</div> <!-- end .vsible-option -->
											<?php 
											if($productdata->attr_status!='0') {
											if(!empty($attributeDetail)){
											?> 
											<div class="dropdown-option clearfix">
												<div class="dropdown-details">
													<form class="default-form">
														<h5>Please Select </h5>
														
														
													<?php 
													foreach($attributeDetail as $attrdetail) { ?>
													<h6><?php echo $attrdetail['name'];?></h6>

													 <?php $i=0;
													 foreach($attrdetail['attr'] as $key){  
													 
													 ?>
														<span class="radio-input">
															<?php  if($i==0 ) { ?>
                                              			  <input type="radio" id="<?php echo $key->title;?>_<?php echo $key->id;?>" name="<?php echo $attrdetail['name'];?>_<?php echo $productdata->id;?>" class="choose_<?php echo $productdata->id;?> attribut_data" value="<?php echo $productdata->id;?>_<?php echo $attrdetail['nameid'];?>_<?php echo $key->id;?>" checked>
													<?php }else{ ?> 
														<input type="radio" id="<?php echo $key->title;?>_<?php echo $key->id;?>" name="<?php echo $attrdetail['name'];?>_<?php echo $productdata->id;?>" class="choose_<?php echo $productdata->id;?> attribut_data" value="<?php echo $productdata->id;?>_<?php echo $attrdetail['nameid'];?>_<?php echo $key->id;?>">	
														<?php } ?>	
														<label for="<?php echo $key->title;?>_<?php echo $key->id;?>"><?php echo $key->title;?><i class="fa fa-plus price">&pound; <?php echo $key->price;?></i>
															</label>
														</span>
														<?php 
														++$i ;
													} } ?>
														
													<a class="btn btn-default-red" onclick="add_to_cart(<?php echo $productdata->id;?>,<?php echo $productdata->attr_status;?>,'a')">Confirm</a>
														<a class="btn btn-default-red">Cancel</a>
													</form>
												</div>
												<!--end .dropdown-details-->
											</div>
											<?php } } ?>
											<!--end .dropdown-option-->
										</div>
										<!-- end .all-details -->
									</div>
									<!-- end .item-list -->
									<?php } } else {  ?>
									<p>No Product Found</p>
									<?php } ?>
								</div>
								</div>
								<?php } ?>
								<!--end all-menu-details-->

								
								
								<!-- end .pagination -->

							</div> <!-- end .tab-pane -->
							
								<?php foreach(get_category_detail() as $catslide) { ?>
							<div class="tab-pane fade" id="tab-<?php echo $catslide->id;?><?php echo $catslide->slug; ?>">
								
								<div class="all-menu-details">
									<h5><?php echo $catslide->title;?></h5>

									<?php $productslidedetail = get_category_by_product_id($catslide->id);
								if(!empty($productslidedetail)){ 
									foreach( $productslidedetail as $productslidedata) { 
										$attributeslideDetail = get_product_attribute_data($productslidedata->id);
										?>
									<div class="item-list">
										<div class="list-image">
											<img src="<?php echo product_path('thumb/').$productslidedata->image;?>" alt="">
										</div>
										<div class="all-details">
											<div class="visible-option">
												<div class="details">
													<h6><a href="#" style="color:red;"><?php echo $productslidedata->title;?></a>
													</h6>
 <ul class="share-this list-inline text-right">
                            <li><a href="#">Share</a>
                              <ul class="list-inline">
                                <li><a href="#"><i class="fa fa-facebook-square"></i></a>
                                </li>
                                <li><a href="#"><i class="fa fa-twitter-square"></i></a>
                                </li>
                                <li><a href="#"><i class="fa fa-google-plus-square"></i></a>
                                </li>
                                <li><a href="#"><i class="fa fa-pinterest-square"></i></a>
                                </li>
                              </ul>
                            </li>
                          </ul>
													
													<p class="m-with-details"><strong>Description:</strong><br><?php echo $productslidedata->description;?>.</p>

													<p class="m-with-details"><strong>Ingredients:</strong><br></p>

													
												</div>

												<div class="price-option fl">
													<h4 class="<?php echo $productslidedata->id;?>"><?php
													 if(!empty($attributeslideDetail)){ 
													 	 $i=0;
															
															$attrprice = array();
															foreach($attributeslideDetail as $variation){
																$attrprice[]=$variation['attr'][0]->price;
															++$i;
															}
															$attrprice = array_sum($attrprice);
														if($attrprice ==0.00) { ?>
														&pound; <?php echo $productslidedata->price;?> 
														<?php } else{ ?>
														&pound; <?php echo $attrprice;?> 
												<?php } 	}else{ ?>
													&pound; <?php echo $productslidedata->price;?> 
													<?php } ?> </h4>
													<button class="toggle">Option</button>
												</div>
												<!-- end .price-option-->
												<div class="qty-cart text-center clearfix">
													<h6>Qty</h6>
													<form class="">
														<input type="text" placeholder="1">
														<br>
														<button onclick="add_to_cart(<?php echo $productslidedata->id;?>,<?php echo $productslidedata->attr_status;?>,'c')"><i class="fa fa-shopping-cart"></i>
														</button>
													</form>
												</div> <!-- end .qty-cart -->
											</div> <!-- end .vsible-option -->
											<?php 
											if(!empty($attributeslideDetail)){ ?> 
											<div class="dropdown-option clearfix">
												<div class="dropdown-details">
													<form class="default-form">
														<h5>Please Select </h5>
														<?php 
													foreach($attributeslideDetail as $attrslidedetail) { ?>
														<h6><?php echo $attrslidedetail['name'];?></h6>
														
													<?php $j =0;
													 foreach($attrslidedetail['attr'] as $attrkey){  
													 
													 ?>
														<span class="radio-input">
															<?php  if($j ==0 ) { ?>
															
                                              			  <input type="radio" id="1<?php echo $attrkey->title;?>_<?php echo $attrkey->id;?>" name="data<?php echo $attrslidedetail['name'];?>_<?php echo $productslidedata->id;?>" class="choose1_<?php echo $productslidedata->id;?> attribut_data" value="<?php echo $productslidedata->id;?>_<?php echo $attrslidedetail['nameid'];?>_<?php echo $attrkey->id;?>" checked>

													<?php } else { ?> 
														<input type="radio" id="1<?php echo $attrkey->title;?>_<?php echo $attrkey->id;?>" name="data<?php echo $attrslidedetail['name'];?>_<?php echo $productslidedata->id;?>" class="choose1_<?php echo $productslidedata->id;?> attribut_data" value="<?php echo $productslidedata->id;?>_<?php echo $attrslidedetail['nameid'];?>_<?php echo $attrkey->id;?>">	
														<?php } ?>	
														<label for="1<?php echo $attrkey->title;?>_<?php echo $attrkey->id;?>"><?php echo $attrkey->title;?><i class="fa fa-plus price">&pound; <?php echo $attrkey->price;?></i>
															</label>
														</span>
														<?php ++$j; } } ?>
														
															
														<a class="btn btn-default-red" onclick="add_to_cart(<?php echo $productslidedata->id;?>,<?php echo $productslidedata->attr_status;?>,'c')">Confirm</a>
														<a class="btn btn-default-black">Cancel</a>
													</form>
												</div>
												<!--end .dropdown-details-->
											</div>
											<?php } ?>
											<!--end .dropdown-option-->
										</div>
										<!-- end .all-details -->
									</div>
									<!-- end .item-list -->
									<?php } } else{ ?>
									<p>No Product Found</p>
									<?php } ?>
								</div>
								<!-- end all-menu-details -->
							</div> <!-- end .tab-pane  -->
							<?php } ?>

						</div> <!-- end .tab-content -->
					</div>
				
					<!--end main-grid layout-->
					<!-- Side-panel begin -->
					<div class="col-md-3 col-sm-12 col-xs-12 col-md-pull-9">
						<div class="side-panel">
							<form class="default-form">
								<h6 class=" active"></h6>
								<div class="sd-panel-heading" style="display:block;">
									<h5 class="toggle-title">My Check Out</h5>
										<input type="hidden" value="<?php echo $this->cart->total();?>" name="cart_price" class="cart_price"/>
									<div class="ajax-data">
										<?php if($this->cart->total_items()>0){ ?>
										<ul class="list-unstyled">
  	
										<?php foreach ($this->cart->contents() as $items): ?>
												<li class="<?php echo $items['rowid']; ?>">
												<div class="checkout_grid"><input type="text" value="<?php echo $items['qty']; ?>" class="qty_<?php echo $items['rowid']; ?>" name="qty" style="width:30px"/></div><div class="checkout_text"><p>x <?php echo $items['name']; ?>
											<?php if ($this->cart->has_options($items['rowid']) == TRUE): ?>

										

											<?php $attrdetail =  unserialize($items['options']['attrdetail']); 
											// print"<pre>";print_R($attrdetail); 
											foreach($attrdetail as $attrdata) { ?>
											
											<?php $atribute = $attrdata->attr; 
											echo $atribute->title.',';

											?>

											<?php } ?>
											
											<?php endif; ?></p></div>

												<span class="icon-link"><i class="fa fa-pencil updaterow" id="<?php echo $items['rowid']; ?>"></i>
												<i class="fa fa-times deleterow" id="<?php echo $items['rowid']; ?>"></i>
												</span>
												</p>										
												<p class="price price_new">&pound; <?php echo $items['subtotal']; ?></p>
												</li>
										<?php endforeach; ?>
										<li>
												<!-- list for total price-->
												<p>Total</p>
												<p class="price-total">&pound;<?php echo $this->cart->total();?></p>
											</li>
															
									</ul>
									<?php } else{ ?>
									<p>Cart is empty</p>
									<?php } ?>

										<div class="checkout">
											<a class="btn btn-default-red " onclick="checkorder('0');" ><i class="fa fa-shopping-cart"></i>Checkout</a>
										</div>
									</div>
									<!--end .slide-toggle -->
								</div>
								<!-- end .sd-side-panel class -->

								<div class="search-keyword">
									<label class="checkbox-inline btn btn-pick" style="margin: 3px 0px 12px 2px !important;"><input type="radio" name="prefered" value="collection"><img src="<?php echo base_url();?>assets/front/img/shopper_1.png" style="width: 29px;"/>
<b>Pick Up </b></label>
									<label class="checkbox-inline btn delivery" style="margin: 3px 0px 12px 2px !important;"><input type="radio" name="prefered" value="delivery" checked> <img src="<?php echo base_url();?>assets/front/img/icon-truck.png" style="width: 29px;"/><b> Delivery </b></label>
									<br/>

                                                               <h6>Search By Postcode</h6>
<input id="zip_field" name="zip_code"  class="zip_code" size="30" value="" class="zip_field required" maxlength="7" type="text" placeholder="Enter Region Postcode" style="border-radius: unset !important;">                   
                       

									
								</div>
<div id="googleMap" style="width: 200px;
height: 250px;
position: relative;
background-color: #E5E3DF;
overflow: hidden;
margin: 7px 0px 11px 22px;"></div>
								<!-- end .search-keyword -->
								<!--<div class="category">
									<h5 class="">Category</h5>
									<?php $categoryParentDetail = get_category_detail();
									foreach($categoryParentDetail as $catparent){ ?>
									
									<div class="toggle-content">
										<span class="checkbox-input">
													<input type="checkbox" id="<?php echo $catparent->title; ?>-<?php echo $catparent->id; ?>" name="search_cat" class="search_data" value="<?php echo $catparent->id; ?>">
													<label for="<?php echo $catparent->title; ?>-<?php echo $catparent->id; ?>"><?php echo $catparent->title; ?></label>
												</span>
										
									</div>
									<?php } ?>
									
									

								
								</div>-->
								<!--end .category-->
								<div class="miscellaneous">
									
									
								
									<!--end .radio-input -->
								
										
								 
									
								</div>
								<!-- end .miscellaneous-->
								<!-- PRICE FILTER : begin -->
								<div class="properties-search-filter">
									
									<!-- end .price-filter -->
								</div>
								<!-- end .properties-search-filter -->

								
								<!-- end .find-on-map -->
							</form>
							<!-- end form -->
						</div>
						<!-- end side-panel -->
					</div>
					<!--end .col-md-3 -->
				</div>
				<!-- end .row -->
			</div>
			<!--end .container -->
			<!-- footer begin -->
		<!--model-->


		 <!--<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"> Note </h4>
        </div>
        <div class="modal-body">
          <p class="model-content" ></p>
        </div>
        <div class="modal-footer">
         
        </div>
      </div>
    </div>
  </div>-->