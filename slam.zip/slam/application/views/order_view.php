 

<style>


.righ-address span{ display:block; font-size:18px;}
.righ-address a{ color:#000; font-size:18px; text-transform:uppercase; display:block; margin-top:18px;}
.send-address span{ display:block; font-size:18px;}
.content-table th,.content-table td{ border:1px solid black;}
.content-table strong{background:#cdcdcd; display:block;}
.table-data table td{ min-width:100px !important;}

.table-data { width:90% !important; margin:0 auto;}
.sub-total-table { text-align:right; margin-bottom:70px;}

.sub-total-table tr:first-child td:nth-child(2){  width:141px !important;}
.sub-total-table td {height:25px !important; }
.sub-total-table span{ min-width:52px; display:block; }
.sub-total-table { float:right;}
.table-comment{ clear:both; border-top:1px solid black; padding-top:30px; margin-bottom:40px;}
.table-comment p{ font-size:20px;text-align:center; }
.table-bordered {
      border: 1px solid #8D8D8D;

}


</style>


					
	 <div class="row">			
<h3>Thank you for your order!</h3>
<?php
if ($this->session->flashdata('message') != '') {
    echo "<div class='alert alert-success' style='margin-left: 270PX; width:533px;'>";
    echo $this->session->flashdata('message');
    echo "<i class='fa fa-times-circle' style='margin-top:-16px; float:right; cursor:pointer;'></i>";
    echo "</div>";
}?>     
<div class="well">
<div>
   <a href="<?php echo base_url('cart/print_pdf/'.$orderdetail->order_id);?>" title="PDF [new window]" target="_blank">
<button type="button" class="btn btn-warning btn-sm pull-right">
         <i class="fa fa-print"></i> Print
        </button></a>

</div>
<div class="col-md-12">

<img src="<?php echo link_front_image('logo.png'); ?>"/></br>
<small><strong>EXCEPTIONAL INDIAN & BANGLADESHI FOOD</strong></small>
<div class="detail">
 1509 Pershore Road</br>
    Stirchley, Birmingham</br>
    B30 2JL, United Kingdom</br>
    <strong>Tel:</strong> 0795 795 4165 
</div>
<br/>
<div class="table-responsive">
                       <table class="table table-bordered">
                            
                           
                          
                            <tr>
                                <th><strong>Quantity</strong></th>
                               
                               
                                <th><strong>Item name</strong></th>
                                <th><strong>Price</strong></th>
                                <th><strong>Subtotal</strong></th>
                                
                            </tr>
                            <?php foreach($orderproductdetail as $product){
                             
                             ?>
                            <tr>
                                <td><span><?php echo $product->qty;?></span></span></td>
                                
                                <td>
                             <b> <?php echo $product->name;?></b><br/>
                              <?php if(!empty($product->attribute)){
                              $data = unserialize($product->attribute); 
                             
                                foreach($data['attrdetail'] as $attrdata) {
                                ?>
            <b><?php echo $attrdata->name; ?>:</b>
            <?php $atribute = $attrdata->attr; 
              echo $atribute->title.'<br/>';

          } 
                            }
                              ?>

                                </td>
                                <td><span>&pound;<?php echo $product->price;?></span></span></td>
                                <td><span>&pound;<?php echo number_format($product->product_subtotal_price, 2);?></span></span></td>                           
                            </tr>
                            <?php } ?>
                        </table>
                        
                        <table class="sub-total-table">
                            <tr>
                                
                                <td><span>Subtotal</span></td>
                                <td><span>&pound;<?php echo $orderdetail->pay;?></span></td>
                            </tr>
                            <?php if(!empty($orderdetail->disct)) { ?>
                            <tr>
                                <td><span>Discount:</span></td>
                                <td><span>&pound;-<?php $orderdetail->order_total - $orderdetail->pay;?></span></td>
                            </tr>
                            <?php  }
                            ?>
                            <tr>
                                <td><strong>Total</strong></td>
                                <td><strong>&pound;<?php echo $orderdetail->order_total;?></strong></td>
                            </tr>
                            
                        
                            
                        </table>
                        <div>
                            <label><strong>Payment method : </strong> stripe</label><br/>
                            <label><strong>Customer Name  : </strong><?php echo $userdetail->first_name.' '.$userdetail->last_name;?></label></br>
                             <label><strong><?php echo $orderdetail->preferece;?></strong></label></br>
                           
                             <label>
                            <span><strong>Shipping to:</strong></span>
                            <div>
                            <span><strong><?php echo $userdetail->title.' '.$shipdetail->first_name.' '.$shipdetail->last_name?></strong></span></br>
                            <span><?php echo $shipdetail->address1;?></span></br>
                            <span><?php echo $shipdetail->city;?></span></br>
                            <span><?php echo $shipdetail->post_code;?></span></br>
                            <span><?php echo $shipdetail->phone_no;?>,<?php echo $shipdetail->phone2;?></span></br>
                            <span>United Kingdom</span></br>
                        </div></label>
                        </div>
</div>

</div>


</div>



</div>








		