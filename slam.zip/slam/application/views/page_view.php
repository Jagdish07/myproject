<div class="page-content">
      <div class="heading">
        <h1><?php echo $meta_details->page_title;?></h1>
      </div>
      <!-- end .heading -->
      <div class="our-team">
        <div class="container">
        	<br></br>
        	  <span><?php echo $meta_details->content;?></span>
        </div>
        <!-- end .container -->
      </div>
      <!-- end .our-team -->
    </div>
<style>
h3{
	color: blue;
text-transform: capitalize;
background-color: rgb(215, 197, 197);
padding: 8px;
font-weight: bold;
border-radius: 3px;
}

</style>

