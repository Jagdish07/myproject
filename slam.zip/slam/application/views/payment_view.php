
<?php
echo link_front_css(
        array(
        	//'vm-ltr-common.css',
        	'vm-ltr-reviews.css',
        	'bootstrap.css',
        	 'facebox.css',
            'theme.css',
           'custom.css',
        )
);
?>

<div class="tm-middle uk-grid" data-uk-grid-match="" data-uk-grid-margin="">
									<div class="tm-main uk-width-medium-1-1">

	<?php
if ($this->session->flashdata('message') != '') {
	echo "<div class='alert alert-success' style='margin-left: 270PX; width:533px;'>";
	echo $this->session->flashdata('message');
	echo "<i class='fa fa-times-circle' style='margin-top:-16px; float:right; cursor:pointer;'></i>";
	echo "</div>";
}?>			
								<main class="tm-content">
<h3>Online Card Payment</h3>
<h3>Your Takeaway
Price, &pound;<?php echo $orderdetail->order_total;?></h3>
		<form action="<?php echo base_url('payment/charge');?>" method="post">
		    <input type="hidden" value="<?php echo $orderdetail->id;?>" name="orderid"/>
			<input type="hidden" value="<?php echo $orderdetail->order_total;?>" name="planPrice"/>
		  <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
			data-key="<?php echo $stripe['publishable_key']; ?>"
			data-amount= "<?php echo $orderdetail->order_total*100;?>"
			 data-image="<?php  echo base_url();?>assets/front/img/logo.png"
			data-description='<?php if($orderdetail->note!='0'){ echo $orderdetail->note; } ?>'
			data-currency="GBP"
			data-label="Pay Now"></script>
			
		</form>

				</main>
				
				
			</div>
			
                                    
		</div>
		<section class="tm-bottom-b uk-grid" data-uk-grid-match="{target:'> div > .uk-panel'}" data-uk-grid-margin>
    <div class="uk-width-1-1">
        <div class="uk-panel uk-panel-box">
            <p>
                <a href="#">
                    <img src="<?php echo link_front_image('longgraphic.png'); ?>" alt="" />
                </a>
            </p>
        </div>
    </div>
</section>








