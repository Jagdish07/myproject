<?php
          echo link_front_js(
                array(
                    'jquery.validate.min.js',
                   
                  )
        );
        
        ?> 



<SCRIPT TYPE="text/javascript">
 $(function() {
    $("#member-registration").validate({
        errorElement: "label",
        rules: {
            fname:{
                required:true
            },
            lname:{
                required:true
            },
            pass:{
            required:true,
             minlength: 8
         },
         cpass:{
            required:true,
            equalTo: '#jform_password1'
         },
           
            email:{
            required:true,
             email: true,
            remote: "<?php echo base_url('register/checkemail')?>"
         },
         
         cemail:{
            required:true,
            equalTo: '#jform_email1'
         },
        },
        messages: {
          fname:{
                required: "The  firstname is required.",
           },
           lname:{
                required: "The Lastname is required.",
           }, 
          pass:{
            required:"The  password field is required.",
             minlength: "Your password must be at least 8 characters long"
         },
         cpass:{
            required:"The confirm password field is required.",
            equalTo: "Password not match with confirm password.",
         },
             
              email:{
            required: "The Email is required.", 
                email: "Please enter a valid email address",      
                remote: "Email is alredy exist Please Enter New Email Id.",      
            
         },
            cemail:{
            required:"The confirm Email field is required.",
            equalTo: "confirm Email not match with  Email.",
         },
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
});

</SCRIPT>
<style>
  .left_contents{width:100%;margin-top: 20px;}
   .input_type_2{width:100%;border:1px solid;}
   .left_contents td{padding: 5px!important;}
   .register_btn{width:100%;margin:15px 0px;}
   .register_btn label{float:right;margin: 0px 4px;}
   .register_btn button{border: 1px solid rgb(225, 6, 6);padding: 8px 11px;background: rgb(225, 6, 6) none repeat scroll 0% 0%;color: rgb(255, 255, 255);border-radius: 8px;}
   .register_btn button:hover{background:#fff;color:rgb(225, 6, 6); text-decoration:none;}
   .register_btn a{border: 1px solid rgb(225, 6, 6);padding: 8px 11px;background: rgb(225, 6, 6) none repeat scroll 0% 0%;color: rgb(255, 255, 255);border-radius: 8px;}
   .register_btn a:hover{background:#fff;color:rgb(225, 6, 6); text-decoration:none;}
</style>

<div class="container">
   <div class="row">
      <div class="col-sm-12 col-md-12 col-lg-12">
         <?php if($this->session->flashdata('messagelogin')!='') { 
            echo $this->session->flashdata('messagelogin');
            }
             if($this->session->flashdata('successmessage')!='') { 


            echo $this->session->flashdata('successmessage');
            }
    ?>
         <h2 style="margin-left: 14px;">User Registration</h2>
         <form name="register" id="member-registration" action="<?php echo base_url('register/user');?>" method="post">
         <div class="col-sm-4 col-md-4 col-lg-4">
            <h3 class="headng">Name and Address</h3>
            <table class="left_contents">
               <tbody>
                  <tr>
                     <td>First Name*</td>
                     <td><input type="text" class="input_type_2" name="fname" /></input></td>
                  </tr>
                  <tr>
                     <td>last Name*</td>
                     <td><input type="text" class="input_type_2" name="lname" /></input></td>
                  </tr>
                 
                  <tr>
                     <td>Password*</td>
                     <td><input type="password" id="jform_password1" class="input_type_2" name="pass"/></input></td>
                  </tr>
                  <tr>
                     <td>Confirm Password*</td>
                     <td><input type="password" class="input_type_2" name="cpass" /></input></td>
                  </tr>
                  <tr>
                     <td>Email Address*</td>
                     <td><input type="email" class="input_type_2" id="jform_email1" name="email" /></input></td>
                  </tr>
                  <tr>
                     <td>Confirm Email Address*</td>
                     <td><input type="email" class="input_type_2" name="cemail"/></input></td>
                  </tr>
                  
               </tbody>
            </table>
            <div class="register_btn">
               <label><button type="submit" name="login" class="btn customer_button2">Register</button>
               <a href="<?php echo base_url('register');?>">Cancel</a></label>
            </div>
         </div>
      </form>
      </div>
   </div>
</div>