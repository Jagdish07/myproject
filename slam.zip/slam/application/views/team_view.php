 <div class="page-content">
      <div class="heading">
        <h1>Our Team</h1>
      </div>
      <!-- end .heading -->
      <div class="our-team">
        <div class="container">
          <h4>Passion brought us here</h4>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed, lacinia in, mi. Cras vel lorem. Etiam pellentesque aliquet tellus. Phasellus pharetra nulla ac diam.</p>

          <div class="row">
            <div class="col-md-4">
              <div class="profile-pic">
                <img src="<?php echo link_front_image('chef-2.jpg');?>" alt="">
              </div>
              <h5><a href="#">Abu Antar - Master Chef</a></h5>
              <div class="share-this">
                <ul class="list-inline">
                  <li><a href="#"><i class="fa fa-facebook-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-twitter-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-google-plus-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-pinterest-square"></i></a>
                  </li>
                </ul>
                <!-- end ul -->
              </div>
              <!-- end .share-this -->
              <p class="about-chef">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed, lacinia in, mi. Cras vel lorem. Etiam pellentesque aliquet tellus. Phasellus pharetra nulla ac diam.</p>
            </div>
            <!-- end col-md-4 grid layout -->
            <div class="col-md-4">
              <div class="profile-pic">
                <img src="<?php echo link_front_image('chef-2.jpg');?>" alt="">
              </div>
              <h5><a href="#">John Doe</a></h5>
              <div class="share-this">
                <ul class="list-inline">
                  <li><a href="#"><i class="fa fa-facebook-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-twitter-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-google-plus-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-pinterest-square"></i></a>
                  </li>
                </ul>
                <!-- end ul -->
              </div>
              <!-- end .share-this -->
              <p class="about-chef">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed, lacinia in, mi. Cras vel lorem. Etiam pellentesque aliquet tellus. Phasellus pharetra nulla ac diam.</p>
            </div>
            <!-- end col-md-4 grid layout -->
            <div class="col-md-4">
              <div class="profile-pic">
                <img src="<?php echo link_front_image('chef-3.jpg');?>" alt="">
              </div>
              <h5><a href="#">Bill Smith</a></h5>
              <div class="share-this">
                <ul class="list-inline">
                  <li><a href="#"><i class="fa fa-facebook-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-twitter-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-google-plus-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-pinterest-square"></i></a>
                  </li>
                </ul>
                <!-- end ul -->
              </div>
              <!-- end .share-this -->
              <p class="about-chef">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed, lacinia in, mi. Cras vel lorem. Etiam pellentesque aliquet tellus. Phasellus pharetra nulla ac diam.</p>
            </div>
            <!-- end col-md-4 grid layout -->
          </div>
          <!-- end .row -->
        </div>
        <!-- end .container -->
      </div>
      <!-- end .our-team -->
    </div>