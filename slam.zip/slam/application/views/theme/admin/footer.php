 <footer>
	<p>
		<a href="http://webthemez.com"></a>
	</p>
</footer>
