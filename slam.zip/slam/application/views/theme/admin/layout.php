<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="shortcut icon" href="" />
        <title><?php echo site_name(); ?><?php echo (isset($site_name)) ? ' | ' . $site_name : ''; ?></title>

        <?php
        echo link_admin_css(
                array(
                    'bootstrap.css',
                    'font-awesome.css',
                    'morris/morris-0.4.3.min.css',
                    'custom-styles.css',
                    'project-style.css'
                )
        );
        ?>
        <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    </head>
    <body>
        <div id="wrapper">
            <?php $this->load->view('theme/admin/header'); ?>

            <?php $this->load->view('theme/admin/sidebar'); ?>

            <div id="page-wrapper" >
                <div id="page-inner">

                    <?php $this->load->view($view); ?>

                    <?php $this->load->view('theme/admin/footer'); ?>
                </div>
            </div>
        </div>

        <?php
        echo link_admin_js(
                array(
                    'jquery-1.10.2.js',
                    'bootstrap.min.js',
                    'jquery.metisMenu.js',
                    //'morris/raphael-2.1.0.min.js',
                    //'morris/morris.js',
                    'custom-scripts.js',
                    'project-script.js'
                )
        );
        
        if(isset($module_assets)) {
            $this->load->view($module_assets);
        }
        ?>	
    </body>
</html>
