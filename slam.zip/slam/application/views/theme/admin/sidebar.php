<nav class="navbar-default navbar-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav" id="main-menu">
  <?php $module = get_module();
 //print"<pre>";print_r($module);
 

 ?>
            <li>
                <a <?php echo ($this->router->fetch_class() == 'admin') ? 'class="active-menu"' : ''; ?> href="<?php echo base_url('admin');?>"><i class="fa fa-dashboard"></i> Dashboard</a>
            </li>
<?php 

if(in_array('category',$module) || in_array('product',$module) || in_array('special',$module)){ ?>
            <li  <?php echo ($this->router->fetch_class() == 'category' || $this->router->fetch_class() == 'products') ? 'class="active"' : ''; ?> >
                <a href="#"><i class="fa fa-qrcode"></i> Catalog<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                   <?php if(in_array('category',$module)){ ?>

                    <li>
                        <a href="<?php echo base_url('category');?>">Categories</a>
                    </li>
                    <?php  }
                    if(in_array('products',$module)) {
                    ?>
                    <li>
                        <a href="<?php echo base_url('products');?>">Products</a>
                    </li>
                    
                    <?php } ?>
                </ul>
            </li>


            
    <?php } 
    if(in_array('banner',$module) || in_array('cms',$module) || in_array('gallery',$module) || in_array('image',$module)){  ?>
    

			<li <?php echo ($this->router->fetch_class() == 'banner' || $this->router->fetch_class() == 'cms' || $this->router->fetch_class() == 'gallery' || $this->router->fetch_class() == 'image') ? 'class="active"' : ''; ?>>
                <a href="#"><i class="fa fa-files-o"></i> Content Management<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                     <?php if(in_array('banner',$module)){ ?>
                    <li>
                        <a href="<?php echo base_url('banner');?>">Banners</a>
                    </li>
                    <?php }
                     if(in_array('cms',$module)){ ?>
                    <li>
                        <a href="<?php echo base_url('cms');?>">Cms pages</a>
                    </li>
                    <?php }
                      if(in_array('gallery',$module)){ ?>
                    <li>
                        <a href="<?php echo base_url('gallery');?>">Gallery</a>
                    </li>
                    <?php } 
					if(in_array('image',$module)){?>
					 <li>
                        <a href="<?php echo base_url('image');?>">Welcome Image</a>
                    </li>
					<?php } ?>
                </ul>
            </li>
            
<?php }
if(in_array('shoppers',$module)){  ?>
           <li>
                <a <?php echo ($this->router->fetch_class() == 'shoppers') ? 'class="active-menu"' : ''; ?> href="<?php echo base_url('shoppers');?>"><i class="fa fa-user"></i> Customers</a>
            </li>
           <?php } 
           if(in_array('testmonial',$module)){  ?>
           <li>
                <a <?php echo ($this->router->fetch_class() == 'testmonial') ? 'class="active-menu"' : ''; ?> href="<?php echo base_url('testmonial');?>"><i class="fa fa-user"></i> Testmonial</a>
            </li>
           <?php } 
if(in_array('discount',$module)){ 
            ?> 
           
			<li>
                <a <?php echo ($this->router->fetch_class() == 'discount') ? 'class="active-menu"' : ''; ?> href="<?php echo base_url('discount');?>"><i class="fa fa-user"></i> Promotion </a>
            </li>
             <?php } 
			if(in_array('orders',$module)){ 
            ?>
            <li>
                <a <?php echo ($this->router->fetch_class() == 'orders') ? 'class="active-menu"' : ''; ?> href="<?php echo base_url('orders');?>"><i class="fa fa-shopping-cart"></i> Orders</a>
            </li>
			<?php } 
				if(in_array('social',$module)){ 
			?>
			<li>
                <a <?php echo ($this->router->fetch_class() == 'social') ? 'class="active-menu"' : ''; ?> href="<?php echo base_url('social');?>"><i class="fa fa-share-square"></i>
 Social Media</a>
            </li>
         <?php } ?>
        
            <?php if($this->session->userdata('slamusername')=='admin'){  ?>
            <li >
                <a href="#"><i class="fa fa-files-o"></i> Role Management<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo base_url('settings/module_manage');?>">Module</a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('settings/role_manage');?>">Role</a>
                    </li>
                   
                </ul>
            </li>
              <li>
                <a <?php echo ($this->router->fetch_class() == 'admin/manage') ? 'class="active-menu"' : ''; ?> href="<?php echo base_url('admin/manage') ?>"><i class="fa fa-cogs"></i> Admin Management</a>
            </li>
            <li>
                <a <?php echo ($this->router->fetch_class() == 'icons') ? 'class="active-menu"' : ''; ?> href="<?php echo base_url('icons') ?>"><i class="fa fa-cogs"></i> Icons Management</a>
            </li>
            <?php } ?>
            
        </ul>

    </div>

</nav>