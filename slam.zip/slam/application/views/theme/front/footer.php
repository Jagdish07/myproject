<footer id="footer">
         <div class="container">
            <div class="main-footer">
               <div class="row">
                  <div class="col-sm-6 col-md-3">
                    <a href="http://dixy.viewmywebsite.co.uk/"><img src="<?php echo link_front_image('logo.png');?>" alt="">
</a>                     <?php $fotter =get_page('dixy-footer');?>
             <p><?php echo $fotter->short_content; ?></p>
                  </div>

                  <div class="col-sm-6 col-md-3">
                     <h5>Quick Links</h5>
                     <div class="row">
                        <div class="col-md-6">
                           <ul class="footer-links padd">
                              <li><a href="<?php echo base_url();?>">Home</a>
                              </li>
                              <li style="width: 200px;"><a href="<?php echo base_url('menu');?>">Order Online </a>
                              </li>
                              
                           </ul>
                        </div>

                        <div class="col-md-6">
                           <ul class="footer-links">
                              <li><a href="<?php echo base_url('page/about-us');?>">About Us</a>
                              </li>
                              
                              <li><a href="<?php echo base_url('page/contact_us');?>">Contact Us</a>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>

                  <div class="col-sm-6 col-md-3" style="margin-top: 39px;">
                    <!-- <a class="twitter-timeline"  href="https://twitter.com/sienna9023" data-widget-id="661476103341498368">Tweets by @sienna9023</a>
                     <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>-->
          
                  </div>

                  <div class="col-sm-6 col-md-3">
                     <h5>Send Us A Message </h5>
                     <div>
                        <form class="form-horizontal" role="form" method="post" action="welcome/email">
                           <div class="form-group">
                             <div class="col-sm-12">
                                 <input type="text" class="form-control" id="name" name="name" placeholder="Enter Your Name" value="" required>
                             </div>
                           </div>
                           <div class="form-group">
                             <div class="col-sm-12">
                                 <input type="email" class="form-control" id="email" name="email" placeholder="Enter Your Email" value="" required>
                             </div>
                           </div>
                           <div class="form-group">
                             <div class="col-sm-12">
                                 <input type="number" class="form-control" id="phone" name="phone" max="10000000000" min="9999999999" placeholder="Enter Your Number" value="" required>
                             </div>
                           </div>
                           <div class="form-group">
                             <div class="col-sm-12">
                                 <textarea class="form-control" rows="4" name="message" placeholder="Type Your Message" required></textarea>
                             </div>
                           </div>
                           <div class="form-group">
                              <div class="col-sm-12">
                                 <input id="submit" name="submit" type="submit" value="Send" class="btn btn-default-red-inverse pad-top">
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <div class="footer-copyright">
            <div class="container">
           
               <p>Copyright <?php echo date('Y')?> ©  <a href="http://www.prontoetech.co.uk/"><img src="<?php echo link_front_image('PoweredbyProntoIcon.png');?>" alt=""></a></p>
<!--<p>Copyright <?php echo date('Y')?> © Powered By Pronto</p>-->
               <ul class="footer-social">
                  <li><a href="https://www.facebook.com/SlammakeTheDifference/"><i class="fa fa-facebook-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-twitter-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-google-plus-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-linkedin-square"></i></a>
                  </li>
                  <li><a href="#"><i class="fa fa-pinterest-square"></i></a>
                  </li>
               </ul>
               <!-- end .footer-social -->
            </div>
         </div>
      </footer>