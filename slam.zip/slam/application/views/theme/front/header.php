   <header id="header">
         <div class="header-top-bar">
            <div class="container">
               <div class="row">
                  <div class="col-md-5 col-sm-12 col-xs-12">
                     <div class="header-login">
                        <a href="<?php echo base_url('menu') ?>">Order online</a>
                        <?php if($this->session->userdata('dixyfrontlogged_in')==TRUE){ ?>
                        Welcome <b><?php echo $this->session->userdata('dixyfrontuser_name').' '.$this->session->userdata('dixyfrontlast_name');?></b>
                        <a href="<?php echo base_url('register/logout');?>">Logout</a>   
                       <?php  } else{ ?>
                        <a href="<?php echo base_url('register');?>">Login</a>   
                        <?php } ?>
                     </div>
                     <!-- end .header-login -->
                     <!-- Header Social -->
                     <?php $getSocial = get_social_media(); ?>
                     <ul class="header-social">
                        <?php foreach($getSocial as $social) { ?>
                        <li><a href="<?php echo $social->url; ?>" target="_blank"><?php echo $social->icon; ?></a></li>    
                        <?php } ?>
                     </ul>
                  </div>
                  <div class="col-md-7 col-sm-12 col-xs-12">
                     <p class="call-us">
                        Call Us: <span style=" margin-left: 6px; margin-right: 9px;" class="font" href="#"> <?php echo get_setting()->contact;?></span>
                        <?php $opentime = get_open_time(); ?>
                        <span class="open-now"><i class="fa fa-check-square"></i>We are open now (<?php echo $opentime->short_content; ?>)</span>
                        <span class="close-now"><i class="fa fa-square"></i>We are close now (10pm-9am)</span>
                     </p>
                  </div>
               </div> <!-- end .row --> 
            </div> <!-- end .container -->
         </div>
         <!-- end .header-top-bar -->

         <div class="header-nav-bar">
            <nav class="navbar navbar-default" role="navigation" style="height: 127px; !important;">
               <div class="container">
                  <!-- Brand and toggle get grouped for better mobile display -->
                  <div class="navbar-header">
                     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                     </button>
                     <a class="navbar-brand" href="<?php echo base_url();?>">
                        <img src="<?php echo link_front_image('logo.png');?>" width="100%" alt="Dixy-Chicken" style="max-width:72%!important;">
                     </a>
                  </div>

                  <!-- Collect the nav links, forms, and other content for toggling -->
                  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                     <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="<?php echo base_url();?>" title="Home">Home </a>
                           
                        </li>
<li>
            <a href="<?php echo base_url('menu') ?>"  >Our Menu </a>
                   
               </li>
                        <li >
                      <a  href="<?php echo base_url('page/about-us');?>">
                         About Us
                      </a>
                   </li>
                     <li >
                      <a href="<?php echo base_url('page/gallery');?>">
                         Gallery Tour
                      </a>
                   </li>
                   <li>
                      <a  href="<?php echo base_url('menu/contact_us') ?>">
                         Contact Us
                      </a>
                   </li>
                     </ul>
                  </div>
                  <!-- /.navbar-collapse -->
               </div>
               <!-- /.container-fluid -->
            </nav>
         </div>
         <!-- end .header-nav-bar -->
         <!-- small menu section -->
         <div class="small-menu">
            <div class="container">
               <ul class="list-unstyled list-inline">
                  <li><a href="#">&nbsp;</a>
                     <?php $last =  end($this->uri->segment_array()); ?>
                  </li>
                  <?php if($last){ ?>
				  <li></li>
                  <li><a href="our-team.html">&nbsp;</a>
                  </li>
               <?php } ?>
                 <!-- -->
               </ul>
            </div>
            <!-- end .container-->
         </div>
         <!--end .small-menu -->
      </header>
      <!-- end #header -->