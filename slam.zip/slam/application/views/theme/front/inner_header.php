<script>
$(document).ready(function(){
    $(".navbar-header").click(function(){
        $(".menuu_bar").toggle(700);
    });
});
</script>

<style>
	   .inner_header{margin:0px 0px;padding:0px 0px;width:auto;height:auto;}
	   .inner_header ul{margin:0px 0px;padding:35px 0px;width:auto;height:auto;list-style-type:none;}
	   .inner_header ul li{float:left;padding:0px 15px;}
	   .inner_header ul li a{color: #000;font-weight: bold;font-size: 15px;}
	   .inner_header ul li a:hover{text-decoration:none;}
      hr{
    margin-top: 4px;
margin-bottom: 0px;
border-right: 0px none;
border-color: #191919 -moz-use-text-color -moz-use-text-color;
border: 4px solid black;
}
.navbar-toggle{background:#000;float:left;margin: 8px 14px;}
.navbar-toggle .icon-bar{background:#fff;}

/*********media query******************/

@media only screen and (min-device-width : 320px) and (max-device-width : 767px) {

.inner_header ul{padding: 0px 0px;}
.inner_header ul li{float:none;}
.menuu_bar{display:none;}
.shopping-table th{padding:2px!important;}
}




	</style>
<header id="header">
         <div class="header-top-bar">
            <div class="container">
               <div class="row">
               <div class="col-md-7 col-sm-12 col-xs-12">
                     <p class="call-us">
                        Call Us: <a class="font" href="#">+441 214 495227</a>
                        <span class="open-now"><i class="fa fa-check-square"></i>We are open now(9am-10pm)</span>
                        <span class="close-now"><i class="fa fa-square"></i>We are close now(10pm-9am)</span>
                     </p>
                  </div>
                  <div class="col-md-5 col-sm-12 col-xs-12">
                     <div class="header-login">
                        <a href="<?php echo base_url('menu') ?>">Order Online </a>
                        <?php if($this->session->userdata('slamfrontlogged_in')==TRUE){ ?>
                        Welcome <b><?php echo $this->session->userdata('slamfrontuser_name').' '.$this->session->userdata('dixyfrontlast_name');?></b>
                        <a href="<?php echo base_url('register/logout');?>">Logout</a>   
                       <?php  } else{ ?>
                        <a href="<?php echo base_url('register');?>">Login</a>   
                        <?php } ?>
                     </div>
                     <!-- end .header-login -->
                     <!-- Header Social -->
                     <ul class="header-social">
                        <li><a href="#"><i class="fa fa-facebook-square"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-twitter-square"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-google-plus-square"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-linkedin-square"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-pinterest-square"></i></a>
                        </li>
                     </ul>
                  </div>
                  
               </div> <!-- end .row --> 
            </div> <!-- end .container -->
         </div>
<div class="container">
   <div class="row">
      <div class="col-sm-12 col-md-12 col-lg-12">
	     <div class="col-sm-3 col-md-3 col-lg-3">
	     	<a href="<?php echo base_url();?>">
		    <img src="<?php echo link_front_image('inner_logo.png');?>"></a>
		 </div>
		 <div class="col-sm-7 col-md-7 col-lg-7 col-md-offset-2">
		    <div class="inner_header">
                    <div class="navbar-header">
                      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> 
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                </button>
             </div>
			   <ul class="menuu_bar">
			      <li><a href="<?php echo base_url();?>">HOME</a></li>
			      <li><a href="<?php echo base_url('menu') ?>">OUR MENU</a></li>
			      <li><a href="<?php echo base_url('page/about-us');?>">ABOUT US</a></li>
			      <li><a href="">GALLERY TOUR</a></li>
			      <li><a href="<?php echo base_url('menu/contact_us') ?>">CONTACT US</a></li>
			   </ul>
			</div>
		 </div>
	  </div>
   </div>
</div>
   </header>
   <hr></hr>