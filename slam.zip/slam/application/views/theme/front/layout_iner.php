<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <link rel="shortcut icon" href="favicon.ico"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>Slam</title>
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
     <link href='http://fonts.googleapis.com/css?family=Roboto+Slab:400,700' rel='stylesheet' type='text/css'>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>

 <?php

        echo link_front_css(
                array(

                    'bootstrap.css',
                    'font-awesome.min.css',
                    'style.css',
                    'masterslider/style/masterslider.css',
                    'masterslider/skins/black-2/style.css',
                    'responsive.css',
                    'owl.theme.css',
                    'owl.carousel.css',
                  )
        );

        ?>

</head>

 <body style="font-size:16px !important;">
  <div id="main-wrapper">
        <?php $this->load->view('theme/front/header');?>

    </header>
         <?php $this->load->view($view);?>
    <footer>
        <?php $this->load->view('theme/front/footer');?>
    </footer>
    <?php

     echo link_front_js(
                array(

                   'masterslider.min.js',
                    'jquery-ui-1.10.4.custom.min.js',
                   'jquery.magnific-popup.min.js',
                   'owl.carousel.js',
                   'bootstrap.js',
                    'jquery.ui.map.js',
                    'scripts.js',









                )
        );
    ?>
     <script>
    window.jQuery || document.write('<script src="js/jquery-1.11.0.min.js"><\/script>')
    </script>

<script>
$(document).ready(function(){
        var slider = new MasterSlider();
        slider.setup('masterslider', {
            width: 1140,
            height: 500,
            space: 5,
            fullwidth: true,
            speed: 60,
            view: 'flow',
            centerControls: false,
            autoplay:true
        });
        slider.control('bullets', {
            autohide: false
        });
//('.navbar-toggle').hide();

   });
 </script>
      <?php
        if(isset($module_assets)) {
            $this->load->view($module_assets);
        }
        ?>
  </body>
</html>
