<style type="text/css">
h5{
  font-size: 16px;
font-weight: bold;
text-transform: capitalize;
}

</style>
 <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
 <div class="carousel-inner" role="listbox">
     <?php $i=0;
     foreach($banner as $bannerdata){ 
        if($i==0){ ?>
          <div class="item active banner">
       <?php  } else { 
           ?>
            <div class="item banner">
     <?php } ?>
      <img src="<?php echo banner_path('used').$bannerdata->image;?>" alt="..." style="width: 100%;
height: 500px;">
      <div class="carousel-caption">
        
      </div>
    </div>
    <?php 
    ++$i;
  } ?>
    
  </div>
</div>
</div>
</div>
<div id="page-content">
<div class="container">
        <div class="call-to-action-section">
          <div>
            <div class="icon">
              <img src="<?php echo link_front_image('call-to-action-icon1.png');?>" alt="">
            </div>
          </div>
          <div class="text">
            <div>
             <h4 style="margin-top:19px;text-align:left;">Order Online</h4>
             <?php $orderonline = get_page('order-online');?>
             
              <p style="margin: 0px 145px 10px 0px;text-align: justify !important;"><?php echo $orderonline->short_content; ?></p>
            </div>

            <!--div class="css-table-cell">
              <a href="<?php echo base_url('page/'.$orderonline->slug) ?>" class="btn btn-default-red  pad-bottom"><i class="fa fa-file-text-o"></i> Read  More</a>
            </div-->

            <div style="float: right !important;margin-top: -82px;">
              <a href="<?php echo base_url('menu') ?>" class="btn btn-default-red-inverse pad-top"><i class="fa fa-shopping-cart"></i> ORDER NOW!</a>
            </div>
          </div>
        </div>
        <!-- end .call-to-action-section -->
      </div>
    
      <!-- purchase TakeAway section start -->
      
      <!-- end .container -->
      <!-- end purchase TakeAway section  -->

      <!-- start .category box section -->
      <div class="category-boxes-icons">
        <div class=" container">
          <div class="row">
            <?php $category = get_category_detail('4');
            foreach($category as $catdata){ ?>
            <div class="col-md-3 col-sm-6 col-xs-12 text-center">
              <div class="category-boxes-item">
                <figure>
                  <img src="<?php echo category_path().$catdata->image;?>">
                  <h4><?php echo $catdata->title;?></h4>
                  <figcaption> <a href="<?php echo base_url('menu')?>#tab-<?php echo $catdata->id;?><?php echo $catdata->slug;?>" class="btn btn-default-white"><i class="fa fa-file-text-o"></i> Read  More</a> 
                  </figcaption>
                </figure>
              </div>
            </div>
            <?php } ?>

            

            

            
          </div>
          <!-- end .row -->
        </div>
        <!-- end .category-boxes-icons -->
      </div>
      <!-- container -->

      <!-- star.chef-welcome -->
      <div class="chef-welcome">
        <div class="container">
                    <div class="col-sm-7 col-md-7 col-lg-7">
                       <?php $home =get_page('home');?>
             <h1><?php echo $home->page_title; ?></h1>

             <p><?php echo $home->short_content; ?></p>
             <a href="<?php echo base_url('page/'.$home->slug) ?>" class="btn btn-default-red"><i class="fa fa-file-text-o"></i> Read  More</a>
                    </div>
                    <div class="col-sm-5 col-md-5 col-md-5 chef_welcme_right">
                       <?php $image = get_welcome_image(); ?>
                       <img src="<?php echo base_url().'assets/uploads/image/'.$image->image;?>" alt="image">
                    </div>
        </div>
        <!-- end .container -->
      </div>
      <!--end .chef-welcome-->

      <!--start small-slide section -->
      <div id="sm-slide-section">
        <div class="container">
          <div class="slide-heading text-center">
            <h4>What Our Customer Say</h4>
          </div>
          <!--end .clients heading-->
          <div id="slide-content" class="owl-carousel">
            <?php $testmonial =get_testmonial();
            foreach($testmonial as $test) { ?>
            <div class="item">
              <img src="<?php echo base_url().'assets/uploads/testmonial/used/'.$test->image;?>" alt="img-1">
              <div class="details">
                <h5><a href="#"><?php echo $test->title;?></a>
                </h5>

               <ul class="list-inline">
                <?php  $data = $test->subtitle;
               for($i=1;$i<=$data;++$i) { ?>

                  <li><a href="#"><i class="fa fa-star"></i></a>
                  </li>
                  <?php } ?>
                  
                </ul>
                <p><?php echo $test->description;?></p>
              </div>
            </div>
            <?php } ?>
            <!-- end item class div-->

          
            <!-- end item class div-->

          
            <!-- end item class div-->
          </div>
          <!-- end i.slide-content -->
        </div>
        <!-- end .container-->
      </div>
      <!-- end .sm-slide-section-->
 <?php $meal = get_cetgory_by_special(); 
 if(!empty($meal)){
   $get_category = get_category_by_product_id($meal->id,'4');
 }
   if(!empty($get_category)) { ?>
      <!--Start blog feed section-->
      <div class="latest-from-blog text-center">
        <div class="container">
          <h4 style="font-size: 27px;!important;">Special Deals</h4>
         <div class="row">
         <?php
       
          foreach($get_category as $mealdata){ ?>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="blog-latest">
                <div class="row">
                  <div class="col-md-6 col-sm-12">
                    <img class="" src="<?php echo product_path('thumb/').$mealdata->image;?>" alt="blog-image">
                  </div>
                  <div class="col-md-6 col-sm-12">
                    <h5><a href="#"><?php echo $mealdata->title;?></a>
                    </h5>
                    <table class="table table_menu_deal">
                                          <p><?php echo $mealdata->description;?></p>
                                        </table>
                                        
                    <a href="<?php echo base_url('menu')?>#tab-<?php echo $meal->id;?><?php echo $meal->slug;?>" class="btn btn-default-red"><i class="fa fa-file-text-o"></i> Read  More</a>
                  </div>
                  <!--end .blog-details-->
                </div>
                <!--end .row-->
              </div>
              <!--end .blog-latest -->
            </div>
            <?php } ?>
            <!--end grid layout-->

            <!--end grid layout-->
          </div>
          <!--end .row main-->
          <!-- read older button -->
          <div class="read-older">
            <a href="<?php echo base_url('menu') ?>" class="btn btn-default-red"><i class="fa fa-file-text-o"></i>  Order Online Now!</a>
          </div>
        </div>
        <!--end container-->
      </div>
     <?php } ?>
      <!--end .latest-from-blog-->

    </div>