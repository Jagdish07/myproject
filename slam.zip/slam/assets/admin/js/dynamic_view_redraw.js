
function variableDefined(name) {

    return typeof this[name] !== 'undefined';
}

function buildDynamicList(field, extraParams) {

    if (window.location.origin === 'http://localhost') {
        formAction = '/slam/' + extraParams.section + '/build_list';
    } else {
        formAction = '/' + extraParams.section + '/build_list';
    }

    list = "list__" + field;

    loaderString = '#loader__' + field;

    pagingObjString = ".paging__" + field;

    listObjString = "." + list;

    postArray = {
        type: field
    };
    if (extraParams === null) {
        // Do Not do anything
    } else {
        $.each(extraParams, function (key, value) {
            postArray[key] = value;
        });
    }
  
    $.post(formAction, postArray, function (data) {

        $(listObjString).html(data);

        $(loaderString).hide();

    });
}
