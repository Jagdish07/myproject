if (window.location.origin == "http://localhost") {
    var base_url = window.location.origin + "/ChilliAariz/";
} else {
    var base_url = window.location.origin + "/";
}



$(document).ready(function () {
    /*
     * Dashboard link manage
     */
    $('.hover-5x').on({
        mouseenter: function () {
            var panel_color = $(this).attr('id');
            $(this).children('.panel').children('.panel-footer').removeClass('back-footer-' + panel_color);
            $(this).children('.panel').removeClass('bg-color-' + panel_color);
        },
        mouseleave: function () {
            var panel_color = $(this).attr('id');
            $(this).children('.panel').addClass('bg-color-' + panel_color);
            $(this).children('.panel').children('.panel-footer').addClass('back-footer-' + panel_color);
        },
        click: function () {
            // Handle click...
        }
    });

    /*
     * Manage site online and offline
     */
    $('.site-online-offline').on('click', function () {

        if ($(this).hasClass('btn-success')) {
            var checkstr =  confirm('are you sure you want to Offline?');
          if(checkstr == true){
            $(this).removeClass('btn-success');
            $(this).text('Site Offline');
            $(this).addClass('btn-warning');

            /* Change the status to offline */
           $.post(base_url + "admin/change_site", {status: "0"},function (data, status) {
          });
 
        }else{
                return false;
        }

        } else {
            var checkstr =  confirm('are you sure you want to Site OnlineSite ?');
            if(checkstr == true){
              $(this).removeClass('btn-warning');
            $(this).text('Site Online');
            $(this).addClass('btn-success');

            /* Change the status to Online */
            $.post(base_url + "admin/change_site",{status: "1"}, function (data, status) {

            });
            }else{
            return false;
            }
            
        }
    });
    $('.updatesetting').click(function(){
      var value = $('.collection-val').val();
      var deliveryvalue = $('.delivery-val').val();
      
       $.post(base_url + "admin/change_site",{value: value,deliveryvalue:deliveryvalue}, function (data, status) {

      alert('update Successfully');
            });

    });
    
    /*
     * Manage form upload
     */
    $('#image').change(function(){
        if($(this).val() === '') {
            $('#file_msg').text('No file selected.');
        } else {
            $('#file_msg').text($(this).val());
        }
    });
    
    $('#select_file').on('click', function(){
        $('#image').trigger('click');
    });
});


