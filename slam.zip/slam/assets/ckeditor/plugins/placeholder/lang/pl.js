﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('placeholder','pl',{placeholder:{title:'Właściwości wypełniacza',toolbar:'Utwórz wypełniacz',text:'Tekst wypełnienia',edit:'Edytuj wypełnienie',textMissing:'Wypełnienie musi posiadać jakiś tekst.'}});
